import React, { useState } from "react";
import { useRouter } from "next/router";
import Layout from "@/components/Layout";
import {
 FaPlus,
 FaFilter,
 FaUsers,
 FaTasks,
 FaClock,
 FaCalendarAlt,
 FaCheckCircle,
 FaArrowUp,
 FaArrowDown,
 FaCodeBranch,
 FaBolt,
 FaEllipsisH,
 FaChartLine,
} from "react-icons/fa";

// ── Types ───────────────────────────────────────────────────────────────────

interface Sprint {
 id: string;
 name: string;
 project: string;
 team: string;
 teamColor: string;
 progress: number;
 daysLeft: number | string;
 status: "active" | "upcoming" | "completed" | "planning";
 totalPoints: number;
 completedPoints: number;
 startDate: string;
 endDate: string;
 sprintNumber: number;
 description: string;
 tasksTotal: number;
 tasksCompleted: number;
}

interface BurndownPoint {
 day: number;
 ideal: number;
 actual: number;
}

interface TeamMember {
 name: string;
 role: string;
 avatar: string;
 color: string;
 utilization: number;
 capacity: string;
 assigned: string;
 status: string;
}

interface SprintTask {
 id: string;
 title: string;
 priority: string;
 status: string;
 assignee: string;
 points: number;
}

interface ActivityItem {
 icon: React.ReactNode;
 iconColor: string;
 description: string;
 timestamp: string;
}

// ── Sample Data ─────────────────────────────────────────────────────────────

const SPREADS: Sprint[] = [
 {
 id: "sprint-1",
 name: "Sprint 3",
 project: "E-commerce Platform",
 team: "Team Alpha",
 teamColor: "blue",
 progress: 72,
 daysLeft: 5,
 status: "active",
 totalPoints: 34,
 completedPoints: 28,
 startDate: "Apr 15",
 endDate: "Apr 30",
 sprintNumber: 3,
 description: "Implementing checkout flow, payment integration, and order management features for the E-commerce Platform.",
 tasksTotal: 30,
 tasksCompleted: 24,
 },
 {
 id: "sprint-2",
 name: "Sprint 2",
 project: "Analytics Dashboard",
 team: "Team Beta",
 teamColor: "purple",
 progress: 60,
 daysLeft: 2,
 status: "active",
 totalPoints: 21,
 completedPoints: 13,
 startDate: "Apr 10",
 endDate: "Apr 24",
 sprintNumber: 2,
 description: "Building real-time data visualization widgets, export functionality, and custom report builder.",
 tasksTotal: 22,
 tasksCompleted: 13,
 },
 {
 id: "sprint-3",
 name: "Sprint 1",
 project: "Mobile Banking App",
 team: "Team Gamma",
 teamColor: "orange",
 progress: 85,
 daysLeft: 1,
 status: "active",
 totalPoints: 28,
 completedPoints: 24,
 startDate: "Apr 1",
 endDate: "Apr 14",
 sprintNumber: 1,
 description: "Core mobile banking features including biometric authentication, account overview, and fund transfers.",
 tasksTotal: 18,
 tasksCompleted: 15,
 },
 {
 id: "sprint-4",
 name: "Sprint 1",
 project: "Internal Automation",
 team: "Team Delta",
 teamColor: "green",
 progress: 0,
 daysLeft: "Starts in 3 days",
 status: "planning",
 totalPoints: 13,
 completedPoints: 0,
 startDate: "Apr 20",
 endDate: "May 5",
 sprintNumber: 1,
 description: "CI/CD pipeline optimization, automated testing framework, and deployment automation workflows.",
 tasksTotal: 15,
 tasksCompleted: 0,
 },
];

const BURNDOWN_DATA: BurndownPoint[] = [
 { day: 1, ideal: 34, actual: 34 },
 { day: 2, ideal: 31, actual: 32 },
 { day: 3, ideal: 28, actual: 30 },
 { day: 4, ideal: 25, actual: 27 },
 { day: 5, ideal: 22, actual: 25 },
 { day: 6, ideal: 19, actual: 22 },
 { day: 7, ideal: 16, actual: 18 },
 { day: 8, ideal: 13, actual: 14 },
 { day: 9, ideal: 10, actual: 10 },
 { day: 10, ideal: 7, actual: 8 },
 { day: 11, ideal: 4, actual: 5 },
 { day: 12, ideal: 1, actual: 2 },
 { day: 13, ideal: 0, actual: 1 },
 { day: 14, ideal: 0, actual: 0 },
 { day: 15, ideal: 0, actual: 0 },
];

const TEAM_MEMBERS: TeamMember[] = [
 { name: "Alex Johnson", role: "Scrum Master", avatar: "AJ", color: "bg-blue-500", utilization: 100, capacity: "Full-time", assigned: "8 tasks", status: "Active" },
 { name: "Taylor Smith", role: "Senior Developer", avatar: "TS", color: "bg-purple-500", utilization: 85, capacity: "Full-time", assigned: "6 tasks", status: "Active" },
 { name: "Casey Lee", role: "Developer", avatar: "CL", color: "bg-green-500", utilization: 90, capacity: "Full-time", assigned: "5 tasks", status: "Active" },
 { name: "Morgan Davis", role: "QA Engineer", avatar: "MD", color: "bg-orange-500", utilization: 75, capacity: "Full-time", assigned: "4 tasks", status: "Active" },
 { name: "Jordan Wilson", role: "Developer", avatar: "JW", color: "bg-pink-500", utilization: 80, capacity: "Full-time", assigned: "4 tasks", status: "Active" },
 { name: "Riley Brown", role: "Frontend Dev", avatar: "RB", color: "bg-cyan-500", utilization: 70, capacity: "Full-time", assigned: "3 tasks", status: "Active" },
 { name: "Quinn Park", role: "Backend Dev", avatar: "QP", color: "bg-indigo-500", utilization: 65, capacity: "Part-time", assigned: "2 tasks", status: "Available" },
];

const SPRINT_TASKS: SprintTask[] = [
 { id: "t-1", title: "Implement product search", priority: "high", status: "in_progress", assignee: "Taylor Smith", points: 5 },
 { id: "t-2", title: "Add shopping cart", priority: "high", status: "in_progress", assignee: "Casey Lee", points: 8 },
 { id: "t-3", title: "Create product detail page", priority: "medium", status: "in_progress", assignee: "Riley Brown", points: 5 },
 { id: "t-4", title: "Implement user auth", priority: "high", status: "review", assignee: "Quinn Park", points: 8 },
 { id: "t-5", title: "Design checkout flow", priority: "medium", status: "todo", assignee: "Jordan Wilson", points: 5 },
];

const RECENT_ACTIVITY: ActivityItem[] = [
 { icon: <FaCodeBranch className="w-3.5 h-3.5" />, iconColor: "text-green-400", description: "Taylor Smith completed checkout validation", timestamp: "2h ago" },
 { icon: <FaBolt className="w-3.5 h-3.5" />, iconColor: "text-yellow-400", description: "CI pipeline passed for PR #142", timestamp: "4h ago" },
 { icon: <FaArrowUp className="w-3.5 h-3.5" />, iconColor: "text-blue-400", description: "Story points updated from 13 to 15", timestamp: "6h ago" },
 { icon: <FaUsers className="w-3.5 h-3.5" />, iconColor: "text-purple-400", description: "Morgan Davis joined the sprint", timestamp: "1d ago" },
 { icon: <FaTasks className="w-3.5 h-3.5" />, iconColor: "text-orange-400", description: "Sprint goal updated by Alex Johnson", timestamp: "2d ago" },
];

// ── Inline SVG Burndown Chart ───────────────────────────────────────────────

function BurndownChart({ data }: { data: BurndownPoint[] }) {
 const width = 700;
 const height = 300;
 const padding = { top: 20, right: 30, bottom: 40, left: 50 };
 const chartW = width - padding.left - padding.right;
 const chartH = height - padding.top - padding.bottom;

 const maxVal = 35;
 const xStep = chartW / (data.length - 1);

 const toX = (i: number) => padding.left + i * xStep;
 const toY = (v: number) => padding.top + chartH - (v / maxVal) * chartH;

 const dateLabels = ["Apr15", "Apr16", "Apr17", "Apr18", "Apr19", "Apr20", "Apr21", "Apr22", "Apr23", "Apr24", "Apr25", "Apr26", "Apr27", "Apr28", "Apr29", "Apr30"];

 return (
 <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto">
 <defs>
 <linearGradient id="actualGrad" x1="0" y1="0" x2="1" y2="0">
 <stop offset="0%" stopColor="#3b82f6" />
 <stop offset="100%" stopColor="#6366f1" />
 </linearGradient>
 </defs>

 {/* Background */}
 <rect x="0" y="0" width={width} height={height} fill="#111827" rx="8" />

 {/* Grid lines */}
 {[0, 5, 10, 15, 20, 25, 30, 35].map((v) => (
 <g key={`grid-${v}`}>
 <line x1={padding.left} y1={toY(v)} x2={width - padding.right} y2={toY(v)} stroke="#1e293b" strokeWidth="1" />
 <text x={padding.left - 8} y={toY(v) + 4} textAnchor="end" className="fill-slate-500" style={{ fontSize: 11 }}>
 {v}
 </text>
 </g>
 ))}

 {/* X-axis line */}
 <line x1={padding.left} y1={height - padding.bottom} x2={width - padding.right} y2={height - padding.bottom} stroke="#334155" strokeWidth="1" />

 {/* Date labels - show every 3rd */}
 {data.map((p, i) => {
 if (i % 3 !== 0 && i !== data.length - 1) return null;
 const labelIdx = Math.min(i, dateLabels.length - 1);
 return (
 <text key={`day-${p.day}`} x={toX(i)} y={height - 8} textAnchor="middle" className="fill-slate-500" style={{ fontSize: 10 }}>
 {dateLabels[labelIdx]}
 </text>
 );
 })}

 {/* Ideal line - dashed */}
 <polyline
 points={data.map((p, i) => `${toX(i)},${toY(p.ideal)}`).join(" ")}
 fill="none"
 stroke="#64748b"
 strokeWidth="2"
 strokeDasharray="6,4"
 />

 {/* Actual line - solid blue */}
 <polyline
 points={data.map((p, i) => `${toX(i)},${toY(p.actual)}`).join(" ")}
 fill="none"
 stroke="url(#actualGrad)"
 strokeWidth="2.5"
 />

 {/* Actual area fill */}
 <polygon
 points={`${toX(0)},${toY(data[0].actual)} ${data.map((p, i) => `${toX(i)},${toY(p.actual)}`).join(" ")} ${toX(data.length - 1)},${toY(0)} ${toX(0)},${toY(0)}`}
 fill="url(#actualGrad)"
 opacity="0.06"
 />

 {/* Data points on actual line */}
 {data.map((p, i) => (
 <circle key={`dot-${i}`} cx={toX(i)} cy={toY(p.actual)} r="4" fill="#3b82f6" stroke="#111827" strokeWidth="2" />
 ))}

 {/* Legend */}
 <text x={padding.left} y={12} className="fill-slate-400" style={{ fontSize: 11 }}>
 <tspan fill="#64748b" strokeDasharray="4,2" strokeWidth="1">────────</tspan> Ideal
 </text>
 <text x={padding.left + 90} y={12} className="fill-slate-400" style={{ fontSize: 11 }}>
 <tspan fill="#3b82f6" stroke="#3b82f6" strokeWidth="2">━━━━</tspan> Actual
 </text>
 </svg>
 );
}

// ── Helper Components ───────────────────────────────────────────────────────

function StatusBadge({ status }: { status: Sprint["status"] }) {
 const config: Record<Sprint["status"], { label: string; className: string }> = {
 active: { label: "Active", className: "bg-green-400/10 text-green-400" },
 upcoming: { label: "Upcoming", className: "bg-blue-400/10 text-blue-400" },
 completed: { label: "Completed", className: "bg-slate-400/10 text-slate-400" },
 planning: { label: "Planning", className: "bg-gray-400/10 text-gray-400" },
 };

 const c = config[status];

 return (
 <span className={`text-[11px] font-medium px-2 py-0.5 rounded-full ${c.className}`}>
 {c.label}
 </span>
 );
}

function PriorityBadge({ priority }: { priority: string }) {
 const colors: Record<string, string> = {
 high: "bg-red-400/10 text-red-400",
 medium: "bg-yellow-400/10 text-yellow-400",
 low: "bg-slate-400/10 text-slate-400",
 };
 return (
 <span className={`text-[11px] font-medium px-2 py-0.5 rounded-full ${colors[priority] || colors.low}`}>
 {priority.charAt(0).toUpperCase() + priority.slice(1)}
 </span>
 );
}

// ── Sprints Page ────────────────────────────────────────────────────────────

const SprintsPage: React.FC = () => {
 const router = useRouter();
 const [search, setSearch] = useState("");
 const [projectFilter, setProjectFilter] = useState("All Projects");
 const [teamFilter, setTeamFilter] = useState("All Teams");
 const [statusFilter, setStatusFilter] = useState("All Status");
 const [activeTab, setActiveTab] = useState<"active" | "upcoming" | "completed" | "all">("active");
 const [expandedSprint, setExpandedSprint] = useState<string | null>(null);
 const [detailTab, setDetailTab] = useState("overview");

 const handleNavigate = (navId: string) => {
 const navHref: Record<string, string> = {
 overview: "/",
 teams: "/teams",
 tasks: "/tasks",
 agents: "/agents",
 projects: "/projects",
 activity: "/activity",
 settings: "/settings",
 sprints: "/sprints",
 };
 router.push(navHref[navId] || "/");
 };

 const statsCards = [
 { label: "Active Sprints", value: "8", icon: <FaBolt />, color: "text-green-400", bg: "bg-green-400/10", trend: "+2", trendUp: true },
 { label: "Total Story Points", value: "42", icon: <FaTasks />, color: "text-blue-400", bg: "bg-blue-400/10", trend: "+8", trendUp: true },
 { label: "Average Completion", value: "68%", icon: <FaChartLine />, color: "text-purple-400", bg: "bg-purple-400/10", trend: "+5%", trendUp: true },
 { label: "Average Cycle Time", value: "12 days", icon: <FaClock />, color: "text-orange-400", bg: "bg-orange-400/10", trend: "-1d", trendUp: true },
 { label: "Teams Running Sprints", value: "6", icon: <FaUsers />, color: "text-pink-400", bg: "bg-pink-400/10", trend: "+1", trendUp: true },
 ];

 const tabs = [
 { key: "active" as const, label: "Active Sprints" },
 { key: "upcoming" as const, label: "Upcoming" },
 { key: "completed" as const, label: "Completed" },
 { key: "all" as const, label: "All Sprints" },
 ];

 const filteredSprints = SPREADS.filter((s) => {
 if (activeTab === "all") return true;
 return s.status === activeTab;
 });

 const expandedSprintData = expandedSprint ? SPREADS.find((s) => s.id === expandedSprint) : null;

 const progressColor = (pct: number) => {
 if (pct >= 80) return "bg-green-500";
 if (pct >= 50) return "bg-blue-500";
 if (pct >= 25) return "bg-orange-500";
 return "bg-slate-500";
 };

 const teamColorMap: Record<string, string> = {
 blue: "bg-blue-500/10 text-blue-400",
 purple: "bg-purple-500/10 text-purple-400",
 orange: "bg-orange-500/10 text-orange-400",
 green: "bg-green-500/10 text-green-400",
 };

 const progressBarColor = (pct: number, teamColor: string) => {
 if (pct >= 80) return "bg-green-500";
 if (pct >= 50) return teamColor === "purple" ? "bg-purple-500" : teamColor === "orange" ? "bg-orange-500" : "bg-blue-500";
 if (pct >= 25) return "bg-orange-500";
 return "bg-slate-500";
 };

 return (
 <Layout activeNav="sprints" onNavigate={handleNavigate}>
 <div className="px-6 space-y-6">
 {/* ── Page Header ──────────────────────────────────────────── */}
 <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
 <div>
 <h1 className="text-2xl font-bold text-white">Sprints</h1>
 <p className="text-sm text-slate-400 mt-1">Manage and track sprint progress across all teams.</p>
 </div>
 <div className="flex flex-wrap items-center gap-3">
 <div className="relative">
 <FaFilter className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-500" />
 <select
 value={projectFilter}
 onChange={(e) => setProjectFilter(e.target.value)}
 className="input-dark text-sm py-2 pl-9 pr-3"
 >
 <option>All Projects</option>
 <option>E-commerce Platform</option>
 <option>Analytics Dashboard</option>
 <option>Mobile Banking App</option>
 <option>Internal Automation</option>
 </select>
 </div>
 <select
 value={teamFilter}
 onChange={(e) => setTeamFilter(e.target.value)}
 className="input-dark text-sm py-2 px-3"
 >
 <option>All Teams</option>
 <option>Team Alpha</option>
 <option>Team Beta</option>
 <option>Team Gamma</option>
 <option>Team Delta</option>
 </select>
 <select
 value={statusFilter}
 onChange={(e) => setStatusFilter(e.target.value)}
 className="input-dark text-sm py-2 px-3"
 >
 <option>All Status</option>
 <option>Active</option>
 <option>Upcoming</option>
 <option>Completed</option>
 <option>Planning</option>
 </select>
 <div className="relative">
 <FaCalendarAlt className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-500" />
 <input
 type="text"
 placeholder="Date range"
 className="input-dark text-sm py-2 pl-9 pr-3 w-40"
 />
 </div>
 <button className="bg-blue-600 hover:bg-blue-500 text-white text-sm px-4 py-2 rounded-md flex items-center gap-2 transition-colors whitespace-nowrap">
 <FaPlus className="w-3.5 h-3.5" />
 Create Sprint
 </button>
 </div>
 </div>

 {/* ── Stats Row ────────────────────────────────────────────── */}
 <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
 {statsCards.map((s) => (
 <div key={s.label} className="stat-card">
 <div className="flex items-start justify-between">
 <div>
 <p className="text-slate-400 text-xs mb-1">{s.label}</p>
 <p className="text-xl font-bold text-white">{s.value}</p>
 </div>
 <div className={`p-2 rounded-lg ${s.bg} ${s.color}`}>
 {React.cloneElement(s.icon as React.ReactElement, { className: "w-4 h-4" })}
 </div>
 </div>
 {s.trend && (
 <div className={`flex items-center gap-1 mt-2 text-[11px] ${s.trendUp ? "text-green-400" : "text-red-400"}`}>
 {s.trendUp ? <FaArrowUp className="w-2.5 h-2.5" /> : <FaArrowDown className="w-2.5 h-2.5" />}
 {s.trend}
 </div>
 )}
 </div>
 ))}
 </div>

 {/* ── Tabs ─────────────────────────────────────────────────── */}
 <div className="flex items-center gap-1 border-b border-slate-700">
 {tabs.map((tab) => (
 <button
 key={tab.key}
 onClick={() => setActiveTab(tab.key)}
 className={`px-4 py-2.5 text-sm font-medium transition-colors border-b-2 ${
 activeTab === tab.key
 ? "text-blue-400 border-blue-400"
 : "text-slate-400 border-transparent hover:text-slate-300"
 }`}
 >
 {tab.label}
 </button>
 ))}
 </div>

 {/* ── Sprint Cards ─────────────────────────────────────────── */}
 <div className="space-y-4">
 {filteredSprints.map((sprint) => (
 <div
 key={sprint.id}
 className="bg-[#1a1d2e] border border-slate-700 rounded-lg overflow-hidden"
 >
 <div
 className="p-5 cursor-pointer hover:border-slate-600 transition-colors"
 onClick={() => setExpandedSprint(expandedSprint === sprint.id ? null : sprint.id)}
 >
 <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
 <div className="flex items-center gap-4">
 <div className={`w-10 h-10 rounded-lg ${teamColorMap[sprint.teamColor] || "bg-slate-500/10 text-slate-400"} flex items-center justify-center`}>
 <FaTasks className="w-5 h-5" />
 </div>
 <div>
 <div className="flex items-center gap-2">
 <h3 className="text-white font-semibold text-sm">{sprint.project} / {sprint.team} / {sprint.name}</h3>
 <StatusBadge status={sprint.status} />
 </div>
 <div className="flex items-center gap-3 mt-1">
 <span className="text-xs text-slate-400 flex items-center gap-1">
 <FaCalendarAlt className="w-3 h-3" />
 {sprint.startDate} - {sprint.endDate}
 </span>
 <span className="text-xs text-slate-400 flex items-center gap-1">
 <FaClock className="w-3 h-3" />
 {typeof sprint.daysLeft === "number" ? `${sprint.daysLeft} days left` : sprint.daysLeft}
 </span>
 </div>
 </div>
 </div>
 <div className="flex items-center gap-6">
 <div className="text-right">
 <p className="text-xs text-slate-400 mb-1">Progress</p>
 <div className="flex items-center gap-2">
 <div className="w-24 bg-slate-700 rounded-full h-2">
 <div className={`${progressBarColor(sprint.progress, sprint.teamColor)} h-2 rounded-full transition-all`} style={{ width: `${sprint.progress}%` }} />
 </div>
 <span className="text-xs text-slate-300 font-medium w-8">{sprint.progress}%</span>
 </div>
 </div>
 <div className="text-right hidden sm:block">
 <p className="text-xs text-slate-400">Story Points</p>
 <p className="text-sm text-white font-medium">{sprint.completedPoints}/{sprint.totalPoints}</p>
 </div>
 <div className="flex -space-x-2 hidden sm:flex">
 {[1, 2].map((i) => (
 <div key={i} className={`w-7 h-7 rounded-full ${sprint.teamColor === "blue" ? "bg-blue-500" : sprint.teamColor === "purple" ? "bg-purple-500" : sprint.teamColor === "orange" ? "bg-orange-500" : "bg-green-500"} flex items-center justify-center text-white text-[10px] font-bold border-2 border-[#1a1d2e]`}>
 +{i}
 </div>
 ))}
 </div>
 <button className="text-slate-400 hover:text-white transition-colors p-1">
 <FaEllipsisH className="w-4 h-4" />
 </button>
 </div>
 </div>
 </div>

 {/* ── Expanded Detail Panel ──────────────────────────────── */}
 {expandedSprint === sprint.id && expandedSprintData && (
 <div className="border-t border-slate-700 bg-[#111827]">
 {/* Detail Header Tabs */}
 <div className="flex items-center gap-1 px-5 pt-3 overflow-x-auto">
 {["overview", "backlog", "tasks", "capacity", "burndown", "metrics"].map((tab) => (
 <button
 key={tab}
 onClick={() => setDetailTab(tab)}
 className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
 detailTab === tab
 ? "bg-blue-600 text-white"
 : "text-slate-400 hover:text-slate-300 hover:bg-slate-800"
 }`}
 >
 {tab.charAt(0).toUpperCase() + tab.slice(1)}
 </button>
 ))}
 </div>

 <div className="p-5 space-y-6">
 {/* Overview Tab */}
 {detailTab === "overview" && (
 <>
 {/* Sprint Metadata */}
 <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
 <div className="bg-[#1a1d2e] rounded-lg p-4 border border-slate-700">
 <p className="text-slate-400 text-xs mb-1">Sprint Goal</p>
 <p className="text-white text-sm">{expandedSprintData.description}</p>
 </div>
 <div className="bg-[#1a1d2e] rounded-lg p-4 border border-slate-700">
 <p className="text-slate-400 text-xs mb-1">Dates</p>
 <p className="text-white text-sm">{expandedSprintData.startDate} - {expandedSprintData.endDate}</p>
 <p className="text-slate-500 text-xs mt-1">16 working days</p>
 </div>
 <div className="bg-[#1a1d2e] rounded-lg p-4 border border-slate-700">
 <p className="text-slate-400 text-xs mb-1">Story Points</p>
 <div className="flex items-center justify-between">
 <span className="text-white text-sm">{expandedSprintData.completedPoints}/{expandedSprintData.totalPoints} completed</span>
 <FaCheckCircle className="w-4 h-4 text-green-400" />
 </div>
 <div className="w-full bg-slate-700 rounded-full h-1.5 mt-2">
 <div className={`${progressColor(expandedSprintData.progress)} h-1.5 rounded-full`} style={{ width: `${expandedSprintData.progress}%` }} />
 </div>
 </div>
 </div>

 {/* Burndown Chart */}
 <div>
 <h4 className="text-white text-sm font-semibold mb-3 flex items-center gap-2">
 <FaChartLine className="w-4 h-4 text-blue-400" />
 Burndown Chart
 </h4>
 <div className="bg-[#1a1d2e] border border-slate-700 rounded-lg p-3 overflow-hidden">
 <BurndownChart data={BURNDOWN_DATA} />
 </div>
 </div>

 {/* Team Members Table */}
 <div>
 <h4 className="text-white text-sm font-semibold mb-3 flex items-center gap-2">
 <FaUsers className="w-4 h-4 text-purple-400" />
 Team Members
 </h4>
 <div className="bg-[#1a1d2e] border border-slate-700 rounded-lg overflow-hidden">
 <div className="overflow-x-auto">
 <table className="w-full text-sm">
 <thead>
 <tr className="text-xs text-slate-500 border-b border-slate-700">
 <th className="text-left px-4 py-2.5 font-medium">Name</th>
 <th className="text-left px-4 py-2.5 font-medium">Role</th>
 <th className="text-left px-4 py-2.5 font-medium">Capacity</th>
 <th className="text-left px-4 py-2.5 font-medium">Assigned</th>
 <th className="text-left px-4 py-2.5 font-medium">Status</th>
 </tr>
 </thead>
 <tbody>
 {TEAM_MEMBERS.map((member) => (
 <tr key={member.name} className="border-b border-slate-700/50 hover:bg-slate-800/30">
 <td className="px-4 py-2.5">
 <div className="flex items-center gap-2.5">
 <div className={`w-7 h-7 rounded-full ${member.color} flex items-center justify-center text-white text-[10px] font-bold`}>
 {member.avatar}
 </div>
 <span className="text-white text-xs font-medium">{member.name}</span>
 </div>
 </td>
 <td className="px-4 py-2.5 text-slate-400 text-xs">{member.role}</td>
 <td className="px-4 py-2.5 text-slate-400 text-xs">{member.capacity}</td>
 <td className="px-4 py-2.5 text-slate-300 text-xs">{member.assigned}</td>
 <td className="px-4 py-2.5">
 <span className="flex items-center gap-1 text-green-400 text-xs">
 <span className="w-1.5 h-1.5 rounded-full bg-green-400" />
 {member.status}
 </span>
 </td>
 </tr>
 ))}
 </tbody>
 </table>
 </div>
 </div>
 </div>

 {/* Progress Summary & Recent Activity side by side */}
 <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
 {/* Progress Summary */}
 <div>
 <h4 className="text-white text-sm font-semibold mb-3">Progress Summary</h4>
 <div className="bg-[#1a1d2e] border border-slate-700 rounded-lg p-4 space-y-3">
 <div className="flex items-center justify-between">
 <span className="text-xs text-slate-400">Sprint Progress</span>
 <span className="text-xs text-white font-medium">{expandedSprintData.progress}%</span>
 </div>
 <div className="w-full bg-slate-700 rounded-full h-2">
 <div className={`${progressColor(expandedSprintData.progress)} h-2 rounded-full`} style={{ width: `${expandedSprintData.progress}%` }} />
 </div>
 <div className="flex items-center justify-between">
 <span className="text-xs text-slate-400">Tasks</span>
 <span className="text-xs text-white font-medium">{expandedSprintData.tasksCompleted}/{expandedSprintData.tasksTotal} completed</span>
 </div>
 <div className="flex items-center justify-between">
 <span className="text-xs text-slate-400">Story Points</span>
 <span className="text-xs text-white font-medium">{expandedSprintData.completedPoints}/{expandedSprintData.totalPoints}</span>
 </div>
 <div className="flex items-center justify-between">
 <span className="text-xs text-slate-400">Remaining</span>
 <span className="text-xs text-orange-400 font-medium">{expandedSprintData.tasksTotal - expandedSprintData.tasksCompleted} tasks, {expandedSprintData.totalPoints - expandedSprintData.completedPoints} pts</span>
 </div>
 </div>
 </div>

 {/* Recent Activity */}
 <div>
 <h4 className="text-white text-sm font-semibold mb-3">Recent Activity</h4>
 <div className="bg-[#1a1d2e] border border-slate-700 rounded-lg p-4 space-y-3">
 {RECENT_ACTIVITY.map((item, i) => (
 <div key={i} className="flex items-start gap-3">
 <div className={`p-1.5 rounded-md bg-slate-800 ${item.iconColor} flex-shrink-0`}>
 {item.icon}
 </div>
 <div className="flex-1 min-w-0">
 <p className="text-xs text-slate-300 leading-snug">{item.description}</p>
 <p className="text-[11px] text-slate-500 mt-0.5">{item.timestamp}</p>
 </div>
 </div>
 ))}
 </div>
 </div>
 </div>

 {/* Sprint Tasks Table */}
 <div>
 <h4 className="text-white text-sm font-semibold mb-3 flex items-center gap-2">
 <FaTasks className="w-4 h-4 text-blue-400" />
 Sprint Tasks
 </h4>
 <div className="bg-[#1a1d2e] border border-slate-700 rounded-lg overflow-hidden">
 <div className="overflow-x-auto">
 <table className="w-full text-sm">
 <thead>
 <tr className="text-xs text-slate-500 border-b border-slate-700">
 <th className="text-left px-4 py-2.5 font-medium">Task</th>
 <th className="text-left px-4 py-2.5 font-medium">Priority</th>
 <th className="text-left px-4 py-2.5 font-medium">Status</th>
 <th className="text-left px-4 py-2.5 font-medium">Assignee</th>
 <th className="text-left px-4 py-2.5 font-medium">Points</th>
 <th className="text-left px-4 py-2.5 font-medium">Actions</th>
 </tr>
 </thead>
 <tbody>
 {SPRINT_TASKS.map((task) => (
 <tr key={task.id} className="border-b border-slate-700/50 hover:bg-slate-800/30">
 <td className="px-4 py-2.5 text-white text-xs font-medium">{task.title}</td>
 <td className="px-4 py-2.5">
 <PriorityBadge priority={task.priority} />
 </td>
 <td className="px-4 py-2.5">
 <span className={`text-[11px] font-medium px-2 py-0.5 rounded-full ${
 task.status === "in_progress" ? "bg-blue-400/10 text-blue-400" :
 task.status === "review" ? "bg-yellow-400/10 text-yellow-400" :
 task.status === "done" ? "bg-green-400/10 text-green-400" :
 "bg-slate-400/10 text-slate-400"
 }`}>
 {task.status === "in_progress" ? "In Progress" :
 task.status === "review" ? "In Review" :
 task.status === "done" ? "Done" : "Todo"}
 </span>
 </td>
 <td className="px-4 py-2.5 text-slate-400 text-xs">{task.assignee}</td>
 <td className="px-4 py-2.5 text-slate-300 text-xs">{task.points}</td>
 <td className="px-4 py-2.5">
 <button className="text-slate-400 hover:text-white transition-colors">
 <FaEllipsisH className="w-3.5 h-3.5" />
 </button>
 </td>
 </tr>
 ))}
 </tbody>
 </table>
 </div>
 </div>
 </div>
 </>
 )}

 {/* Burndown Tab */}
 {detailTab === "burndown" && (
 <div>
 <h4 className="text-white text-sm font-semibold mb-3">Sprint Burndown</h4>
 <div className="bg-[#1a1d2e] border border-slate-700 rounded-lg p-3 overflow-hidden">
 <BurndownChart data={BURNDOWN_DATA} />
 </div>
 <div className="flex items-center gap-6 mt-3 text-xs text-slate-400">
 <span className="flex items-center gap-1.5">
 <span className="w-4 h-0.5 bg-slate-500 inline-block rounded" style={{ borderBottom: "2px dashed #64748b", height: 0 }} />
 Ideal Burndown
 </span>
 <span className="flex items-center gap-1.5">
 <span className="w-4 h-0.5 bg-blue-500 inline-block rounded" />
 Actual Burndown
 </span>
 </div>
 </div>
 )}

 {/* Metrics Tab */}
 {detailTab === "metrics" && (
 <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
 <div className="bg-[#1a1d2e] border border-slate-700 rounded-lg p-4">
 <p className="text-slate-400 text-xs mb-1">Velocity</p>
 <p className="text-white text-xl font-bold">15 pts</p>
 <p className="text-green-400 text-xs mt-1">+3 from last sprint</p>
 </div>
 <div className="bg-[#1a1d2e] border border-slate-700 rounded-lg p-4">
 <p className="text-slate-400 text-xs mb-1">Cycle Time</p>
 <p className="text-white text-xl font-bold">12 days</p>
 <p className="text-green-400 text-xs mt-1">-1d improvement</p>
 </div>
 <div className="bg-[#1a1d2e] border border-slate-700 rounded-lg p-4">
 <p className="text-slate-400 text-xs mb-1">Lead Time</p>
 <p className="text-white text-xl font-bold">3.5 days</p>
 <p className="text-green-400 text-xs mt-1">On track</p>
 </div>
 <div className="bg-[#1a1d2e] border border-slate-700 rounded-lg p-4">
 <p className="text-slate-400 text-xs mb-1">Defect Rate</p>
 <p className="text-white text-xl font-bold">2.1%</p>
 <p className="text-green-400 text-xs mt-1">Below threshold</p>
 </div>
 </div>
 )}

 {/* Other tabs placeholder */}
 {(detailTab === "backlog" || detailTab === "tasks" || detailTab === "capacity") && (
 <div className="text-center py-8">
 <p className="text-slate-400 text-sm">{detailTab.charAt(0).toUpperCase() + detailTab.slice(1)} view coming soon.</p>
 </div>
 )}
 </div>
 </div>
 )}
 </div>
 ))}
 </div>

 {filteredSprints.length === 0 && (
 <div className="text-center py-12 bg-[#1a1d2e] border border-slate-700 rounded-lg">
 <FaTasks className="w-8 h-8 text-slate-600 mx-auto mb-3" />
 <p className="text-slate-400 text-sm">No sprints match your filters</p>
 <button
 onClick={() => {
 setSearch("");
 setProjectFilter("All Projects");
 setTeamFilter("All Teams");
 setStatusFilter("All Status");
 }}
 className="text-blue-400 text-sm mt-2 hover:underline"
 >
 Clear filters
 </button>
 </div>
 )}
 </div>
 </Layout>
 );
};

export default SprintsPage;
