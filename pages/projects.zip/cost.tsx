'use client';

import React, { useState } from "react";
import { useRouter } from "next/router";
import Layout from "@/components/Layout";
import InteractiveDonut from "@/components/InteractiveDonut";
import {
 FaDollarSign,
 FaChartBar,
 FaFilter,
 FaDownload,
 FaCalendarAlt,
 FaArrowUp,
 FaArrowDown,
 FaCheckCircle,
 FaExclamationTriangle,
} from "react-icons/fa";

// ── Types ───────────────────────────────────────────────────────────────────

interface CostRow {
 id: string;
 model: string;
 provider: string;
 providerBadge: string;
 requestsToday: number;
 inputTokens: number;
 outputTokens: number;
 inputCost: number;
 outputCost: number;
 totalCost: number;
 pctOfSpend: number;
}

interface DailyDataPoint {
 day: number;
 cost: number;
}

interface ProviderShare {
 name: string;
 pct: number;
 color: string;
}

interface MonthlyBar {
 month: string;
 spend: number;
 isCurrent: boolean;
}

// ── Sample Data ─────────────────────────────────────────────────────────────

const COST_ROWS: CostRow[] = [
 {
 id: "c1",
 model: "Claude Sonnet 4.5",
 provider: "Anthropic",
 providerBadge: "bg-orange-400/10 text-orange-400",
 requestsToday: 45200,
 inputTokens: 8.4,
 outputTokens: 3.2,
 inputCost: 352.00,
 outputCost: 1480.00,
 totalCost: 1832.00,
 pctOfSpend: 64.4,
 },
 {
 id: "c2",
 model: "GPT-4o",
 provider: "OpenAI",
 providerBadge: "bg-teal-400/10 text-teal-400",
 requestsToday: 28100,
 inputTokens: 5.1,
 outputTokens: 2.0,
 inputCost: 178.50,
 outputCost: 580.00,
 totalCost: 758.50,
 pctOfSpend: 26.6,
 },
 {
 id: "c3",
 model: "Gemini 2.5 Pro",
 provider: "Google",
 providerBadge: "bg-blue-400/10 text-blue-400",
 requestsToday: 9800,
 inputTokens: 2.3,
 outputTokens: 0.9,
 inputCost: 64.90,
 outputCost: 216.00,
 totalCost: 280.90,
 pctOfSpend: 9.9,
 },
 {
 id: "c4",
 model: "Claude Opus 4",
 provider: "Anthropic",
 providerBadge: "bg-orange-400/10 text-orange-400",
 requestsToday: 3200,
 inputTokens: 0.8,
 outputTokens: 0.5,
 inputCost: 28.00,
 outputCost: 112.50,
 totalCost: 140.50,
 pctOfSpend: 4.9,
 },
 {
 id: "c5",
 model: "GPT-4o Mini",
 provider: "OpenAI",
 providerBadge: "bg-teal-400/10 text-teal-400",
 requestsToday: 53400,
 inputTokens: 4.2,
 outputTokens: 1.6,
 inputCost: 21.00,
 outputCost: 29.40,
 totalCost: 50.40,
 pctOfSpend: 1.8,
 },
 {
 id: "c6",
 model: "Gemini Flash 2.0",
 provider: "Google",
 providerBadge: "bg-blue-400/10 text-blue-400",
 requestsToday: 18700,
 inputTokens: 1.1,
 outputTokens: 0.4,
 inputCost: 5.50,
 outputCost: 9.80,
 totalCost: 15.30,
 pctOfSpend: 0.5,
 },
 {
 id: "c7",
 model: "Claude Haiku 3.5",
 provider: "Anthropic",
 providerBadge: "bg-orange-400/10 text-orange-400",
 requestsToday: 22100,
 inputTokens: 1.5,
 outputTokens: 0.7,
 inputCost: 3.75,
 outputCost: 12.50,
 totalCost: 16.25,
 pctOfSpend: 0.6,
 },
 {
 id: "c8",
 model: "Llama 3.1 405B",
 provider: "Meta",
 providerBadge: "bg-indigo-400/10 text-indigo-400",
 requestsToday: 3400,
 inputTokens: 0.6,
 outputTokens: 0.3,
 inputCost: 2.10,
 outputCost: 4.50,
 totalCost: 6.60,
 pctOfSpend: 0.2,
 },
];

const TOTAL_DAILY_COST = 2847.50;

// 30-day mock daily cost data
const DAILY_TREND: DailyDataPoint[] = Array.from({ length: 30 }, (_, i) => {
 const base = 2200 + Math.sin(i * 0.4) * 400;
 const noise = (Math.random() - 0.5) * 300;
 return { day: i + 1, cost: Math.round(base + noise) };
});

const PROVIDER_SHARES: ProviderShare[] = [
 { name: "Anthropic", pct: 45, color: "#f97316" },
 { name: "OpenAI", pct: 35, color: "#14b8a6" },
 { name: "Google", pct: 15, color: "#3b82f6" },
 { name: "Others", pct: 5, color: "#6366f1" },
];

const MONTHLY_BARS: MonthlyBar[] = [
 { month: "Apr", spend: 68200, isCurrent: false },
 { month: "May", spend: 74500, isCurrent: false },
 { month: "Jun", spend: 71300, isCurrent: false },
 { month: "Jul", spend: 80100, isCurrent: false },
 { month: "Aug", spend: 85425, isCurrent: false },
 { month: "Sep", spend: 85425, isCurrent: true },
];

const BUDGET_TARGET = 100000;
const MAX_BAR = 100000;

const DATE_OPTIONS = ["Last 7 Days", "Last 30 Days", "This Month", "Last Month"];

// ── SVG helpers ─────────────────────────────────────────────────────────────

function AreaChart({ data }: { data: DailyDataPoint[] }) {
 const w = 580;
 const h = 180;
 const pad = { t: 10, r: 10, b: 25, l: 40 };
 const iw = w - pad.l - pad.r;
 const ih = h - pad.t - pad.b;
 const [tooltip, setTooltip] = useState<{ x: number; y: number; cost: number; day: number } | null>(null);

 const maxVal = Math.max(...data.map((d) => d.cost));
 const minVal = Math.min(...data.map((d) => d.cost));
 const range = maxVal - minVal || 1;

 const xStep = iw / (data.length - 1);

 const points = data.map(
 (d, i) => ({
 x: pad.l + i * xStep,
 y: pad.t + ih - ((d.cost - minVal) / range) * ih,
 })
 );

 const areaD = `M${points[0].x},${pad.t + ih} ` +
 points.map((p) => `L${p.x},${p.y}`).join(" ") +
 ` L${points[points.length - 1].x},${pad.t + ih} Z`;

 const lineD = points.map((p, i) => `${i === 0 ? "M" : "L"}${p.x},${p.y}`).join(" ");

 // Y-axis ticks
 const yTicks = [minVal, Math.round((minVal + maxVal) / 2), maxVal];

 return (
 <svg viewBox={`0 0 ${w} ${h}`} className="w-full h-auto">
 <defs>
 <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
 <stop offset="0%" stopColor="#6366f1" stopOpacity={0.35} />
 <stop offset="100%" stopColor="#6366f1" stopOpacity={0.02} />
 </linearGradient>
 </defs>

 {/* Grid lines */}
 {yTicks.map((tick) => {
 const y = pad.t + ih - ((tick - minVal) / range) * ih;
 return (
 <g key={tick}>
 <line x1={pad.l} y1={y} x2={w - pad.r} y2={y} stroke="#334155" strokeDasharray="3 3" />
 <text x={pad.l - 6} y={y + 3} fill="#94a3b8" fontSize="9" textAnchor="end">
 ${(tick / 1000).toFixed(0)}k
 </text>
 </g>
 );
 })}

 <path d={areaD} fill="url(#areaGrad)" />
 <path d={lineD} fill="none" stroke="#6366f1" strokeWidth="1.8" />

 {/* Interactive data points */}
 {points.map((p, i) => (
 <g key={i}>
 <rect
 x={p.x - 8}
 y={p.y - 8}
 width={16}
 height={16}
 fill="transparent"
 onMouseEnter={() => setTooltip({ x: p.x, y: p.y - 12, cost: data[i].cost, day: data[i].day })}
 onMouseMove={(e) => {
 const svgRect = e.currentTarget.ownerSVGElement?.getBoundingClientRect();
 if (svgRect) {
 const scaleX = w / svgRect.width;
 const scaleY = h / svgRect.height;
 setTooltip({
 x: (p.x) * scaleX,
 y: (p.y - 14) * scaleY,
 cost: data[i].cost,
 day: data[i].day,
 });
 }
 }}
 onMouseLeave={() => setTooltip(null)}
 style={{ cursor: "pointer" }}
 />
 <circle cx={p.x} cy={p.y} r={2.5} fill="#6366f1" stroke="#1a1d2e" strokeWidth={1.5} />
 </g>
 ))}

 {/* Tooltip */}
 {tooltip && (
 <g transform={`translate(${tooltip.x},${tooltip.y})`}>
 <rect
 x={-38}
 y={-28}
 width={76}
 height={26}
 rx={4}
 fill="#1e293b"
 stroke="#6366f1"
 strokeWidth={1}
 />
 <text x={0} y={-12} fill="#e2e8f0" fontSize="9" textAnchor="middle" fontWeight="600">
 Day {tooltip.day}
 </text>
 <text x={0} y={-2} fill="#6366f1" fontSize="9" textAnchor="middle">
 ${tooltip.cost.toLocaleString()}
 </text>
 </g>
 )}

 {/* X-axis day labels */}
 {points.filter((_, i) => i % 5 === 0).map((p) => (
 <text key={p.x} x={p.x} y={h - 5} fill="#64748b" fontSize="9" textAnchor="middle">
 {data[Math.round((p.x - pad.l) / xStep)]?.day}
 </text>
 ))}
 </svg>
 );
}

// ── Component ───────────────────────────────────────────────────────────────

const CostPage: React.FC = () => {
 const router = useRouter();
 const [dateRange, setDateRange] = useState("Last 30 Days");

 const fmt = (n: number) =>
 n >= 1_000_000
 ? `$${(n / 1_000_000).toFixed(1)}M`
 : n >= 1_000
 ? `$${(n / 1_000).toFixed(1)}k`
 : `$${n.toFixed(2)}`;

 const handleExport = () => {
 const headers = [
 "Model",
 "Provider",
 "Requests Today",
 "Input Tokens (M)",
 "Output Tokens (M)",
 "Input Cost ($)",
 "Output Cost ($)",
 "Total Cost ($)",
 "% of Spend",
 ];
 const rows = COST_ROWS.map((r) =>
 [
 r.model,
 r.provider,
 r.requestsToday.toLocaleString(),
 r.inputTokens,
 r.outputTokens,
 r.inputCost.toFixed(2),
 r.outputCost.toFixed(2),
 r.totalCost.toFixed(2),
 `${r.pctOfSpend}%`,
 ].join(",")
 );
 const csv = [headers.join(","), ...rows].join("\n");
 const blob = new Blob([csv], { type: "text/csv" });
 const url = URL.createObjectURL(blob);
 const a = document.createElement("a");
 a.href = url;
 a.download = "cost-breakdown.csv";
 a.click();
 URL.revokeObjectURL(url);
 };

 const handleNavigate = (item: string) => {
 const navHref: Record<string, string> = {
 overview: "/",
 teams: "/teams",
 tasks: "/tasks",
 agents: "/agents",
 projects: "/projects",
 activity: "/activity",
 settings: "/settings",
 sprints: "/sprints",
 };
 router.push(navHref[item] || "/");
 };

 return (
 <Layout activeNav="cost" onNavigate={handleNavigate}>
 <div className="px-6 py-8 space-y-8">

 {/* ── Page Header ─────────────────────────────────────────────── */}
 <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
 <div>
 <h1 className="text-2xl font-bold tracking-tight">Cost &amp; Usage</h1>
 <p className="text-sm text-slate-400 mt-1">
 Track spending and usage metrics across all AI models and providers.
 </p>
 </div>
 <div className="flex items-center gap-3">
 <div className="relative">
 <FaCalendarAlt className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs" />
 <select
 value={dateRange}
 onChange={(e) => setDateRange(e.target.value)}
 className="bg-[#1a1d2e] border border-slate-700 text-slate-200 text-sm rounded-lg pl-9 pr-8 py-2.5 outline-none appearance-none cursor-pointer hover:border-slate-600 transition-colors"
 >
 {DATE_OPTIONS.map((opt) => (
 <option key={opt} value={opt}>{opt}</option>
 ))}
 </select>
 </div>
 <button
 onClick={handleExport}
 className="flex items-center gap-2 bg-indigo-500 hover:bg-indigo-600 text-white text-sm font-medium px-4 py-2.5 rounded-lg transition-colors"
 >
 <FaDownload className="text-xs" />
 Export CSV
 </button>
 </div>
 </div>

 {/* ── Stat Cards ──────────────────────────────────────────────── */}
 <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
 {/* Daily Cost */}
 <div className="bg-[#1a1d2e] border border-slate-800 rounded-xl p-5">
 <div className="flex items-center justify-between mb-3">
 <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">
 Daily Cost
 </span>
 <div className="w-8 h-8 bg-indigo-500/10 rounded-lg flex items-center justify-center">
 <FaDollarSign className="text-indigo-400 text-sm" />
 </div>
 </div>
 <div className="text-2xl font-bold">$2,847.50</div>
 <div className="flex items-center gap-1 mt-2">
 <FaArrowUp className="text-emerald-400 text-[10px]" />
 <span className="text-xs font-medium text-emerald-400">+12.3%</span>
 <span className="text-xs text-slate-500">vs yesterday</span>
 </div>
 </div>

 {/* Monthly Spend */}
 <div className="bg-[#1a1d2e] border border-slate-800 rounded-xl p-5">
 <div className="flex items-center justify-between mb-3">
 <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">
 Monthly Spend
 </span>
 <div className="w-8 h-8 bg-orange-500/10 rounded-lg flex items-center justify-center">
 <FaChartBar className="text-orange-400 text-sm" />
 </div>
 </div>
 <div className="text-2xl font-bold">$85,425</div>
 <div className="flex items-center gap-1 mt-2">
 <FaArrowUp className="text-emerald-400 text-[10px]" />
 <span className="text-xs font-medium text-emerald-400">+8.2%</span>
 <span className="text-xs text-slate-500">vs budget</span>
 </div>
 </div>

 {/* Tokens This Month */}
 <div className="bg-[#1a1d2e] border border-slate-800 rounded-xl p-5">
 <div className="flex items-center justify-between mb-3">
 <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">
 Tokens This Month
 </span>
 <div className="w-8 h-8 bg-blue-500/10 rounded-lg flex items-center justify-center">
 <FaChartBar className="text-blue-400 text-sm" />
 </div>
 </div>
 <div className="text-2xl font-bold">2.4M</div>
 <div className="flex items-center gap-1 mt-2">
 <span className="text-xs text-slate-500">78% of monthly budget</span>
 <FaCheckCircle className="text-emerald-400 text-[10px] ml-auto" />
 </div>
 <div className="mt-2 h-1.5 bg-slate-700 rounded-full overflow-hidden">
 <div className="h-full bg-blue-400 rounded-full" style={{ width: "78%" }} />
 </div>
 </div>

 {/* Active Tasks */}
 <div className="bg-[#1a1d2e] border border-slate-800 rounded-xl p-5">
 <div className="flex items-center justify-between mb-3">
 <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">
 Active Tasks
 </span>
 <div className="w-8 h-8 bg-emerald-500/10 rounded-lg flex items-center justify-center">
 <FaCheckCircle className="text-emerald-400 text-sm" />
 </div>
 </div>
 <div className="text-2xl font-bold">156</div>
 <div className="flex items-center gap-1 mt-2">
 <FaArrowDown className="text-orange-400 text-[10px]" />
 <span className="text-xs font-medium text-orange-400">-5</span>
 <span className="text-xs text-slate-500">from last week</span>
 </div>
 </div>
 </div>

 {/* ── Cost Breakdown Table ────────────────────────────────────── */}
 <div>
 <h2 className="text-lg font-semibold mb-4">Cost Breakdown by Model</h2>
 <div className="bg-[#1a1d2e] border border-slate-800 rounded-xl overflow-hidden">
 <div className="overflow-x-auto">
 <table className="w-full text-sm">
 <thead>
 <tr className="border-b border-slate-700/60">
 {["Model", "Provider", "Requests Today", "Input Tokens", "Output Tokens", "Input Cost", "Output Cost", "Total Cost", "% of Spend"].map(
 (h) => (
 <th
 key={h}
 className="text-left text-xs font-medium text-slate-400 uppercase tracking-wider px-4 py-3 whitespace-nowrap"
 >
 {h}
 </th>
 )
 )}
 </tr>
 </thead>
 <tbody className="divide-y divide-slate-800">
 {COST_ROWS.map((row) => (
 <tr key={row.id} className="hover:bg-slate-800/30 transition-colors">
 <td className="px-4 py-3 font-medium text-white whitespace-nowrap">
 {row.model}
 </td>
 <td className="px-4 py-3 whitespace-nowrap">
 <span
 className={`text-xs font-medium px-2 py-0.5 rounded-full ${row.providerBadge}`}
 >
 {row.provider}
 </span>
 </td>
 <td className="px-4 py-3 text-slate-300 tabular-nums">
 {row.requestsToday.toLocaleString()}
 </td>
 <td className="px-4 py-3 text-slate-300 tabular-nums">
 {row.inputTokens}M
 </td>
 <td className="px-4 py-3 text-slate-300 tabular-nums">
 {row.outputTokens}M
 </td>
 <td className="px-4 py-3 text-slate-300 tabular-nums">
 ${row.inputCost.toFixed(2)}
 </td>
 <td className="px-4 py-3 text-slate-300 tabular-nums">
 ${row.outputCost.toFixed(2)}
 </td>
 <td className="px-4 py-3 font-semibold text-white tabular-nums">
 ${row.totalCost.toFixed(2)}
 </td>
 <td className="px-4 py-3 min-w-[140px]">
 <div className="flex items-center gap-2">
 <div className="flex-1 h-2 bg-slate-700 rounded-full overflow-hidden">
 <div
 className="h-full bg-indigo-500 rounded-full"
 style={{ width: `${row.pctOfSpend}%` }}
 />
 </div>
 <span className="text-xs text-slate-400 tabular-nums w-10 text-right">
 {row.pctOfSpend}%
 </span>
 </div>
 </td>
 </tr>
 ))}
 </tbody>
 {/* Totals row */}
 <tfoot>
 <tr className="border-t-2 border-slate-700 bg-slate-800/40">
 <td className="px-4 py-3 font-bold text-white" colSpan={5}>
 Total
 </td>
 <td className="px-4 py-3 font-semibold text-slate-200 tabular-nums">
 $728.75
 </td>
 <td className="px-4 py-3 font-semibold text-slate-200 tabular-nums">
 $2,118.75
 </td>
 <td className="px-4 py-3 font-bold text-white tabular-nums">
 $2,847.50
 </td>
 <td className="px-4 py-3">
 <span className="text-xs font-bold text-white">100%</span>
 </td>
 </tr>
 </tfoot>
 </table>
 </div>
 </div>
 </div>

 {/* ── Bottom Charts Row ───────────────────────────────────────── */}
 <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">

 {/* Daily Cost Trend */}
 <div className="bg-[#1a1d2e] border border-slate-800 rounded-xl p-5">
 <h3 className="text-sm font-semibold text-white mb-1">Daily Cost Trend</h3>
 <p className="text-xs text-slate-500 mb-4">Last 30 days</p>
 <AreaChart data={DAILY_TREND} />
 </div>

 {/* Spend by Provider */}
 <div className="bg-[#1a1d2e] border border-slate-800 rounded-xl p-5">
 <h3 className="text-sm font-semibold text-white mb-1">Spend by Provider</h3>
 <p className="text-xs text-slate-500 mb-5">Distribution this month</p>
 <InteractiveDonut
 segments={PROVIDER_SHARES.map(p => ({ label: p.name, value: p.pct, color: p.color }))}
 size={120}
 strokeWidth={16}
 centerLabel="Spend"
 centerValue="$85K"
 showLegend={true}
 legendLayout="vertical"
 />
 </div>

 {/* Monthly Budget */}
 <div className="bg-[#1a1d2e] border border-slate-800 rounded-xl p-5">
 <h3 className="text-sm font-semibold text-white mb-1">Monthly Budget</h3>
 <p className="text-xs text-slate-500 mb-5">Last 6 months vs $100K budget</p>
 <div className="flex items-end gap-3 h-[160px]">
 {MONTHLY_BARS.map((bar) => {
 const heightPct = (bar.spend / MAX_BAR) * 100;
 return (
 <div key={bar.month} className="flex-1 flex flex-col items-center gap-2">
 <div className="relative w-full flex justify-center" style={{ height: 120 }}>
 {/* Budget target line */}
 <div
 className="absolute left-0 right-0 border-t border-dashed border-slate-600 z-10"
 style={{ bottom: `${(BUDGET_TARGET / MAX_BAR) * 120}px` }}
 >
 <span className="absolute -top-3 left-1/2 -translate-x-1/2 text-[9px] text-slate-500 whitespace-nowrap">
 $100K
 </span>
 </div>
 <div
 className={`w-full max-w-[32px] rounded-t-md transition-all duration-500 ${
 bar.isCurrent
 ? "bg-indigo-500"
 : "bg-indigo-500/40 hover:bg-indigo-500/60"
 }`}
 style={{ height: `${heightPct}%`, position: "absolute", bottom: 0 }}
 />
 </div>
 <span
 className={`text-xs ${
 bar.isCurrent ? "text-indigo-400 font-semibold" : "text-slate-400"
 }`}
 >
 {bar.month}
 </span>
 </div>
 );
 })}
 </div>
 </div>
 </div>
 </div>
 </Layout>
 );
};

export default CostPage;
