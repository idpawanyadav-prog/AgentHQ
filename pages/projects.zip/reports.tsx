'use client';

import React, { useState } from "react";
import { useRouter } from "next/router";
import Layout from "@/components/Layout";
import StatCard from "@/components/StatCard";
import {
 FaChartBar,
 FaFilter,
 FaDownload,
 FaFileAlt,
 FaCalendarAlt,
 FaUsers,
 FaCheckCircle,
 FaExclamationTriangle,
 FaArrowUp,
 FaArrowDown,
 FaEye,
 FaSearch,
} from "react-icons/fa";

// ── Types ────────────────────────────────────────────────────────────────────

interface StatBlock {
 label: string;
 value: string;
 sub: string;
 up?: boolean;
}

interface TeamRankRow {
 rank: number;
 name: string;
 completed: number;
 avgTime: string;
 quality: number;
 color: string;
 miniBars: number[];
}

interface BlockerRow {
 id: string;
 title: string;
 severity: "high" | "medium" | "low";
 assignee: string;
 since: string;
}

interface RecentReport {
 id: string;
 name: string;
 type: string;
 date: string;
 status: "completed" | "pending" | "failed";
}

// ── Sample Data ──────────────────────────────────────────────────────────────

const REPORT_TYPES = [
 "Sprint Report",
 "Team Performance",
 "Code Quality",
 "Task Analytics",
 "Budget Report",
];

const DATE_RANGES = ["Last 7 Days", "Last 30 Days", "Last Quarter", "Year to Date", "Custom"];
const TEAMS = ["All Teams", "Team Alpha", "Team Beta", "Team Gamma", "Team Delta"];

const STATS: StatBlock[] = [
 { label: "Reports Generated", value: "24", sub: "this quarter", up: true },
 { label: "Avg Sprint Velocity", value: "47 pts", sub: "+8% vs last quarter", up: true },
 { label: "Code Review Coverage", value: "87%", sub: "+3% improvement", up: true },
 { label: "Avg Lead Time", value: "2.3 days", sub: "-12% improvement", up: false },
];

const TABS = ["Sprint Reports", "Team Performance", "Code Quality", "Task Analytics", "Budget Reports"] as const;

type Tab = typeof TABS[number];

// Sprint report data
const SPRINT_DATA = {
 name: "Sprint 24 — E-commerce Platform",
 dateRange: "Apr 15 – Apr 30, 2025",
 totalPoints: 50,
 completedPoints: 45,
 burndown: [
 { day: 1, ideal: 50, actual: 50 },
 { day: 2, ideal: 45, actual: 48 },
 { day: 3, ideal: 40, actual: 46 },
 { day: 4, ideal: 35, actual: 42 },
 { day: 5, ideal: 30, actual: 39 },
 { day: 6, ideal: 25, actual: 34 },
 { day: 7, ideal: 20, actual: 29 },
 { day: 8, ideal: 15, actual: 22 },
 { day: 9, ideal: 10, actual: 15 },
 { day: 10, ideal: 5, actual: 7 },
 { day: 11, ideal: 0, actual: 3 },
 { day: 12, ideal: 0, actual: 0 },
 { day: 13, ideal: 0, actual: 0 },
 { day: 14, ideal: 0, actual: 0 },
 ],
 velocityComparison: [
 { team: "Team Alpha", value: 52, color: "bg-blue-500" },
 { team: "Team Beta", value: 47, color: "bg-purple-500" },
 { team: "Team Gamma", value: 43, color: "bg-green-500" },
 { team: "Team Delta", value: 38, color: "bg-orange-500" },
 ],
 blockers: [
 { id: "BLK-001", title: "Payment gateway timeout", severity: "high" as const, assignee: "Casey Lee", since: "Apr 22" },
 { id: "BLK-002", title: "Missing API credentials for staging", severity: "medium" as const, assignee: "Quinn Park", since: "Apr 23" },
 { id: "BLK-003", title: "Design assets not finalized", severity: "low" as const, assignee: "Riley Brown", since: "Apr 24" },
 { id: "BLK-004", title: "Third-party auth rate limit", severity: "high" as const, assignee: "Sam Rivera", since: "Apr 22" },
 ],
};

// Team Performance data
const TEAM_RANKINGS: TeamRankRow[] = [
 { rank: 1, name: "Team Alpha", completed: 87, avgTime: "1.8 days", quality: 96, color: "bg-blue-500", miniBars: [70, 80, 75, 90, 85, 95, 88] },
 { rank: 2, name: "Team Beta", completed: 82, avgTime: "2.1 days", quality: 92, color: "bg-purple-500", miniBars: [60, 72, 78, 80, 85, 82, 88] },
 { rank: 3, name: "Team Gamma", completed: 76, avgTime: "2.4 days", quality: 89, color: "bg-green-500", miniBars: [55, 65, 70, 75, 72, 80, 78] },
 { rank: 4, name: "Team Delta", completed: 71, avgTime: "2.8 days", quality: 85, color: "bg-orange-500", miniBars: [50, 58, 62, 68, 70, 73, 72] },
 { rank: 5, name: "Team Epsilon", completed: 65, avgTime: "3.1 days", quality: 80, color: "bg-pink-500", miniBars: [45, 50, 55, 60, 62, 65, 66] },
 { rank: 6, name: "Team Zeta", completed: 58, avgTime: "3.5 days", quality: 76, color: "bg-cyan-500", miniBars: [40, 45, 48, 52, 55, 58, 59] },
 { rank: 7, name: "Team Eta", completed: 49, avgTime: "4.0 days", quality: 71, color: "bg-indigo-500", miniBars: [30, 38, 42, 45, 50, 52, 50] },
];

// Code Quality data
const CODE_QUALITY = {
 testCoverage: 87,
 reviewRate: 92,
 bugDensity: 2.3,
 techDebt: "B+",
 trend: [
 { month: "Oct", value: 78 },
 { month: "Nov", value: 80 },
 { month: "Dec", value: 82 },
 { month: "Jan", value: 83 },
 { month: "Feb", value: 85 },
 { month: "Mar", value: 87 },
 ],
};

// Recent Reports data
const RECENT_REPORTS: RecentReport[] = [
 { id: "RPT-001", name: "Sprint 24 Summary", type: "Sprint Report", date: "Apr 30, 2025", status: "completed" },
 { id: "RPT-002", name: "Q1 Team Performance", type: "Team Performance", date: "Apr 28, 2025", status: "completed" },
 { id: "RPT-003", name: "Code Quality Audit", type: "Code Quality", date: "Apr 25, 2025", status: "completed" },
 { id: "RPT-004", name: "Task Velocity Analysis", type: "Task Analytics", date: "Apr 22, 2025", status: "completed" },
 { id: "RPT-005", name: "Budget Forecast Q2", type: "Budget Report", date: "Apr 20, 2025", status: "pending" },
 { id: "RPT-006", name: "Sprint 23 Retrospective", type: "Sprint Report", date: "Apr 15, 2025", status: "completed" },
 { id: "RPT-007", name: "Engineering DORA Metrics", type: "Team Performance", date: "Apr 10, 2025", status: "failed" },
 { id: "RPT-008", name: "Technical Debt Assessment", type: "Code Quality", date: "Apr 5, 2025", status: "completed" },
];

// ── SVG Burndown Chart ────────────────────────────────────────────────────────

function BurndownChart({ data }: { data: typeof SPRINT_DATA["burndown"] }) {
 const [tooltip, setTooltip] = useState<{x:number;y:number;actual:number;ideal:number;day:number}|null>(null);
 const w = 680;
 const h = 280;
 const pad = { top: 20, right: 20, bottom: 36, left: 44 };
 const chartW = w - pad.left - pad.right;
 const chartH = h - pad.top - pad.bottom;
 const maxVal = 55;
 const xStep = chartW / (data.length - 1);

 const toX = (i: number) => pad.left + i * xStep;
 const toY = (v: number) => pad.top + chartH - (v / maxVal) * chartH;

 const actualPath = data.map((d, i) => `${i === 0 ? "M" : "L"}${toX(i).toFixed(1)},${toY(d.actual).toFixed(1)}`).join(" ");
 const idealPath = data.map((d, i) => `${i === 0 ? "M" : "L"}${toX(i).toFixed(1)},${toY(d.ideal).toFixed(1)}`).join(" ");

 const yTicks = [0, 10, 20, 30, 40, 50];

 return (
 <svg viewBox={`0 0 ${w} ${h}`} className="w-full max-w-3xl mx-auto">
 {/* Grid lines */}
 {yTicks.map((tick) => (
 <line key={tick} x1={pad.left} x2={w - pad.right} y1={toY(tick)} y2={toY(tick)} stroke="#1e293b" strokeWidth="1" />
 ))}
 {/* Y-axis labels */}
 {yTicks.map((tick) => (
 <text key={tick} x={pad.left - 8} y={toY(tick) + 4} textAnchor="end" fill="#64748b" fontSize="11">{tick}</text>
 ))}
 {/* X-axis labels */}
 {data.filter((_, i) => i % 2 === 0 || i === data.length - 1).map((d, i) => {
 const idx = data.findIndex((p) => p.day === d.day);
 return (
 <text key={d.day} x={toX(idx)} y={h - 8} textAnchor="middle" fill="#64748b" fontSize="11">D{d.day}</text>
 );
 })}
 {/* Ideal line */}
 <path d={idealPath} fill="none" stroke="#334155" strokeWidth="2" strokeDasharray="6,4" />
 {/* Actual line */}
 <path d={actualPath} fill="none" stroke="#3b82f6" strokeWidth="2.5" />
 {/* Data points - actual */}
 {data.map((d, i) => (
 <circle
 key={`a-${d.day}`}
 cx={toX(i)}
 cy={toY(d.actual)}
 r="4"
 fill="#3b82f6"
 stroke="#0f1117"
 strokeWidth="2"
 style={{ pointerEvents: "none" }}
 />
 ))}
 {/* Hit-area circles for actual data points */}
 {data.map((d, i) => (
 <circle
 key={`ha-${d.day}`}
 cx={toX(i)}
 cy={toY(d.actual)}
 r="14"
 fill="transparent"
 onMouseEnter={() => setTooltip({ x: toX(i), y: toY(d.actual), actual: d.actual, ideal: d.ideal, day: d.day })}
 onMouseLeave={() => setTooltip(null)}
 />
 ))}
 {/* Data points - ideal */}
 {data.map((d, i) => (
 <circle key={`i-${d.day}`} cx={toX(i)} cy={toY(d.ideal)} r="3" fill="#475569" stroke="#0f1117" strokeWidth="1.5" />
 ))}
 {/* Tooltip */}
 {tooltip && (
 <g>
 <rect x={tooltip.x - 30} y={tooltip.y - 42} width="60" height="34" rx="4" fill="#1e293b" stroke="#334155" strokeWidth="1" />
 <text x={tooltip.x} y={tooltip.y - 26} textAnchor="middle" fill="#94a3b8" fontSize="9">D{tooltip.day}</text>
 <text x={tooltip.x} y={tooltip.y - 14} textAnchor="middle" fill="#3b82f6" fontSize="10" fontWeight="bold">Actual: {tooltip.actual}</text>
 <text x={tooltip.x} y={tooltip.y - 4} textAnchor="middle" fill="#64748b" fontSize="9">Ideal: {tooltip.ideal}</text>
 </g>
 )}
 {/* Legend */}
 <rect x={pad.left} y={4} width="14" height="3" fill="#3b82f6" rx="1" />
 <text x={pad.left + 18} y={8} fill="#94a3b8" fontSize="11">Actual</text>
 <rect x={pad.left + 62} y={4} width="14" height="3" fill="#475569" rx="1" strokeDasharray="3,2" />
 <text x={pad.left + 80} y={8} fill="#94a3b8" fontSize="11">Ideal</text>
 </svg>
 );
}

// ── SVG Trend Chart ──────────────────────────────────────────────────────────

function TrendChart({ data }: { data: typeof CODE_QUALITY["trend"] }) {
 const [tooltip, setTooltip] = useState<{x:number;y:number;value:number;month:string}|null>(null);
 const w = 620;
 const h = 200;
 const pad = { top: 16, right: 20, bottom: 32, left: 40 };
 const chartW = w - pad.left - pad.right;
 const chartH = h - pad.top - pad.bottom;
 const minVal = 75;
 const maxVal = 90;
 const xStep = chartW / (data.length - 1);

 const toX = (i: number) => pad.left + i * xStep;
 const toY = (v: number) => pad.top + chartH - ((v - minVal) / (maxVal - minVal)) * chartH;

 const path = data.map((d, i) => `${i === 0 ? "M" : "L"}${toX(i).toFixed(1)},${toY(d.value).toFixed(1)}`).join(" ");
 const areaPath = path + ` L${toX(data.length - 1).toFixed(1)},${pad.top + chartH} L${toX(0).toFixed(1)},${pad.top + chartH} Z`;

 return (
 <svg viewBox={`0 0 ${w} ${h}`} className="w-full max-w-2xl mx-auto">
 {/* Grid lines */}
 {[75, 80, 85, 90].map((tick) => (
 <line key={tick} x1={pad.left} x2={w - pad.right} y1={toY(tick)} y2={toY(tick)} stroke="#1e293b" strokeWidth="1" />
 ))}
 {/* Y labels */}
 {[75, 80, 85, 90].map((tick) => (
 <text key={tick} x={pad.left - 8} y={toY(tick) + 4} textAnchor="end" fill="#64748b" fontSize="11">{tick}%</text>
 ))}
 {/* Area fill */}
 <path d={areaPath} fill="rgba(59,130,246,0.08)" />
 {/* Trend line */}
 <path d={path} fill="none" stroke="#3b82f6" strokeWidth="2.5" />
 {/* Points */}
 {data.map((d, i) => (
 <circle
 key={d.month}
 cx={toX(i)}
 cy={toY(d.value)}
 r="5"
 fill="#1a1d2e"
 stroke="#3b82f6"
 strokeWidth="2.5"
 style={{ pointerEvents: "none" }}
 />
 ))}
 {/* Hit-area circles for data points */}
 {data.map((d, i) => (
 <circle
 key={`ha-${d.month}`}
 cx={toX(i)}
 cy={toY(d.value)}
 r="14"
 fill="transparent"
 onMouseEnter={() => setTooltip({ x: toX(i), y: toY(d.value), value: d.value, month: d.month })}
 onMouseLeave={() => setTooltip(null)}
 />
 ))}
 {/* Tooltip */}
 {tooltip && (
 <g>
 <rect x={tooltip.x - 28} y={tooltip.y - 40} width="56" height="30" rx="4" fill="#1e293b" stroke="#334155" strokeWidth="1" />
 <text x={tooltip.x} y={tooltip.y - 24} textAnchor="middle" fill="#94a3b8" fontSize="9">{tooltip.month}</text>
 <text x={tooltip.x} y={tooltip.y - 12} textAnchor="middle" fill="#3b82f6" fontSize="10" fontWeight="bold">{tooltip.value}%</text>
 </g>
 )}
 {/* X labels */}
 {data.map((d, i) => (
 <text key={d.month} x={toX(i)} y={h - 10} textAnchor="middle" fill="#64748b" fontSize="11">{d.month}</text>
 ))}
 {/* Value labels on points */}
 {data.map((d, i) => (
 <text key={`v-${d.month}`} x={toX(i)} y={toY(d.value) - 10} textAnchor="middle" fill="#3b82f6" fontSize="11" fontWeight="600">{d.value}%</text>
 ))}
 </svg>
 );
}

// ── Severity Badge ───────────────────────────────────────────────────────────

function SeverityBadge({ severity }: { severity: BlockerRow["severity"] }) {
 const colors: Record<string, string> = {
 high: "bg-red-500/15 text-red-400 border border-red-500/30",
 medium: "bg-yellow-500/15 text-yellow-400 border border-yellow-500/30",
 low: "bg-sky-500/15 text-sky-400 border border-sky-500/30",
 };
 return (
 <span className={`px-2 py-0.5 rounded text-xs font-medium capitalize ${colors[severity]}`}>{severity}</span>
 );
}

// ── Status Badge ─────────────────────────────────────────────────────────────

function StatusBadge({ status }: { status: RecentReport["status"] }) {
 const cfg: Record<string, { bg: string; text: string; label: string }> = {
 completed: { bg: "bg-emerald-500/15", text: "text-emerald-400", label: "Completed" },
 pending: { bg: "bg-yellow-500/15", text: "text-yellow-400", label: "Pending" },
 failed: { bg: "bg-red-500/15", text: "text-red-400", label: "Failed" },
 };
 const c = cfg[status];
 return (
 <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${c.bg} ${c.text}`}>
 <span className="w-1.5 h-1.5 rounded-full bg-current" />
 {c.label}
 </span>
 );
}

// ── Mini Sparkline ────────────────────────────────────────────────────────────

function MiniSparkline({ values, color }: { values: number[]; color: string }) {
 const w = 120;
 const h = 32;
 const max = 100;
 const xStep = w / (values.length - 1);
 const barW = (w / values.length) * 0.6;
 return (
 <svg viewBox={`0 0 ${w} ${h}`} className="w-28 h-8">
 {values.map((v, i) => {
 const barH = (v / max) * (h - 4);
 const x = i * xStep + (xStep - barW) / 2;
 return (
 <rect
 key={i}
 x={x}
 y={h - barH}
 width={barW}
 height={barH}
 fill={color}
 rx="1.5"
 opacity={0.5 + (i / values.length) * 0.5}
 />
 );
 })}
 </svg>
 );
}

// ══════════════════════════════════════════════════════════════════════════════
// Main Page
// ══════════════════════════════════════════════════════════════════════════════

export default function ReportsPage() {
 const [activeTab, setActiveTab] = useState<Tab>("Sprint Reports");
 const [reportType, setReportType] = useState("Sprint Report");
 const [dateRange, setDateRange] = useState("Last 30 Days");
 const [team, setTeam] = useState("All Teams");
 const [searchQuery, setSearchQuery] = useState("");

 const completedPct = Math.round((SPRINT_DATA.completedPoints / SPRINT_DATA.totalPoints) * 100);

 const handleNavigate = (item: string) => {
	 const navHref: Record<string, string> = {
		 overview: "/",
		 teams: "/teams",
		 tasks: "/tasks",
		 agents: "/agents",
		 projects: "/projects",
		 activity: "/activity",
		 settings: "/settings",
		 sprints: "/sprints",
	 };
	 router.push(navHref[item] || "/");
	 };

 return (
 <Layout activeNav="reports" onNavigate={handleNavigate}>
 <div className="px-6 space-y-6 pb-10">
 {/* ── Page Header ─────────────────────────────────────────────── */}
 <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
 <div>
 <h1 className="text-2xl font-bold text-white flex items-center gap-3">
 <FaChartBar className="text-blue-400" />
 Reports
 </h1>
 <p className="text-gray-400 mt-1 text-sm">Generate and view analytics reports</p>
 </div>

 <div className="flex flex-wrap items-center gap-3">
 {/* Report Type */}
 <div className="relative">
 <select
 value={reportType}
 onChange={(e) => setReportType(e.target.value)}
 className="appearance-none bg-[#1a1d2e] border border-slate-700 text-gray-200 rounded-lg pl-3 pr-8 py-2 text-sm focus:outline-none focus:border-blue-500 cursor-pointer"
 >
 {REPORT_TYPES.map((t) => (
 <option key={t} value={t}>{t}</option>
 ))}
 </select>
 <FaFilter className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-500 text-xs pointer-events-none" />
 </div>

 {/* Date Range */}
 <div className="relative">
 <select
 value={dateRange}
 onChange={(e) => setDateRange(e.target.value)}
 className="appearance-none bg-[#1a1d2e] border border-slate-700 text-gray-200 rounded-lg pl-3 pr-8 py-2 text-sm focus:outline-none focus:border-blue-500 cursor-pointer"
 >
 {DATE_RANGES.map((d) => (
 <option key={d} value={d}>{d}</option>
 ))}
 </select>
 <FaCalendarAlt className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-500 text-xs pointer-events-none" />
 </div>

 {/* Team */}
 <div className="relative">
 <select
 value={team}
 onChange={(e) => setTeam(e.target.value)}
 className="appearance-none bg-[#1a1d2e] border border-slate-700 text-gray-200 rounded-lg pl-3 pr-8 py-2 text-sm focus:outline-none focus:border-blue-500 cursor-pointer"
 >
 {TEAMS.map((t) => (
 <option key={t} value={t}>{t}</option>
 ))}
 </select>
 <FaUsers className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-500 text-xs pointer-events-none" />
 </div>

 {/* Generate Button */}
 <button className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg px-4 py-2 text-sm font-medium transition-colors">
 <FaFileAlt className="text-xs" />
 Generate Report
 </button>
 </div>
 </div>

 {/* ── Stat Cards ───────────────────────────────────────────────── */}
 <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
 {STATS.map((s) => (
 <div key={s.label} className="bg-[#1a1d2e] border border-slate-700/60 rounded-xl p-5">
 <p className="text-gray-400 text-xs uppercase tracking-wider mb-2">{s.label}</p>
 <p className="text-2xl font-bold text-white">{s.value}</p>
 <p className={`text-xs mt-1 flex items-center gap-1 ${s.up ? "text-emerald-400" : "text-sky-400"}`}>
 {s.up ? <FaArrowUp className="text-[10px]" /> : <FaArrowDown className="text-[10px]" />}
 {s.sub}
 </p>
 </div>
 ))}
 </div>

 {/* ── Tab Bar ─────────────────────────────────────────────────── */}
 <div className="flex flex-wrap gap-1 border-b border-slate-700/60">
 {TABS.map((tab) => (
 <button
 key={tab}
 onClick={() => setActiveTab(tab)}
 className={`px-4 py-2.5 text-sm font-medium transition-colors border-b-2 -mb-px ${
 activeTab === tab
 ? "text-blue-400 border-blue-500"
 : "text-gray-400 border-transparent hover:text-gray-200 hover:border-slate-600"
 }`}
 >
 {tab}
 </button>
 ))}
 </div>

 {/* ── Content Area ────────────────────────────────────────────── */}
 <div className="bg-[#1a1d2e] border border-slate-700/60 rounded-xl p-6">
 {/* ── Sprint Reports Tab ─────────────────────────────────────── */}
 {activeTab === "Sprint Reports" && (
 <div className="space-y-6">
 <div>
 <h3 className="text-white font-semibold text-lg">{SPRINT_DATA.name}</h3>
 <p className="text-gray-400 text-sm mt-1 flex items-center gap-2">
 <FaCalendarAlt className="text-xs text-gray-500" />
 {SPRINT_DATA.dateRange}
 </p>
 </div>

 {/* Story Points Summary */}
 <div className="flex items-center gap-4">
 <div className="flex-1">
 <div className="flex justify-between text-sm mb-1.5">
 <span className="text-gray-300">Story Points</span>
 <span className="text-gray-400">
 {SPRINT_DATA.completedPoints} of {SPRINT_DATA.totalPoints} completed
 </span>
 </div>
 <div className="w-full bg-slate-700/50 rounded-full h-2.5">
 <div
 className="bg-blue-500 rounded-full h-2.5 transition-all"
 style={{ width: `${completedPct}%` }}
 />
 </div>
 <p className="text-blue-400 text-xs mt-1.5 font-medium">{completedPct}% completion rate</p>
 </div>
 </div>

 {/* Burndown Chart */}
 <div>
 <h4 className="text-gray-300 text-sm font-medium mb-3">Sprint Burndown</h4>
 <div className="bg-[#0f1117] rounded-lg p-4 border border-slate-700/40">
 <BurndownChart data={SPRINT_DATA.burndown} />
 </div>
 </div>

 {/* Velocity Comparison */}
 <div>
 <h4 className="text-gray-300 text-sm font-medium mb-4">Team Velocity Comparison</h4>
 <div className="space-y-3">
 {SPRINT_DATA.velocityComparison.map((item) => {
 const maxV = Math.max(...SPRINT_DATA.velocityComparison.map((v) => v.value));
 const pct = (item.value / maxV) * 100;
 return (
 <div key={item.team} className="flex items-center gap-3">
 <span className="text-gray-400 text-sm w-28 shrink-0">{item.team}</span>
 <div className="flex-1 bg-slate-700/30 rounded-full h-6 overflow-hidden">
 <div
 className={`${item.color} h-full rounded-full flex items-center justify-end pr-2 transition-all`}
 style={{ width: `${pct}%` }}
 >
 <span className="text-white text-xs font-semibold">{item.value}</span>
 </div>
 </div>
 </div>
 );
 })}
 </div>
 </div>

 {/* Blockers Table */}
 <div>
 <h4 className="text-gray-300 text-sm font-medium mb-3 flex items-center gap-2">
 <FaExclamationTriangle className="text-yellow-400 text-xs" />
 Active Blockers
 </h4>
 <div className="overflow-x-auto">
 <table className="w-full text-sm">
 <thead>
 <tr className="text-gray-500 text-xs uppercase border-b border-slate-700/60">
 <th className="text-left py-2.5 px-3 font-medium">ID</th>
 <th className="text-left py-2.5 px-3 font-medium">Title</th>
 <th className="text-left py-2.5 px-3 font-medium">Severity</th>
 <th className="text-left py-2.5 px-3 font-medium">Assignee</th>
 <th className="text-left py-2.5 px-3 font-medium">Since</th>
 </tr>
 </thead>
 <tbody>
 {SPRINT_DATA.blockers.map((b) => (
 <tr key={b.id} className="border-b border-slate-700/30 hover:bg-slate-800/30 transition-colors">
 <td className="py-2.5 px-3 text-gray-400 font-mono text-xs">{b.id}</td>
 <td className="py-2.5 px-3 text-gray-200">{b.title}</td>
 <td className="py-2.5 px-3"><SeverityBadge severity={b.severity} /></td>
 <td className="py-2.5 px-3 text-gray-400">{b.assignee}</td>
 <td className="py-2.5 px-3 text-gray-500">{b.since}</td>
 </tr>
 ))}
 </tbody>
 </table>
 </div>
 </div>
 </div>
 )}

 {/* ── Team Performance Tab ───────────────────────────────────── */}
 {activeTab === "Team Performance" && (
 <div className="space-y-6">
 <h3 className="text-white font-semibold text-lg">Team Performance Overview</h3>

 {/* 3 Stat Boxes */}
 <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
 <div className="bg-[#0f1117] border border-slate-700/40 rounded-xl p-5">
 <p className="text-gray-400 text-xs uppercase tracking-wider mb-2">Tasks Completed</p>
 <p className="text-3xl font-bold text-white">1,247</p>
 <p className="text-emerald-400 text-xs mt-1 flex items-center gap-1">
 <FaArrowUp className="text-[10px]" /> +12% vs last month
 </p>
 </div>
 <div className="bg-[#0f1117] border border-slate-700/40 rounded-xl p-5">
 <p className="text-gray-400 text-xs uppercase tracking-wider mb-2">Avg Completion Rate</p>
 <p className="text-3xl font-bold text-white">89.4%</p>
 <p className="text-emerald-400 text-xs mt-1 flex items-center gap-1">
 <FaArrowUp className="text-[10px]" /> +5.2% vs last month
 </p>
 </div>
 <div className="bg-[#0f1117] border border-slate-700/40 rounded-xl p-5">
 <p className="text-gray-400 text-xs uppercase tracking-wider mb-2">On-Time Delivery</p>
 <p className="text-3xl font-bold text-white">94.1%</p>
 <p className="text-emerald-400 text-xs mt-1 flex items-center gap-1">
 <FaArrowUp className="text-[10px]" /> +2.1% vs last month
 </p>
 </div>
 </div>

 {/* Team Ranking Table */}
 <div>
 <h4 className="text-gray-300 text-sm font-medium mb-4">Team Rankings</h4>
 <div className="overflow-x-auto">
 <table className="w-full text-sm">
 <thead>
 <tr className="text-gray-500 text-xs uppercase border-b border-slate-700/60">
 <th className="text-left py-2.5 px-3 font-medium w-12">Rank</th>
 <th className="text-left py-2.5 px-3 font-medium">Team</th>
 <th className="text-left py-2.5 px-3 font-medium">Completed</th>
 <th className="text-left py-2.5 px-3 font-medium">Avg Time</th>
 <th className="text-left py-2.5 px-3 font-medium">Quality</th>
 <th className="text-left py-2.5 px-3 font-medium w-36">Trend</th>
 </tr>
 </thead>
 <tbody>
 {TEAM_RANKINGS.map((t) => (
 <tr key={t.name} className="border-b border-slate-700/30 hover:bg-slate-800/30 transition-colors">
 <td className="py-3 px-3">
 <span className={`inline-flex items-center justify-center w-7 h-7 rounded-full text-xs font-bold ${
 t.rank === 1 ? "bg-yellow-500/20 text-yellow-400" :
 t.rank === 2 ? "bg-gray-400/20 text-gray-300" :
 t.rank === 3 ? "bg-orange-500/20 text-orange-400" :
 "bg-slate-700/50 text-gray-400"
 }`}>
 {t.rank}
 </span>
 </td>
 <td className="py-3 px-3">
 <div className="flex items-center gap-2.5">
 <span className={`w-2.5 h-2.5 rounded-full ${t.color}`} />
 <span className="text-gray-200 font-medium">{t.name}</span>
 </div>
 </td>
 <td className="py-3 px-3 text-gray-300">{t.completed}</td>
 <td className="py-3 px-3 text-gray-400">{t.avgTime}</td>
 <td className="py-3 px-3">
 <div className="flex items-center gap-2">
 <span className="text-gray-300">{t.quality}%</span>
 <div className="w-16 bg-slate-700/40 rounded-full h-1.5">
 <div className="bg-emerald-500 rounded-full h-1.5" style={{ width: `${t.quality}%` }} />
 </div>
 </div>
 </td>
 <td className="py-3 px-3">
 <MiniSparkline values={t.miniBars} color={t.color.replace("bg-", "#")} />
 </td>
 </tr>
 ))}
 </tbody>
 </table>
 </div>
 </div>
 </div>
 )}

 {/* ── Code Quality Tab ───────────────────────────────────────── */}
 {activeTab === "Code Quality" && (
 <div className="space-y-6">
 <h3 className="text-white font-semibold text-lg">Code Quality Metrics</h3>

 {/* 4 Metric Cards */}
 <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
 <div className="bg-[#0f1117] border border-slate-700/40 rounded-xl p-5 text-center">
 <FaCheckCircle className="text-emerald-400 text-2xl mx-auto mb-2" />
 <p className="text-3xl font-bold text-white">{CODE_QUALITY.testCoverage}%</p>
 <p className="text-gray-400 text-xs mt-1">Test Coverage</p>
 <p className="text-emerald-400 text-xs mt-1">+2.1% this sprint</p>
 </div>
 <div className="bg-[#0f1117] border border-slate-700/40 rounded-xl p-5 text-center">
 <FaUsers className="text-blue-400 text-2xl mx-auto mb-2" />
 <p className="text-3xl font-bold text-white">{CODE_QUALITY.reviewRate}%</p>
 <p className="text-gray-400 text-xs mt-1">Code Review Rate</p>
 <p className="text-emerald-400 text-xs mt-1">+1.4% this sprint</p>
 </div>
 <div className="bg-[#0f1117] border border-slate-700/40 rounded-xl p-5 text-center">
 <FaExclamationTriangle className="text-yellow-400 text-2xl mx-auto mb-2" />
 <p className="text-3xl font-bold text-white">{CODE_QUALITY.bugDensity}/kloc</p>
 <p className="text-gray-400 text-xs mt-1">Bug Density</p>
 <p className="text-emerald-400 text-xs mt-1">-0.3 improvement</p>
 </div>
 <div className="bg-[#0f1117] border border-slate-700/40 rounded-xl p-5 text-center">
 <FaChartBar className="text-purple-400 text-2xl mx-auto mb-2" />
 <p className="text-3xl font-bold text-white">{CODE_QUALITY.techDebt}</p>
 <p className="text-gray-400 text-xs mt-1">Tech Debt Score</p>
 <p className="text-emerald-400 text-xs mt-1">Up from C+</p>
 </div>
 </div>

 {/* Trend Chart */}
 <div>
 <h4 className="text-gray-300 text-sm font-medium mb-1">Test Coverage Trend (6 Months)</h4>
 <p className="text-gray-500 text-xs mb-4">Steady improvement in test coverage across all projects</p>
 <div className="bg-[#0f1117] rounded-lg p-4 border border-slate-700/40">
 <TrendChart data={CODE_QUALITY.trend} />
 </div>
 </div>
 </div>
 )}

 {/* ── Task Analytics Tab ─────────────────────────────────────── */}
 {activeTab === "Task Analytics" && (
 <div className="space-y-6">
 <h3 className="text-white font-semibold text-lg">Task Analytics</h3>

 <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
 <div className="bg-[#0f1117] border border-slate-700/40 rounded-xl p-5">
 <p className="text-gray-400 text-xs uppercase tracking-wider mb-2">Total Tasks</p>
 <p className="text-3xl font-bold text-white">342</p>
 <p className="text-gray-500 text-xs mt-1">Across 5 active sprints</p>
 </div>
 <div className="bg-[#0f1117] border border-slate-700/40 rounded-xl p-5">
 <p className="text-gray-400 text-xs uppercase tracking-wider mb-2">Avg Completion Time</p>
 <p className="text-3xl font-bold text-white">2.8 days</p>
 <p className="text-emerald-400 text-xs mt-1 flex items-center gap-1">
 <FaArrowDown className="text-[10px]" /> 0.4 days faster
 </p>
 </div>
 <div className="bg-[#0f1117] border border-slate-700/40 rounded-xl p-5">
 <p className="text-gray-400 text-xs uppercase tracking-wider mb-2">Tasks on Time</p>
 <p className="text-3xl font-bold text-white">91.2%</p>
 <p className="text-emerald-400 text-xs mt-1 flex items-center gap-1">
 <FaArrowUp className="text-[10px]" /> +4.3% improvement
 </p>
 </div>
 </div>

 {/* Task Status Breakdown */}
 <div>
 <h4 className="text-gray-300 text-sm font-medium mb-4">Task Status Breakdown</h4>
 <div className="space-y-3">
 {[
 { label: "Completed", value: 218, pct: 64, color: "bg-emerald-500" },
 { label: "In Progress", value: 78, pct: 23, color: "bg-blue-500" },
 { label: "In Review", value: 28, pct: 8, color: "bg-yellow-500" },
 { label: "Blocked", value: 12, pct: 4, color: "bg-red-500" },
 { label: "To Do", value: 6, pct: 1, color: "bg-slate-500" },
 ].map((item) => (
 <div key={item.label} className="flex items-center gap-3">
 <span className="text-gray-400 text-sm w-28 shrink-0">{item.label}</span>
 <div className="flex-1 bg-slate-700/30 rounded-full h-7 overflow-hidden">
 <div
 className={`${item.color} h-full rounded-full flex items-center justify-end pr-2.5 transition-all`}
 style={{ width: `${item.pct}%` }}
 >
 {item.pct > 8 && (
 <span className="text-white text-xs font-semibold">{item.value}</span>
 )}
 </div>
 </div>
 <span className="text-gray-500 text-xs w-12 text-right">{item.pct}%</span>
 </div>
 ))}
 </div>
 </div>
 </div>
 )}

 {/* ── Budget Reports Tab ─────────────────────────────────────── */}
 {activeTab === "Budget Reports" && (
 <div className="space-y-6">
 <h3 className="text-white font-semibold text-lg">Budget Reports</h3>

 <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
 <div className="bg-[#0f1117] border border-slate-700/40 rounded-xl p-5">
 <p className="text-gray-400 text-xs uppercase tracking-wider mb-2">Total Budget</p>
 <p className="text-3xl font-bold text-white">$2.4M</p>
 <p className="text-gray-500 text-xs mt-1">FY 2025 allocated</p>
 </div>
 <div className="bg-[#0f1117] border border-slate-700/40 rounded-xl p-5">
 <p className="text-gray-400 text-xs uppercase tracking-wider mb-2">Spent YTD</p>
 <p className="text-3xl font-bold text-white">$1.62M</p>
 <p className="text-yellow-400 text-xs mt-1 flex items-center gap-1">
 <FaArrowUp className="text-[10px]" /> 67.5% utilized
 </p>
 </div>
 <div className="bg-[#0f1117] border border-slate-700/40 rounded-xl p-5">
 <p className="text-gray-400 text-xs uppercase tracking-wider mb-2">Remaining</p>
 <p className="text-3xl font-bold text-emerald-400">$780K</p>
 <p className="text-emerald-400/70 text-xs mt-1">On track</p>
 </div>
 <div className="bg-[#0f1117] border border-slate-700/40 rounded-xl p-5">
 <p className="text-gray-400 text-xs uppercase tracking-wider mb-2">Forecast Variance</p>
 <p className="text-3xl font-bold text-white">-2.3%</p>
 <p className="text-emerald-400 text-xs mt-1 flex items-center gap-1">
 <FaArrowDown className="text-[10px]" /> Under budget
 </p>
 </div>
 </div>

 {/* Department spend */}
 <div>
 <h4 className="text-gray-300 text-sm font-medium mb-4">Spend by Department</h4>
 <div className="space-y-3">
 {[
 { dept: "Engineering", spent: 720000, budget: 1100000, color: "bg-blue-500" },
 { dept: "Design", spent: 180000, budget: 250000, color: "bg-purple-500" },
 { dept: "QA", spent: 290000, budget: 400000, color: "bg-green-500" },
 { dept: "DevOps", spent: 310000, budget: 400000, color: "bg-orange-500" },
 { dept: "Management", spent: 120000, budget: 250000, color: "bg-pink-500" },
 ].map((item) => {
 const pct = (item.spent / item.budget) * 100;
 return (
 <div key={item.dept} className="flex items-center gap-3">
 <span className="text-gray-400 text-sm w-32 shrink-0">{item.dept}</span>
 <div className="flex-1 bg-slate-700/30 rounded-full h-6 overflow-hidden">
 <div
 className={`${item.color} h-full rounded-full flex items-center justify-end pr-2 transition-all`}
 style={{ width: `${Math.min(pct, 100)}%` }}
 >
 <span className="text-white text-xs font-semibold">${(item.spent / 1000).toFixed(0)}K</span>
 </div>
 </div>
 <span className="text-gray-500 text-xs w-14 text-right">{pct.toFixed(0)}%</span>
 </div>
 );
 })}
 </div>
 </div>
 </div>
 )}
 </div>

 {/* ── Recent Reports Table ────────────────────────────────────── */}
 <div className="bg-[#1a1d2e] border border-slate-700/60 rounded-xl overflow-hidden">
 <div className="p-5 border-b border-slate-700/40 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
 <h3 className="text-white font-semibold text-lg">Recent Reports</h3>
 <div className="relative">
 <FaSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 text-xs" />
 <input
 type="text"
 placeholder="Search reports..."
 value={searchQuery}
 onChange={(e) => setSearchQuery(e.target.value)}
 className="bg-[#0f1117] border border-slate-700 text-gray-200 rounded-lg pl-8 pr-4 py-2 text-sm focus:outline-none focus:border-blue-500 w-56"
 />
 </div>
 </div>

 <div className="overflow-x-auto">
 <table className="w-full text-sm">
 <thead>
 <tr className="text-gray-500 text-xs uppercase border-b border-slate-700/60 bg-slate-800/30">
 <th className="text-left py-3 px-4 font-medium">Report Name</th>
 <th className="text-left py-3 px-4 font-medium">Type</th>
 <th className="text-left py-3 px-4 font-medium">Generated Date</th>
 <th className="text-left py-3 px-4 font-medium">Status</th>
 <th className="text-right py-3 px-4 font-medium">Actions</th>
 </tr>
 </thead>
 <tbody>
 {RECENT_REPORTS.map((r) => (
 <tr key={r.id} className="border-b border-slate-700/30 hover:bg-slate-800/20 transition-colors">
 <td className="py-3 px-4">
 <div className="flex items-center gap-2.5">
 <FaFileAlt className="text-gray-500 text-sm" />
 <div>
 <span className="text-gray-200 font-medium">{r.name}</span>
 <p className="text-gray-600 text-xs">{r.id}</p>
 </div>
 </div>
 </td>
 <td className="py-3 px-4 text-gray-400">{r.type}</td>
 <td className="py-3 px-4 text-gray-400">{r.date}</td>
 <td className="py-3 px-4">
 <StatusBadge status={r.status} />
 </td>
 <td className="py-3 px-4">
 <div className="flex items-center justify-end gap-2">
 <button
 className="p-1.5 text-gray-400 hover:text-blue-400 hover:bg-blue-500/10 rounded-lg transition-colors"
 title="View report"
 >
 <FaEye className="text-xs" />
 </button>
 <button
 className="p-1.5 text-gray-400 hover:text-emerald-400 hover:bg-emerald-500/10 rounded-lg transition-colors"
 title="Download report"
 >
 <FaDownload className="text-xs" />
 </button>
 </div>
 </td>
 </tr>
 ))}
 </tbody>
 </table>
 </div>
 </div>
 </div>
 </Layout>
 );
}
