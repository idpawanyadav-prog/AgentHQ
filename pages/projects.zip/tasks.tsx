import React, { useState, useMemo } from "react";
import { useRouter } from "next/router";
import Layout from "@/components/Layout";
import TaskCard from "@/components/TaskCard";
import InteractiveDonut from "@/components/InteractiveDonut";
import type { TaskPriority, TaskStatus } from "@/types";
import {
 FaSearch,
 FaFilter,
 FaPlus,
 FaTasks,
 FaCheckCircle,
 FaClock,
 FaEllipsisH,
 FaChartPie,
 FaChevronDown,
} from "react-icons/fa";

// ── Types ────────────────────────────────────────────────────────────────

interface TaskRow {
 id: string;
 title: string;
 description: string;
 priority: TaskPriority;
 status: TaskStatus | "testing";
 type: string;
 project: string;
 sprint: string;
 assignee: string;
 assigneeColor: string;
 dueDate: string;
 storyPoints: number;
 progress: number;
 acceptanceCriteria: { text: string; done: boolean }[];
 attachments: number;
 relatedTasks: string[];
 blocked: boolean;
}

// Extended task type with CI for TaskCard
interface TaskRowWithCI extends TaskRow {
 ciStatus?: { state: "pending" | "success" | "failure" | "error"; description?: string };
}

// ── Sample Data ──────────────────────────────────────────────────────────

const KANBAN_COLUMNS: { id: TaskStatus | "testing"; title: string; color: string; headerBg: string; tasks: TaskRowWithCI[] }[] = [
 {
 id: "backlog",
 title: "To Do",
 color: "border-l-slate-500",
 headerBg: "bg-slate-500",
 tasks: [
 {
 id: "t1", title: "Setup CI/CD pipeline", description: "Configure GitHub Actions for automated testing and deployment.",
 priority: "high", status: "backlog", type: "Feature", project: "E-commerce Platform", sprint: "Sprint 5",
 assignee: "Alex Chen", assigneeColor: "bg-blue-600", dueDate: "Jan 10", storyPoints: 5,
 progress: 0,
 acceptanceCriteria: [{ text: "Pipeline runs on PR", done: false }, { text: "Deploy to staging auto", done: false }],
 attachments: 2, relatedTasks: ["t2"], blocked: false,
 ciStatus: { state: "pending" },
 },
 {
 id: "t2", title: "Implement user auth", description: "Add OAuth2 login with Google and GitHub providers.",
 priority: "high", status: "backlog", type: "Feature", project: "E-commerce Platform", sprint: "Sprint 5",
 assignee: "Sam Rivera", assigneeColor: "bg-purple-600", dueDate: "Jan 12", storyPoints: 8,
 progress: 0,
 acceptanceCriteria: [{ text: "OAuth flow works", done: false }, { text: "Session management", done: false }],
 attachments: 3, relatedTasks: ["t1"], blocked: false,
 },
 {
 id: "t3", title: "Write API docs", description: "Document all REST endpoints with Swagger/OpenAPI.",
 priority: "medium", status: "backlog", type: "Documentation", project: "Analytics Dashboard", sprint: "Sprint 4",
 assignee: "Jordan Lee", assigneeColor: "bg-green-600", dueDate: "Jan 15", storyPoints: 3,
 progress: 0,
 acceptanceCriteria: [{ text: "All endpoints documented", done: false }],
 attachments: 1, relatedTasks: [], blocked: false,
 },
 {
 id: "t4", title: "Fix memory leak in worker", description: "Investigate and fix OOM errors in background job processor.",
 priority: "critical", status: "backlog", type: "Bug", project: "Internal Automation", sprint: "Sprint 5",
 assignee: "Casey Park", assigneeColor: "bg-orange-600", dueDate: "Jan 8", storyPoints: 5,
 progress: 0,
 acceptanceCriteria: [{ text: "No OOM in 24h test", done: false }],
 attachments: 0, relatedTasks: [], blocked: true,
 },
 {
 id: "t5", title: "Add rate limiting", description: "Implement rate limiting middleware for API endpoints.",
 priority: "medium", status: "backlog", type: "Feature", project: "Mobile Banking", sprint: "Sprint 4",
 assignee: "Riley Kim", assigneeColor: "bg-pink-600", dueDate: "Jan 18", storyPoints: 3,
 progress: 0,
 acceptanceCriteria: [{ text: "100 req/min limit enforced", done: false }],
 attachments: 0, relatedTasks: [], blocked: false,
 },
 {
 id: "t6", title: "Design onboarding flow", description: "Create wireframes and mockups for new user onboarding.",
 priority: "low", status: "backlog", type: "Design", project: "Customer Portal v2", sprint: "Sprint 3",
 assignee: "Morgan Wu", assigneeColor: "bg-cyan-600", dueDate: "Jan 20", storyPoints: 2,
 progress: 0,
 acceptanceCriteria: [{ text: "Figma prototype ready", done: false }],
 attachments: 1, relatedTasks: [], blocked: false,
 },
 ],
 },
 {
 id: "in_progress",
 title: "In Progress",
 color: "border-l-blue-500",
 headerBg: "bg-blue-500",
 tasks: [
 {
 id: "t7", title: "Refactor payment module", description: "Split monolithic payment service into microservices.",
 priority: "high", status: "in_progress", type: "Refactor", project: "E-commerce Platform", sprint: "Sprint 5",
 assignee: "Alex Chen", assigneeColor: "bg-blue-600", dueDate: "Jan 14", storyPoints: 8,
 progress: 45,
 acceptanceCriteria: [{ text: "Stripe module done", done: true }, { text: "PayPal module done", done: false }],
 attachments: 4, relatedTasks: ["t8"], blocked: false,
 ciStatus: { state: "success", description: "Build passing" },
 },
 {
 id: "t8", title: "Update pricing engine", description: "Migrate pricing calculations to new rule engine.",
 priority: "medium", status: "in_progress", type: "Feature", project: "E-commerce Platform", sprint: "Sprint 5",
 assignee: "Sam Rivera", assigneeColor: "bg-purple-600", dueDate: "Jan 13", storyPoints: 5,
 progress: 60,
 acceptanceCriteria: [{ text: "Rule engine integrated", done: true }],
 attachments: 2, relatedTasks: ["t7"], blocked: false,
 ciStatus: { state: "success" },
 },
 {
 id: "t9", title: "Build analytics charts", description: "Create interactive charts using Chart.js for the dashboard.",
 priority: "medium", status: "in_progress", type: "Feature", project: "Analytics Dashboard", sprint: "Sprint 4",
 assignee: "Jordan Lee", assigneeColor: "bg-green-600", dueDate: "Jan 11", storyPoints: 5,
 progress: 30,
 acceptanceCriteria: [{ text: "3 chart types implemented", done: false }],
 attachments: 1, relatedTasks: [], blocked: false,
 ciStatus: { state: "pending" },
 },
 {
 id: "t10", title: "Migrate database schema", description: "Run migration scripts for v2 schema changes.",
 priority: "critical", status: "in_progress", type: "Infrastructure", project: "Mobile Banking", sprint: "Sprint 4",
 assignee: "Dana Foster", assigneeColor: "bg-orange-600", dueDate: "Jan 9", storyPoints: 13,
 progress: 75,
 acceptanceCriteria: [{ text: "Zero data loss", done: true }, { text: "Rollback plan tested", done: false }],
 attachments: 5, relatedTasks: ["t11"], blocked: false,
 ciStatus: { state: "success" },
 },
 {
 id: "t11", title: "Performance testing", description: "Run load tests against the new schema.",
 priority: "high", status: "in_progress", type: "Testing", project: "Mobile Banking", sprint: "Sprint 4",
 assignee: "Chris Novak", assigneeColor: "bg-pink-600", dueDate: "Jan 10", storyPoints: 5,
 progress: 20,
 acceptanceCriteria: [{ text: "10k RPS sustained", done: false }],
 attachments: 0, relatedTasks: ["t10"], blocked: true,
 },
 {
 id: "t12", title: "API gateway config", description: "Configure routing and rate limits in the API gateway.",
 priority: "medium", status: "in_progress", type: "Infrastructure", project: "Internal Automation", sprint: "Sprint 5",
 assignee: "Pat Nguyen", assigneeColor: "bg-cyan-600", dueDate: "Jan 16", storyPoints: 3,
 progress: 55,
 acceptanceCriteria: [{ text: "Routes configured", done: true }],
 attachments: 2, relatedTasks: [], blocked: false,
 },
 {
 id: "t13", title: "Mobile responsive fixes", description: "Fix layout issues on mobile viewports across all pages.",
 priority: "low", status: "in_progress", type: "Bug", project: "Customer Portal v2", sprint: "Sprint 3",
 assignee: "Avery Brooks", assigneeColor: "bg-green-600", dueDate: "Jan 17", storyPoints: 3,
 progress: 40,
 acceptanceCriteria: [{ text: "All breakpoints verified", done: false }],
 attachments: 1, relatedTasks: [], blocked: false,
 },
 {
 id: "t14", title: "Implement search indexing", description: "Add Elasticsearch indexing for product catalog.",
 priority: "high", status: "in_progress", type: "Feature", project: "E-commerce Platform", sprint: "Sprint 5",
 assignee: "Lee Martinez", assigneeColor: "bg-purple-600", dueDate: "Jan 15", storyPoints: 8,
 progress: 25,
 acceptanceCriteria: [{ text: "Full-text search working", done: false }],
 attachments: 3, relatedTasks: [], blocked: false,
 },
 ],
 },
 {
 id: "review",
 title: "Code Review",
 color: "border-l-yellow-500",
 headerBg: "bg-yellow-500",
 tasks: [
 {
 id: "t15", title: "Payment webhook handlers", description: "Review webhook handlers for Stripe and PayPal.",
 priority: "high", status: "review", type: "Feature", project: "E-commerce Platform", sprint: "Sprint 5",
 assignee: "Quinn Adams", assigneeColor: "bg-blue-600", dueDate: "Jan 9", storyPoints: 5,
 progress: 90,
 acceptanceCriteria: [{ text: "All edge cases covered", done: true }],
 attachments: 2, relatedTasks: ["t7"], blocked: false,
 ciStatus: { state: "success" },
 },
 {
 id: "t16", title: "Notification service refactor", description: "Review the refactored notification microservice.",
 priority: "medium", status: "review", type: "Refactor", project: "Internal Automation", sprint: "Sprint 5",
 assignee: "Riley Kim", assigneeColor: "bg-pink-600", dueDate: "Jan 10", storyPoints: 5,
 progress: 85,
 acceptanceCriteria: [{ text: "Tests pass", done: true }],
 attachments: 1, relatedTasks: [], blocked: false,
 ciStatus: { state: "success" },
 },
 {
 id: "t17", title: "Auth middleware update", description: "Review updated authentication middleware with JWT rotation.",
 priority: "critical", status: "review", type: "Feature", project: "Mobile Banking", sprint: "Sprint 4",
 assignee: "Dana Foster", assigneeColor: "bg-orange-600", dueDate: "Jan 8", storyPoints: 8,
 progress: 88,
 acceptanceCriteria: [{ text: "Security review passed", done: true }],
 attachments: 3, relatedTasks: ["t2"], blocked: false,
 ciStatus: { state: "success" },
 },
 {
 id: "t18", title: "Dashboard layout redesign", description: "Review the new dashboard layout with sidebar navigation.",
 priority: "low", status: "review", type: "Design", project: "Analytics Dashboard", sprint: "Sprint 4",
 assignee: "Morgan Wu", assigneeColor: "bg-cyan-600", dueDate: "Jan 12", storyPoints: 3,
 progress: 80,
 acceptanceCriteria: [{ text: "Design approved by PM", done: false }],
 attachments: 4, relatedTasks: [], blocked: false,
 },
 ],
 },
 {
 id: "testing",
 title: "Testing",
 color: "border-l-violet-500",
 headerBg: "bg-violet-500",
 tasks: [
 {
 id: "t25", title: "E2E checkout flow", description: "End-to-end tests for the complete checkout flow.",
 priority: "high", status: "testing", type: "Testing", project: "E-commerce Platform", sprint: "Sprint 5",
 assignee: "Chris Novak", assigneeColor: "bg-pink-600", dueDate: "Jan 11", storyPoints: 5,
 progress: 50,
 acceptanceCriteria: [{ text: "All checkout paths tested", done: false }],
 attachments: 0, relatedTasks: ["t7"], blocked: false,
 ciStatus: { state: "pending" },
 },
 {
 id: "t26", title: "Security audit", description: "Run OWASP security scan on the application.",
 priority: "critical", status: "testing", type: "Testing", project: "Mobile Banking", sprint: "Sprint 4",
 assignee: "Quinn Adams", assigneeColor: "bg-blue-600", dueDate: "Jan 10", storyPoints: 5,
 progress: 30,
 acceptanceCriteria: [{ text: "No critical vulnerabilities", done: false }],
 attachments: 0, relatedTasks: [], blocked: false,
 ciStatus: { state: "failure" },
 },
 {
 id: "t27", title: "Load test API", description: "Run load tests against the pricing engine API.",
 priority: "high", status: "testing", type: "Testing", project: "E-commerce Platform", sprint: "Sprint 5",
 assignee: "Lee Martinez", assigneeColor: "bg-purple-600", dueDate: "Jan 16", storyPoints: 5,
 progress: 20,
 acceptanceCriteria: [{ text: "1000 concurrent users", done: false }],
 attachments: 1, relatedTasks: [], blocked: false,
 },
 {
 id: "t28", title: "Mobile regression test", description: "Regression testing on mobile devices and emulators.",
 priority: "medium", status: "testing", type: "Testing", project: "Customer Portal v2", sprint: "Sprint 3",
 assignee: "Avery Brooks", assigneeColor: "bg-green-600", dueDate: "Jan 18", storyPoints: 3,
 progress: 40,
 acceptanceCriteria: [{ text: "All mobile features verified", done: false }],
 attachments: 2, relatedTasks: [], blocked: false,
 },
 ],
 },
 {
 id: "done",
 title: "Done",
 color: "border-l-green-500",
 headerBg: "bg-green-500",
 tasks: [
 {
 id: "t19", title: "Setup project repository", description: "Initialize monorepo with pnpm workspaces.",
 priority: "high", status: "done", type: "Infrastructure", project: "E-commerce Platform", sprint: "Sprint 4",
 assignee: "Alex Chen", assigneeColor: "bg-blue-600", dueDate: "Dec 20", storyPoints: 3,
 progress: 100,
 acceptanceCriteria: [{ text: "Repo created", done: true }, { text: "CI configured", done: true }],
 attachments: 1, relatedTasks: [], blocked: false,
 ciStatus: { state: "success" },
 },
 {
 id: "t20", title: "Database schema v1", description: "Initial database schema with all core tables.",
 priority: "high", status: "done", type: "Infrastructure", project: "Mobile Banking", sprint: "Sprint 3",
 assignee: "Dana Foster", assigneeColor: "bg-orange-600", dueDate: "Dec 18", storyPoints: 8,
 progress: 100,
 acceptanceCriteria: [{ text: "Migrations verified", done: true }],
 attachments: 2, relatedTasks: ["t10"], blocked: false,
 ciStatus: { state: "success" },
 },
 {
 id: "t21", title: "Login page UI", description: "Implement login page with form validation.",
 priority: "medium", status: "done", type: "Feature", project: "Customer Portal v2", sprint: "Sprint 3",
 assignee: "Avery Brooks", assigneeColor: "bg-green-600", dueDate: "Dec 22", storyPoints: 3,
 progress: 100,
 acceptanceCriteria: [{ text: "Form validation works", done: true }],
 attachments: 1, relatedTasks: [], blocked: false,
 },
 {
 id: "t22", title: "Unit test suite setup", description: "Configure Jest and write initial test utilities.",
 priority: "medium", status: "done", type: "Testing", project: "Analytics Dashboard", sprint: "Sprint 4",
 assignee: "Chris Novak", assigneeColor: "bg-pink-600", dueDate: "Dec 19", storyPoints: 3,
 progress: 100,
 acceptanceCriteria: [{ text: "80% coverage", done: true }],
 attachments: 0, relatedTasks: [], blocked: false,
 ciStatus: { state: "success" },
 },
 {
 id: "t23", title: "Docker compose setup", description: "Create docker-compose for local development.",
 priority: "low", status: "done", type: "Infrastructure", project: "Internal Automation", sprint: "Sprint 4",
 assignee: "Pat Nguyen", assigneeColor: "bg-cyan-600", dueDate: "Dec 21", storyPoints: 2,
 progress: 100,
 acceptanceCriteria: [{ text: "All services start", done: true }],
 attachments: 1, relatedTasks: [], blocked: false,
 },
 {
 id: "t24", title: "Error handling middleware", description: "Global error handler with logging.",
 priority: "medium", status: "done", type: "Feature", project: "E-commerce Platform", sprint: "Sprint 4",
 assignee: "Sam Rivera", assigneeColor: "bg-purple-600", dueDate: "Dec 23", storyPoints: 3,
 progress: 100,
 acceptanceCriteria: [{ text: "All errors caught", done: true }],
 attachments: 1, relatedTasks: [], blocked: false,
 },
 ],
 },
];

// Put remaining tasks in a "Testing" column
// ── (already integrated into KANBAN_COLUMNS) ───────────────────────────────

// All tasks from all kanban columns
const ALL_TASKS: TaskRowWithCI[] = KANBAN_COLUMNS.flatMap((c) => c.tasks);

// ── Stats Data ───────────────────────────────────────────────────────────

const STATS = [
 { label: "Total Tasks", value: "124", icon: <FaTasks />, color: "text-blue-400", bg: "bg-blue-400/10" },
 { label: "Completed", value: "72", icon: <FaCheckCircle />, color: "text-green-400", bg: "bg-green-400/10" },
 { label: "In Progress", value: "36", icon: <FaClock />, color: "text-yellow-400", bg: "bg-yellow-400/10" },
 { label: "Blocked", value: "8", icon: <FaEllipsisH />, color: "text-red-400", bg: "bg-red-400/10" },
 { label: "Overdue", value: "4", icon: <FaClock />, color: "text-orange-400", bg: "bg-orange-400/10" },
 { label: "On Track", value: "85%", icon: <FaChartPie />, color: "text-emerald-400", bg: "bg-emerald-400/10" },
];

const TABLE_TASKS: TaskRowWithCI[] = ALL_TASKS.slice(0, 10);

const PRIORITY_COLORS: Record<TaskPriority, { bg: string; text: string }> = {
 low: { bg: "bg-slate-400/10", text: "text-slate-400" },
 medium: { bg: "bg-yellow-400/10", text: "text-yellow-400" },
 high: { bg: "bg-orange-400/10", text: "text-orange-400" },
 critical: { bg: "bg-red-400/10", text: "text-red-400" },
};

const PRIORITY_LABELS: Record<TaskPriority, string> = {
 low: "Low",
 medium: "Medium",
 high: "High",
 critical: "Critical",
};

// ── Selected task detail state ───────────────────────────────────────────

const TasksPage: React.FC = () => {
 const router = useRouter();
 const [searchQuery, setSearchQuery] = useState("");
 const [projectFilter, setProjectFilter] = useState("All Projects");
 const [teamFilter, setTeamFilter] = useState("All Teams");
 const [showFilters, setShowFilters] = useState(false);
 const [activeView, setActiveView] = useState<"kanban" | "list" | "calendar" | "my-tasks" | "reviews">("kanban");
 const [selectedTask, setSelectedTask] = useState<TaskRowWithCI | null>(null);

 const projects = useMemo(() => {
 const set = new Set(ALL_TASKS.map((t) => t.project));
 return ["All Projects", ...Array.from(set)];
 }, []);

 const teams = useMemo(() => {
 const set = new Set(ALL_TASKS.map((t) => t.sprint.replace(/ Sprint.*/, "")));
 return ["All Teams", ...Array.from(set)];
 }, []);

 const filteredKanban = useMemo(() => {
 return KANBAN_COLUMNS.map((col) => {
 let tasks = col.tasks;
 if (searchQuery) {
 const q = searchQuery.toLowerCase();
 tasks = tasks.filter((t) => t.title.toLowerCase().includes(q) || t.description.toLowerCase().includes(q));
 }
 if (projectFilter !== "All Projects") {
 tasks = tasks.filter((t) => t.project === projectFilter);
 }
 return { ...col, tasks };
 });
 }, [searchQuery, projectFilter]);

 const handleNavigate = (item: string) => {
 const navHref: Record<string, string> = {
 overview: "/",
 teams: "/teams",
 tasks: "/tasks",
 agents: "/agents",
 projects: "/projects",
 activity: "/activity",
 settings: "/settings",
 };
 router.push(navHref[item] || "/");
 };

 const donutData = [
 { label: "Feature", value: 48, color: "#3b82f6" },
 { label: "Bug", value: 28, color: "#ef4444" },
 { label: "Refactor", value: 22, color: "#f97316" },
 { label: "Docs", value: 12, color: "#94a3b8" },
 { label: "Testing", value: 14, color: "#22c55e" },
 ];

 const priorityData = [
 { label: "Critical", value: 8, color: "#ef4444" },
 { label: "High", value: 32, color: "#f97316" },
 { label: "Medium", value: 52, color: "#fbbf24" },
 { label: "Low", value: 32, color: "#94a3b8" },
 ];

 const filteredTable = useMemo(() => {
 let tasks = TABLE_TASKS;
 if (searchQuery) {
 const q = searchQuery.toLowerCase();
 tasks = tasks.filter((t) => t.title.toLowerCase().includes(q) || t.description.toLowerCase().includes(q));
 }
 if (projectFilter !== "All Projects") {
 tasks = tasks.filter((t) => t.project === projectFilter);
 }
 return tasks;
 }, [searchQuery, projectFilter]);

 // Status label/color mapping for table
 const statusLabel = (s: string) => {
 switch (s) {
 case "backlog": return "To Do";
 case "in_progress": return "In Progress";
 case "review": return "Code Review";
 case "testing": return "Testing";
 case "done": return "Done";
 default: return s;
 }
 };
 const statusClass = (s: string) => {
 switch (s) {
 case "backlog": return "bg-slate-600/20 text-slate-400";
 case "in_progress": return "bg-blue-400/10 text-blue-400";
 case "review": return "bg-yellow-400/10 text-yellow-400";
 case "testing": return "bg-violet-400/10 text-violet-400";
 case "done": return "bg-green-400/10 text-green-400";
 default: return "bg-slate-600/20 text-slate-400";
 }
 };

 return (
 <Layout activeNav="tasks" onNavigate={handleNavigate}>
 <div className="px-6 space-y-6">
 {/* ── Page Header ─────────────────────────────────────────── */}
 <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
 <div>
 <h1 className="text-2xl font-bold text-white">Tasks</h1>
 <p className="text-sm text-slate-400 mt-1">Manage and track tasks across all projects and teams.</p>
 </div>
 <div className="flex flex-wrap items-center gap-3">
 {/* Search */}
 <div className="relative">
 <FaSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 text-xs" />
 <input
 type="text"
 placeholder="Search tasks..."
 value={searchQuery}
 onChange={(e) => setSearchQuery(e.target.value)}
 className="w-64 bg-[#111827] border border-slate-700 rounded-md pl-9 pr-4 py-2 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-500"
 />
 </div>

 {/* Dropdowns */}
 <select
 value={projectFilter}
 onChange={(e) => setProjectFilter(e.target.value)}
 className="bg-[#111827] border border-slate-700 rounded-md px-3 py-2 text-sm text-slate-300 focus:outline-none focus:border-blue-500"
 >
 {projects.map((p) => (
 <option key={p} value={p}>{p}</option>
 ))}
 </select>

 <select
 value={teamFilter}
 onChange={(e) => setTeamFilter(e.target.value)}
 className="bg-[#111827] border border-slate-700 rounded-md px-3 py-2 text-sm text-slate-300 focus:outline-none focus:border-blue-500"
 >
 {teams.map((t) => (
 <option key={t} value={t}>{t}</option>
 ))}
 </select>

 <button
 onClick={() => setShowFilters(!showFilters)}
 className="bg-[#111827] border border-slate-700 rounded-md px-3 py-2 text-sm text-slate-300 hover:text-white flex items-center gap-2 transition-colors"
 >
 <FaFilter className="w-3 h-3" />
 Filters
 <FaChevronDown className={`w-3 h-3 transition-transform ${showFilters ? "rotate-180" : ""}`} />
 </button>

 <button className="bg-blue-600 hover:bg-blue-500 text-white text-sm px-4 py-2 rounded-md flex items-center gap-2 transition-colors">
 <FaPlus className="w-3 h-3" />
 Create Task
 </button>
 </div>
 </div>

 {/* ── Stats Row ───────────────────────────────────────────── */}
 <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
 {STATS.map((s) => (
 <div key={s.label} className="bg-[#1a1d2e] border border-slate-700 rounded-lg p-4">
 <div className="flex items-start justify-between">
 <div>
 <p className="text-xs text-slate-400 mb-1">{s.label}</p>
 <p className="text-xl font-bold text-white">{s.value}</p>
 </div>
 <div className={`p-2 rounded-lg ${s.bg} ${s.color}`}>
 {React.cloneElement(s.icon as React.ReactElement, { className: "w-4 h-4" })}
 </div>
 </div>
 </div>
 ))}
 </div>

 {/* ── View Tabs ───────────────────────────────────────────── */}
 <div className="flex items-center gap-1 border-b border-slate-700">
 {[
 { id: "kanban" as const, label: "Kanban" },
 { id: "list" as const, label: "List" },
 { id: "calendar" as const, label: "Calendar" },
 { id: "my-tasks" as const, label: "My Tasks" },
 { id: "reviews" as const, label: "Reviews" },
 ].map((tab) => (
 <button
 key={tab.id}
 onClick={() => setActiveView(tab.id)}
 className={`px-4 py-2.5 text-sm font-medium transition-colors ${
 activeView === tab.id
 ? "text-blue-400 border-b-2 border-blue-500"
 : "text-slate-400 hover:text-white"
 }`}
 >
 {tab.label}
 </button>
 ))}
 </div>

 {/* ── Main Content: Kanban + Right Panel ──────────────────── */}
 <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
 {/* LEFT: Kanban Board */}
 <div className={selectedTask ? "xl:col-span-3" : "xl:col-span-4"}>
 {activeView === "kanban" && (
 <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-thin">
 {filteredKanban.map((col) => (
 <div
 key={col.id}
 className={`kanban-column flex-shrink-0 w-72 flex flex-col ${col.color}`}
 >
 {/* Column Header */}
 <div className="px-3 py-2.5 rounded-t-lg" style={{ backgroundColor: col.headerBg }}>
 <div className="flex items-center justify-between">
 <h3 className="text-sm font-semibold text-white">{col.title}</h3>
 <span className="text-xs text-white/70 bg-white/10 px-2 py-0.5 rounded-full">
 {col.tasks.length}
 </span>
 </div>
 </div>

 {/* Tasks */}
 <div className="flex-1 overflow-y-auto scrollbar-thin p-2.5 space-y-2.5">
 {col.tasks.map((task) => (
 <div
 key={task.id}
 onClick={() => setSelectedTask(task)}
 className="cursor-pointer group"
 >
 <div className="bg-[#1a1d2e] border border-slate-700 rounded-md p-3 hover:border-slate-600 transition-colors">
 {/* Type badge */}
 <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-700/60 text-slate-300 uppercase tracking-wide mb-1.5 inline-block">
 {task.type}
 </span>
 {/* TaskCard (priority + title + assignee) */}
 <TaskCard task={task} onClick={() => {}} showAssignee compact />
 {/* Due date */}
 <div className="flex items-center gap-1 text-[11px] text-slate-500 mt-2">
 <FaClock className="w-3 h-3" />
 {task.dueDate}
 </div>
 {/* Progress bar */}
 <div className="mt-2">
 <div className="w-full bg-slate-700/60 rounded-full h-1.5">
 <div
 className="bg-blue-500 h-1.5 rounded-full transition-all"
 style={{ width: `${task.progress}%` }}
 />
 </div>
 <div className="flex items-center justify-between mt-0.5">
 <span className="text-[10px] text-slate-500">Progress</span>
 <span className="text-[10px] text-slate-400">{task.progress}%</span>
 </div>
 </div>
 </div>
 </div>
 ))}
 {col.tasks.length === 0 && (
 <div className="text-center py-8 text-slate-600 text-xs">
 No tasks
 </div>
 )}
 </div>
 </div>
 ))}
 </div>
 )}

 {activeView === "list" && (
 <div className="bg-[#1a1d2e] border border-slate-700 rounded-lg overflow-hidden">
 <div className="overflow-x-auto">
 <table className="w-full text-sm">
 <thead>
 <tr className="text-xs text-slate-500 border-b border-slate-700">
 <th className="text-left px-4 py-3 font-medium">Task</th>
 <th className="text-left px-4 py-3 font-medium">Type</th>
 <th className="text-left px-4 py-3 font-medium">Priority</th>
 <th className="text-left px-4 py-3 font-medium">Status</th>
 <th className="text-left px-4 py-3 font-medium">Assignee</th>
 <th className="text-left px-4 py-3 font-medium">Due Date</th>
 <th className="text-left px-4 py-3 font-medium">Progress</th>
 <th className="text-left px-4 py-3 font-medium">Actions</th>
 </tr>
 </thead>
 <tbody>
 {filteredTable.map((task) => {
 const pStyle = PRIORITY_COLORS[task.priority];
 return (
 <tr
 key={task.id}
 onClick={() => setSelectedTask(task)}
 className="border-b border-slate-700/50 hover:bg-slate-800/30 cursor-pointer"
 >
 <td className="px-4 py-3">
 <div>
 <p className="text-white font-medium text-sm">{task.title}</p>
 <p className="text-slate-500 text-xs truncate max-w-xs">{task.project}</p>
 </div>
 </td>
 <td className="px-4 py-3">
 <span className="text-xs px-2 py-0.5 rounded-full bg-slate-700/50 text-slate-300">
 {task.type}
 </span>
 </td>
 <td className="px-4 py-3">
 <span className={`text-xs px-2 py-0.5 rounded-full ${pStyle.bg} ${pStyle.text}`}>
 {PRIORITY_LABELS[task.priority]}
 </span>
 </td>
 <td className="px-4 py-3">
 <span className={`text-xs px-2 py-0.5 rounded-full ${statusClass(task.status)}`}>
 {statusLabel(task.status)}
 </span>
 </td>
 <td className="px-4 py-3">
 <div className="flex items-center gap-2">
 <div className={`w-6 h-6 rounded-full ${task.assigneeColor} flex items-center justify-center text-white text-[10px] font-bold`}>
 {task.assignee.split(" ").map((n) => n[0]).join("")}
 </div>
 <span className="text-slate-400 text-xs">{task.assignee}</span>
 </div>
 </td>
 <td className="px-4 py-3 text-slate-400 text-xs">{task.dueDate}</td>
 <td className="px-4 py-3">
 <div className="flex items-center gap-2">
 <div className="w-16 bg-slate-700 rounded-full h-1.5">
 <div
 className="bg-blue-500 h-1.5 rounded-full"
 style={{ width: `${task.progress}%` }}
 />
 </div>
 <span className="text-xs text-slate-400">{task.progress}%</span>
 </div>
 </td>
 <td className="px-4 py-3">
 <button className="text-slate-400 hover:text-white transition-colors">
 <FaEllipsisH className="w-4 h-4" />
 </button>
 </td>
 </tr>
 );
 })}
 </tbody>
 </table>
 </div>
 </div>
 )}

 {(activeView === "calendar" || activeView === "my-tasks" || activeView === "reviews") && (
 <div className="bg-[#1a1d2e] border border-slate-700 rounded-lg p-12 text-center">
 <FaTasks className="w-12 h-12 text-slate-600 mx-auto mb-3" />
 <p className="text-slate-400 text-sm">
 {activeView === "calendar" && "Calendar view is coming soon."}
 {activeView === "my-tasks" && "My Tasks view shows only tasks assigned to you."}
 {activeView === "reviews" && "Code Reviews view shows tasks awaiting review."}
 </p>
 </div>
 )}

 {/* ── Bottom Section: Task List Table + Donut + Priority ── */}
 <div className="grid grid-cols-1 xl:grid-cols-4 gap-6 mt-6">
 {/* Task List Table */}
 <div className="xl:col-span-3 bg-[#1a1d2e] border border-slate-700 rounded-lg overflow-hidden">
 <div className="px-4 py-3 border-b border-slate-700 flex items-center justify-between">
 <h3 className="text-sm font-semibold text-white">All Tasks</h3>
 <span className="text-xs text-slate-500">{filteredTable.length} tasks</span>
 </div>
 <div className="overflow-x-auto">
 <table className="w-full text-sm">
 <thead>
 <tr className="text-xs text-slate-500 border-b border-slate-700">
 <th className="text-left px-4 py-2.5 font-medium w-8">#</th>
 <th className="text-left px-4 py-2.5 font-medium">Task</th>
 <th className="text-left px-4 py-2.5 font-medium">Project</th>
 <th className="text-left px-4 py-2.5 font-medium">Priority</th>
 <th className="text-left px-4 py-2.5 font-medium">Due Date</th>
 <th className="text-left px-4 py-2.5 font-medium">Status</th>
 <th className="text-left px-4 py-2.5 font-medium">Assignee</th>
 </tr>
 </thead>
 <tbody>
 {filteredTable.map((task, idx) => {
 const pStyle = PRIORITY_COLORS[task.priority];
 return (
 <tr
 key={task.id}
 onClick={() => setSelectedTask(task)}
 className="border-b border-slate-700/50 hover:bg-slate-800/30 cursor-pointer"
 >
 <td className="px-4 py-3 text-slate-500 text-xs">{idx + 1}</td>
 <td className="px-4 py-3 text-white font-medium text-sm">{task.title}</td>
 <td className="px-4 py-3 text-slate-400 text-xs">{task.project}</td>
 <td className="px-4 py-3">
 <span className={`text-xs px-2 py-0.5 rounded-full ${pStyle.bg} ${pStyle.text}`}>
 {PRIORITY_LABELS[task.priority]}
 </span>
 </td>
 <td className="px-4 py-3 text-slate-400 text-xs">{task.dueDate}</td>
 <td className="px-4 py-3">
 <span className={`text-xs px-2 py-0.5 rounded-full ${statusClass(task.status)}`}>
 {statusLabel(task.status)}
 </span>
 </td>
 <td className="px-4 py-3">
 <div className="flex items-center gap-2">
 <div className={`w-5 h-5 rounded-full ${task.assigneeColor} flex items-center justify-center text-white text-[9px] font-bold`}>
 {task.assignee.split(" ").map((n) => n[0]).join("")}
 </div>
 <span className="text-slate-400 text-xs">{task.assignee}</span>
 </div>
 </td>
 </tr>
 );
 })}
 </tbody>
 </table>
 </div>
 </div>

 {/* RIGHT: Donut + Priority Breakdown */}
 <div className="xl:col-span-1 space-y-6">
 {/* Task Distribution Donut */}
 <div className="bg-[#1a1d2e] border border-slate-700 rounded-lg p-4">
 <h3 className="text-white text-sm font-semibold mb-3">Task Distribution</h3>
 <InteractiveDonut
 segments={[
 { label: "Feature", value: 48, color: "#3b82f6" },
 { label: "Bug", value: 28, color: "#ef4444" },
 { label: "Refactor", value: 22, color: "#f97316" },
 { label: "Docs", value: 12, color: "#94a3b8" },
 { label: "Testing", value: 14, color: "#22c55e" },
 ]}
 size={140}
 strokeWidth={18}
 centerLabel="Tasks"
 showLegend={true}
 />
 </div>

 {/* Tasks by Priority */}
 <div className="bg-[#1a1d2e] border border-slate-700 rounded-lg p-4">
 <h3 className="text-white text-sm font-semibold mb-3">Tasks by Priority</h3>
 <div className="space-y-3">
 {priorityData.map((item) => (
 <div key={item.label}>
 <div className="flex items-center justify-between text-xs mb-1">
 <div className="flex items-center gap-2">
 <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }} />
 <span className="text-slate-300">{item.label}</span>
 </div>
 <span className="text-slate-400 font-medium">{item.value}</span>
 </div>
 <div className="w-full bg-slate-700 rounded-full h-2">
 <div
 className="h-2 rounded-full transition-all"
 style={{
 width: `${(item.value / 52) * 100}%`,
 backgroundColor: item.color,
 }}
 />
 </div>
 </div>
 ))}
 </div>
 </div>
 </div>
 </div>
 </div>

 {/* RIGHT: Task Detail Panel */}
 {selectedTask && (
 <div className="xl:col-span-1 space-y-0">
 <div className="bg-[#1a1d2e] border border-slate-700 rounded-lg overflow-hidden">
 {/* Panel Header */}
 <div className="px-4 py-3 border-b border-slate-700 flex items-center justify-between">
 <h3 className="text-white text-sm font-semibold">Task Detail</h3>
 <button
 onClick={() => setSelectedTask(null)}
 className="text-slate-400 hover:text-white transition-colors"
 >
 <FaEllipsisH className="w-4 h-4" />
 </button>
 </div>

 <div className="p-4 space-y-4 max-h-[calc(100vh-200px)] overflow-y-auto scrollbar-thin">
 {/* Project & Sprint */}
 <div>
 <p className="text-xs text-slate-500 mb-1">Project</p>
 <p className="text-sm text-white font-medium">{selectedTask.project}</p>
 <p className="text-xs text-slate-400 mt-0.5">Sprint: {selectedTask.sprint}</p>
 </div>

 {/* Title */}
 <div>
 <p className="text-xs text-slate-500 mb-1">Title</p>
 <p className="text-sm text-white">{selectedTask.title}</p>
 </div>

 {/* Assignee */}
 <div>
 <p className="text-xs text-slate-500 mb-1">Assignee</p>
 <div className="flex items-center gap-2">
 <div className={`w-6 h-6 rounded-full ${selectedTask.assigneeColor} flex items-center justify-center text-white text-[10px] font-bold`}>
 {selectedTask.assignee.split(" ").map((n) => n[0]).join("")}
 </div>
 <span className="text-sm text-slate-300">{selectedTask.assignee}</span>
 </div>
 </div>

 {/* Priority + Type */}
 <div className="grid grid-cols-2 gap-3">
 <div>
 <p className="text-xs text-slate-500 mb-1">Priority</p>
 <span className={`text-xs px-2 py-0.5 rounded-full ${PRIORITY_COLORS[selectedTask.priority].bg} ${PRIORITY_COLORS[selectedTask.priority].text}`}>
 {PRIORITY_LABELS[selectedTask.priority]}
 </span>
 </div>
 <div>
 <p className="text-xs text-slate-500 mb-1">Type</p>
 <span className="text-xs px-2 py-0.5 rounded-full bg-slate-700/50 text-slate-300">
 {selectedTask.type}
 </span>
 </div>
 </div>

 {/* Story Points + Due Date */}
 <div className="grid grid-cols-2 gap-3">
 <div>
 <p className="text-xs text-slate-500 mb-1">Story Points</p>
 <p className="text-sm text-white font-medium">{selectedTask.storyPoints}</p>
 </div>
 <div>
 <p className="text-xs text-slate-500 mb-1">Due Date</p>
 <p className="text-sm text-white">{selectedTask.dueDate}</p>
 </div>
 </div>

 {/* Description */}
 <div>
 <p className="text-xs text-slate-500 mb-1">Description</p>
 <p className="text-sm text-slate-300 leading-relaxed">{selectedTask.description}</p>
 </div>

 {/* Acceptance Criteria */}
 <div>
 <p className="text-xs text-slate-500 mb-2">Acceptance Criteria</p>
 <div className="space-y-1.5">
 {selectedTask.acceptanceCriteria.map((ac, i) => (
 <label key={i} className="flex items-start gap-2 cursor-pointer">
 <input
 type="checkbox"
 checked={ac.done}
 readOnly
 className="mt-0.5 w-3.5 h-3.5 rounded border-slate-600 bg-slate-800 text-blue-500 focus:ring-blue-500"
 />
 <span className={`text-xs ${ac.done ? "text-slate-500 line-through" : "text-slate-300"}`}>
 {ac.text}
 </span>
 </label>
 ))}
 </div>
 </div>

 {/* Attachments */}
 <div>
 <p className="text-xs text-slate-500 mb-1">Attachments</p>
 <p className="text-sm text-slate-300">{selectedTask.attachments} files attached</p>
 </div>

 {/* Related Items */}
 <div>
 <p className="text-xs text-slate-500 mb-1">Related Items</p>
 <div className="space-y-1">
 {selectedTask.relatedTasks.map((rid) => {
 const rel = ALL_TASKS.find((t) => t.id === rid);
 if (!rel) return null;
 return (
 <button
 key={rid}
 onClick={() => setSelectedTask(rel)}
 className="w-full text-left text-xs text-blue-400 hover:text-blue-300 bg-slate-800/50 rounded px-2 py-1.5 transition-colors"
 >
 {rel.id}: {rel.title}
 </button>
 );
 })}
 </div>
 </div>
 </div>
 </div>
 </div>
 )}
 </div>
 </div>
 </Layout>
 );
};

export default TasksPage;
