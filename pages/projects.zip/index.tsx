'use client';

import React, { useState } from "react";
import { useRouter } from "next/router";
import Layout from "@/components/Layout";
import InteractiveDonut from "@/components/InteractiveDonut";
import {
	FaUsers,
	FaProjectDiagram,
	FaTasks,
	FaMicrochip,
	FaCoins,
	FaDollarSign,
	FaArrowUp,
	FaArrowDown,
	FaPlus,
	FaCheckCircle,
	FaCalendarAlt,
	FaCode,
	FaBug,
	FaPalette,
	FaUserTie,
	FaChartLine,
	FaCog,
} from "react-icons/fa";

interface KpiCardProps {
	icon: React.ReactNode;
	label: string;
	value: string | number;
	subtext?: string;
	trend?: { value: string; positive: boolean };
	iconColor: string;
	iconBg: string;
}

function KpiCard({ icon, label, value, subtext, trend, iconColor, iconBg }: KpiCardProps) {
	return (
		<div className="bg-[#1a1d2e] border border-slate-700 rounded-xl p-4 hover:border-slate-600 transition-all">
			<div className="flex items-start justify-between mb-3">
				<div className={`w-9 h-9 rounded-lg ${iconBg} flex items-center justify-center ${iconColor}`}>
					{icon}
				</div>
				{trend && (
					<div
						className={`flex items-center gap-1 text-xs font-medium ${
							trend.positive ? "text-green-400" : "text-red-400"
						}`}
					>
						{trend.positive ? <FaArrowUp className="w-3 h-3" /> : <FaArrowDown className="w-3 h-3" />}
						{trend.value}
					</div>
				)}
			</div>
			<p className="text-2xl font-bold text-white tabular-nums">{value}</p>
			<p className="text-xs text-slate-400 mt-0.5">{label}</p>
			{subtext && <p className="text-[11px] text-slate-500 mt-1">{subtext}</p>}
		</div>
	);
}

interface TeamCardProps {
	letter: string;
	name: string;
	focus: string;
	color: string;
	textColor: string;
	bg: string;
	sprint: number;
	sprintOf: number;
	progress: number;
	daysLeft: number;
	members: number;
	projects: number;
	active: boolean;
}

function TeamCard({
	letter,
	name,
	focus,
	color,
	textColor,
	bg,
	sprint,
	sprintOf,
	progress,
	daysLeft,
	members,
	projects,
	active,
}: TeamCardProps) {
	return (
		<div className="bg-[#1a1d2e] border border-slate-700 rounded-xl p-4 hover:border-slate-600 transition-all cursor-pointer">
			<div className="flex items-start justify-between mb-3">
				<div className="flex items-center gap-3">
					<div className={`w-10 h-10 rounded-lg ${bg} flex items-center justify-center text-white font-bold`}>
						{letter}
					</div>
					<div>
						<h4 className="text-white font-semibold text-sm">{name}</h4>
						<p className={`text-xs ${textColor}`}>{focus}</p>
					</div>
				</div>
				{active && (
					<span className="text-[10px] px-2 py-0.5 rounded-full bg-green-400/10 text-green-400 border border-green-400/20">
						Active
					</span>
				)}
			</div>

			<div className="mb-2">
				<div className="flex items-center justify-between text-xs mb-1.5">
					<span className="text-slate-400">Sprint {sprint} of {sprintOf}</span>
					<span className="text-slate-400">{daysLeft} days</span>
				</div>
				<div className="w-full bg-slate-800 rounded-full h-1.5">
					<div
						className={`h-1.5 rounded-full ${color}`}
						style={{ width: `${progress}%` }}
					/>
				</div>
				<p className={`text-[11px] mt-1 ${textColor} font-medium`}>{progress}% complete</p>
			</div>

			<div className="flex items-center gap-3 text-[11px] text-slate-500 mt-3 pt-3 border-t border-slate-700/50">
				<span className="flex items-center gap-1">
					<FaUsers className="w-3 h-3" />
					{members}
				</span>
				<span className="flex items-center gap-1">
					<FaProjectDiagram className="w-3 h-3" />
					{projects}
				</span>
			</div>
		</div>
	);
}

type DetailTab = "members" | "projects" | "sprint" | "tasks" | "activity" | "metrics";

interface MemberCardProps {
	name: string;
	role: string;
	model: string;
	avatarColor: string;
	modelBg: string;
	modelText: string;
	task: string;
	initials: string;
}

function MemberCard({ name, role, model, avatarColor, modelBg, modelText, task, initials }: MemberCardProps) {
	return (
		<div className="bg-[#111827] border border-slate-700/60 rounded-lg p-3 hover:border-slate-600 transition-colors">
			<div className="flex items-start gap-3 mb-2">
				<div className={`w-10 h-10 rounded-lg ${avatarColor} flex items-center justify-center text-white text-sm font-bold flex-shrink-0`}>
					{initials}
				</div>
				<div className="min-w-0 flex-1">
					<p className="text-white text-sm font-medium truncate">{name}</p>
					<p className="text-slate-400 text-[11px] truncate">{role}</p>
				</div>
			</div>
			<div className="flex items-center justify-between gap-2 mb-2">
				<span className={`text-[10px] px-2 py-0.5 rounded ${modelBg} ${modelText} font-medium`}>
					{model}
				</span>
			</div>
			<p className="text-[11px] text-slate-500 truncate">{task}</p>
		</div>
	);
}

export default function Overview() {
	const [detailTab, setDetailTab] = useState<DetailTab>("members");

	const kpis: KpiCardProps[] = [
		{
			icon: <FaUsers className="w-4 h-4" />,
			label: "Total Teams",
			value: "4",
			trend: { value: "+1 new", positive: true },
			iconColor: "text-blue-400",
			iconBg: "bg-blue-500/10",
		},
		{
			icon: <FaProjectDiagram className="w-4 h-4" />,
			label: "Active Projects",
			value: "8",
			trend: { value: "+3 new", positive: true },
			iconColor: "text-purple-400",
			iconBg: "bg-purple-500/10",
		},
		{
			icon: <FaTasks className="w-4 h-4" />,
			label: "Active Tasks",
			value: "24",
			subtext: "12 in progress",
			iconColor: "text-orange-400",
			iconBg: "bg-orange-500/10",
		},
		{
			icon: <FaMicrochip className="w-4 h-4" />,
			label: "Total AI Employees",
			value: "28",
			iconColor: "text-cyan-400",
			iconBg: "bg-cyan-500/10",
		},
		{
			icon: <FaCoins className="w-4 h-4" />,
			label: "Total Token Usage",
			value: "12.4M",
			trend: { value: "-28%", positive: false },
			iconColor: "text-pink-400",
			iconBg: "bg-pink-500/10",
		},
		{
			icon: <FaDollarSign className="w-4 h-4" />,
			label: "Estimated Cost",
			value: "$48.72",
			trend: { value: "-32%", positive: false },
			iconColor: "text-emerald-400",
			iconBg: "bg-emerald-500/10",
		},
	];

	const teams: TeamCardProps[] = [
		{
			letter: "A",
			name: "Team Alpha",
			focus: "E-commerce Platform",
			color: "bg-blue-500",
			textColor: "text-blue-400",
			bg: "bg-blue-500",
			sprint: 3,
			sprintOf: 4,
			progress: 72,
			daysLeft: 8,
			members: 7,
			projects: 2,
			active: true,
		},
		{
			letter: "B",
			name: "Team Beta",
			focus: "AI Analytics Engine",
			color: "bg-purple-500",
			textColor: "text-purple-400",
			bg: "bg-purple-500",
			sprint: 2,
			sprintOf: 4,
			progress: 45,
			daysLeft: 12,
			members: 7,
			projects: 2,
			active: true,
		},
		{
			letter: "G",
			name: "Team Gamma",
			focus: "Mobile App Suite",
			color: "bg-orange-500",
			textColor: "text-orange-400",
			bg: "bg-orange-500",
			sprint: 1,
			sprintOf: 4,
			progress: 22,
			daysLeft: 18,
			members: 7,
			projects: 2,
			active: true,
		},
		{
			letter: "D",
			name: "Team Delta",
			focus: "Internal Tools",
			color: "bg-green-500",
			textColor: "text-green-400",
			bg: "bg-green-500",
			sprint: 2,
			sprintOf: 4,
			progress: 58,
			daysLeft: 10,
			members: 7,
			projects: 2,
			active: true,
		},
	];

	const members: MemberCardProps[] = [
		{
			name: "Alex Rivera",
			role: "Scrum Master",
			model: "Claude Sonnet",
			avatarColor: "bg-gradient-to-br from-blue-500 to-blue-700",
			modelBg: "bg-blue-500/10",
			modelText: "text-blue-400",
			task: "Sprint planning & coordination",
			initials: "AR",
		},
		{
			name: "Taylor Kim",
			role: "Business Analyst",
			model: "Claude Sonnet",
			avatarColor: "bg-gradient-to-br from-indigo-500 to-indigo-700",
			modelBg: "bg-blue-500/10",
			modelText: "text-blue-400",
			task: "Requirements & user stories",
			initials: "TK",
		},
		{
			name: "Casey Morgan",
			role: "Designer",
			model: "Fable 5.1",
			avatarColor: "bg-gradient-to-br from-pink-500 to-pink-700",
			modelBg: "bg-purple-500/10",
			modelText: "text-purple-400",
			task: "UI/UX design system",
			initials: "CM",
		},
		{
			name: "Morgan Lee",
			role: "Senior Developer",
			model: "Opus 5",
			avatarColor: "bg-gradient-to-br from-emerald-500 to-emerald-700",
			modelBg: "bg-green-500/10",
			modelText: "text-green-400",
			task: "Architecture & backend",
			initials: "ML",
		},
		{
			name: "Jordan Smith",
			role: "Senior Developer",
			model: "Opus 5",
			avatarColor: "bg-gradient-to-br from-teal-500 to-teal-700",
			modelBg: "bg-green-500/10",
			modelText: "text-green-400",
			task: "API integration & services",
			initials: "JS",
		},
		{
			name: "Riley Chen",
			role: "Junior Developer",
			model: "Haiku 4.5",
			avatarColor: "bg-gradient-to-br from-amber-500 to-amber-700",
			modelBg: "bg-orange-500/10",
			modelText: "text-orange-400",
			task: "Bug fixes & code reviews",
			initials: "RC",
		},
		{
			name: "Quinn Davis",
			role: "Tester / QA",
			model: "Claude Sonnet",
			avatarColor: "bg-gradient-to-br from-slate-500 to-slate-700",
			modelBg: "bg-blue-500/10",
			modelText: "text-blue-400",
			task: "Test planning & execution",
			initials: "QD",
		},
	];

	const detailTabs: { id: DetailTab; label: string }[] = [
		{ id: "members", label: "Team Members" },
		{ id: "projects", label: "Projects" },
		{ id: "sprint", label: "Sprint" },
		{ id: "tasks", label: "Tasks" },
		{ id: "activity", label: "Activity" },
		{ id: "metrics", label: "Metrics" },
	];

	const projects = [
		{ name: "Main E-commerce", progress: 75, due: "Apr 30" },
		{ name: "Payment Integration", progress: 60, due: "May 15" },
		{ name: "Admin Dashboard", progress: 20, due: "Jun 10" },
	];

	const activities = [
		{ name: "Jordan", action: "completed task", target: "#1234", time: "2 hours ago", color: "bg-green-400" },
		{ name: "Alex", action: "updated sprint status", target: "", time: "5 hours ago", color: "bg-blue-400" },
		{ name: "Casey", action: "delivered UI design for", target: "checkout flow", time: "Yesterday", color: "bg-purple-400" },
		{ name: "Morgan", action: "merged pull request", target: "#5678", time: "Yesterday", color: "bg-emerald-400" },
	];

	const tokenSegments = [
		{ label: "Designer", value: 784, color: "#ec4899" },
		{ label: "Senior Developer", value: 672, color: "#10b981" },
		{ label: "Senior Developer", value: 616, color: "#14b8a6" },
		{ label: "Scrum Master", value: 280, color: "#6366f1" },
		{ label: "Business Analyst", value: 252, color: "#3b82f6" },
		{ label: "Junior Developer", value: 168, color: "#f59e0b" },
		{ label: "Tester / QA", value: 140, color: "#94a3b8" },
	];

	const handleNavigate = (item: string) => {
		const navHref: Record<string, string> = {
			overview: "/",
			teams: "/teams",
			tasks: "/tasks",
			agents: "/agents",
			projects: "/projects",
			activity: "/activity",
			settings: "/settings",
			sprints: "/sprints",
		};
		router.push(navHref[item] || "/");
	};

	return (
		<Layout activeNav="overview" onNavigate={handleNavigate}>
			<div className="p-6 space-y-6">
				{/* Page Title */}
				<div>
					<h1 className="text-2xl font-bold text-white">Overview</h1>
					<p className="text-slate-400 text-sm mt-1">
						Welcome back. Here&apos;s what&apos;s happening with your AI teams today.
					</p>
				</div>

				{/* KPI Cards */}
				<div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
					{kpis.map((kpi, idx) => (
						<KpiCard key={idx} {...kpi} />
					))}
				</div>

				{/* Development Teams */}
				<div>
					<div className="flex items-center justify-between mb-4">
						<div>
							<h2 className="text-lg font-semibold text-white">Development Teams</h2>
							<p className="text-xs text-slate-500 mt-0.5">Active squads working across the organization</p>
						</div>
						<button className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-sm rounded-lg font-medium transition-colors">
							<FaPlus className="w-3 h-3" />
							Create New Team
						</button>
					</div>
					<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
						{teams.map((team, idx) => (
							<TeamCard key={idx} {...team} />
						))}
					</div>
				</div>

				{/* Team Alpha Detail */}
				<div className="bg-[#1a1d2e] border border-slate-700 rounded-xl overflow-hidden">
					{/* Team Header */}
					<div className="p-5 border-b border-slate-700">
						<div className="flex items-start justify-between mb-4">
							<div className="flex items-center gap-3">
								<div className="w-12 h-12 rounded-lg bg-blue-500 flex items-center justify-center text-white font-bold text-lg">
									A
								</div>
								<div>
									<div className="flex items-center gap-2">
										<h3 className="text-white font-semibold text-lg">Team Alpha</h3>
										<span className="text-[10px] px-2 py-0.5 rounded-full bg-green-400/10 text-green-400 border border-green-400/20">
											Active
										</span>
									</div>
									<p className="text-blue-400 text-xs">E-commerce Platform</p>
								</div>
							</div>
							<button className="text-sm text-blue-400 hover:text-blue-300 font-medium">
								View Details →
							</button>
						</div>
						<p className="text-slate-400 text-sm">
							Building the next-gen e-commerce platform with AI-powered recommendations, seamless checkout, and a unified admin experience.
						</p>
					</div>

					{/* Sprint Progress Bar */}
					<div className="p-5 border-b border-slate-700">
						<div className="flex items-center justify-between mb-2">
							<div>
								<p className="text-white text-sm font-medium">Current Sprint Progress</p>
								<p className="text-slate-500 text-xs mt-0.5">Sprint 3 of 4 · 8 days left</p>
							</div>
							<span className="text-2xl font-bold text-blue-400 tabular-nums">72%</span>
						</div>
						<div className="w-full bg-slate-800 rounded-full h-2.5">
							<div className="h-2.5 rounded-full bg-gradient-to-r from-blue-500 to-cyan-400" style={{ width: "72%" }} />
						</div>
					</div>

					{/* Sub-tabs */}
					<div className="border-b border-slate-700 px-5">
						<div className="flex items-center gap-1 overflow-x-auto scrollbar-thin">
							{detailTabs.map((tab) => (
								<button
									key={tab.id}
									onClick={() => setDetailTab(tab.id)}
									className={`px-3 py-2.5 text-sm font-medium whitespace-nowrap border-b-2 transition-colors ${
										detailTab === tab.id
											? "text-white border-blue-500"
											: "text-slate-400 border-transparent hover:text-slate-200"
									}`}
								>
									{tab.label}
								</button>
							))}
						</div>
					</div>

					{/* Tab Content */}
					<div className="p-5">
						{detailTab === "members" && (
							<div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
								{members.map((m, idx) => (
									<MemberCard key={idx} {...m} />
								))}
							</div>
						)}
						{detailTab === "projects" && (
							<div className="text-slate-400 text-sm">Projects view coming soon.</div>
						)}
						{detailTab === "sprint" && (
							<div className="text-slate-400 text-sm">Sprint view coming soon.</div>
						)}
						{detailTab === "tasks" && (
							<div className="text-slate-400 text-sm">Tasks view coming soon.</div>
						)}
						{detailTab === "activity" && (
							<div className="text-slate-400 text-sm">Activity view coming soon.</div>
						)}
						{detailTab === "metrics" && (
							<div className="text-slate-400 text-sm">Metrics view coming soon.</div>
						)}
					</div>
				</div>

				{/* Bottom Row: Projects / Activity / Token Usage */}
				<div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
					{/* Team Projects */}
					<div className="bg-[#1a1d2e] border border-slate-700 rounded-xl p-5">
						<div className="flex items-center justify-between mb-4">
							<h3 className="text-white font-semibold text-sm">Team Projects</h3>
							<button className="text-xs text-blue-400 hover:text-blue-300">View all</button>
						</div>
						<div className="space-y-3">
							{projects.map((p, idx) => (
								<div key={idx}>
									<div className="flex items-center justify-between mb-1.5">
										<p className="text-white text-sm">{p.name}</p>
										<p className="text-slate-500 text-xs">{p.due}</p>
									</div>
									<div className="flex items-center gap-2">
										<div className="flex-1 h-1.5 bg-slate-800 rounded-full overflow-hidden">
											<div
												className="h-full bg-blue-500 rounded-full"
												style={{ width: `${p.progress}%` }}
											/>
										</div>
										<span className="text-xs text-slate-400 tabular-nums w-9 text-right">{p.progress}%</span>
									</div>
								</div>
							))}
						</div>
					</div>

					{/* Recent Activity */}
					<div className="bg-[#1a1d2e] border border-slate-700 rounded-xl p-5">
						<div className="flex items-center justify-between mb-4">
							<h3 className="text-white font-semibold text-sm">Recent Activity</h3>
							<button className="text-xs text-blue-400 hover:text-blue-300">View all</button>
						</div>
						<div className="space-y-3">
							{activities.map((a, idx) => (
								<div key={idx} className="flex items-start gap-3">
									<div className={`w-2 h-2 rounded-full ${a.color} mt-1.5 flex-shrink-0`} />
									<div className="flex-1 min-w-0">
										<p className="text-sm text-slate-300">
											<span className="text-white font-medium">{a.name}</span>{" "}
											{a.action}{" "}
											{a.target && <span className="text-blue-400">{a.target}</span>}
										</p>
										<p className="text-[11px] text-slate-500 mt-0.5">{a.time}</p>
									</div>
								</div>
							))}
						</div>
					</div>

					{/* Token Usage Donut */}
					<div className="bg-[#1a1d2e] border border-slate-700 rounded-xl p-5">
						<div className="flex items-center justify-between mb-2">
							<h3 className="text-white font-semibold text-sm">Token Usage</h3>
							<span className="text-[10px] text-slate-500 uppercase tracking-wider">This Month</span>
						</div>
						<InteractiveDonut
							segments={tokenSegments}
							size={150}
							strokeWidth={18}
							centerLabel="Total Tokens"
							centerValue="2.8M"
							legendLayout="vertical"
							showLegend={true}
						/>
					</div>
				</div>
			</div>
		</Layout>
	);
}
