import React, { useState } from "react";
import { useRouter } from "next/router";
import type { ProjectStatus } from "@/types";
import Layout from "@/components/Layout";
import {
 FaSearch,
 FaPlus,
 FaFilter,
 FaMicrochip,
 FaCog,
 FaCheckCircle,
 FaTimesCircle,
 FaEllipsisH,
 FaDollarSign,
 FaUsers,
 FaClock,
 FaExternalLinkAlt,
 FaCodeBranch,
 FaEye,
 FaEdit,
 FaTrash,
 FaFolderOpen,
 FaTasks,
} from "react-icons/fa";

import InteractiveDonut from "@/components/InteractiveDonut";

// ── Types ────────────────────────────────────────────────────────────────

interface ProjectType {
 id: string;
 name: string;
 team: string;
 teamLetter: string;
 type: string;
 typeBadge: string;
 progress: number;
 members: number;
 dueDate: string;
 status: string;
 startDate: string;
 endDate: string;
 budget: string;
}

interface KanbanColumn {
 title: string;
 headerColor: string;
 bgColor: string;
 count: number;
 projects: ProjectType[];
}

interface ActivityItem {
 teamLetter: string;
 teamColor: string;
 description: string;
 timestamp: string;
}

// ── Sample Data ──────────────────────────────────────────────────────────

const KANBAN_COLUMNS: KanbanColumn[] = [
 {
 title: "Idea / Intake",
 headerColor: "bg-blue-500",
 bgColor: "bg-blue-500/5",
 count: 3,
 projects: [
 {
 id: "p1",
 name: "AI Code Reviewer",
 team: "Team Alpha",
 teamLetter: "A",
 type: "Web App",
 typeBadge: "bg-blue-400/10 text-blue-400",
 progress: 0,
 members: 3,
 dueDate: "Jan 15",
 status: "idea",
 startDate: "2025-01-01",
 endDate: "2025-01-15",
 budget: "$4.5K",
 },
 {
 id: "p2",
 name: "Mobile Wallet",
 team: "Team Gamma",
 teamLetter: "G",
 type: "Mobile",
 typeBadge: "bg-purple-400/10 text-purple-400",
 progress: 0,
 members: 4,
 dueDate: "Feb 01",
 status: "idea",
 startDate: "2025-01-10",
 endDate: "2025-02-01",
 budget: "$8.2K",
 },
 {
 id: "p3",
 name: "Customer Portal v2",
 team: "Team Beta",
 teamLetter: "B",
 type: "Web App",
 typeBadge: "bg-blue-400/10 text-blue-400",
 progress: 0,
 members: 2,
 dueDate: "Jan 20",
 status: "idea",
 startDate: "2025-01-05",
 endDate: "2025-01-20",
 budget: "$3.8K",
 },
 ],
 },
 {
 title: "Planning",
 headerColor: "bg-purple-500",
 bgColor: "bg-purple-500/5",
 count: 2,
 projects: [
 {
 id: "p4",
 name: "HR Dashboard",
 team: "Team Beta",
 teamLetter: "B",
 type: "Analytics",
 typeBadge: "bg-orange-400/10 text-orange-400",
 progress: 10,
 members: 3,
 dueDate: "Mar 10",
 status: "planning",
 startDate: "2025-01-15",
 endDate: "2025-03-10",
 budget: "$6.1K",
 },
 {
 id: "p5",
 name: "Inventory System",
 team: "Team Alpha",
 teamLetter: "A",
 type: "Web App",
 typeBadge: "bg-blue-400/10 text-blue-400",
 progress: 15,
 members: 5,
 dueDate: "Apr 01",
 status: "planning",
 startDate: "2025-02-01",
 endDate: "2025-04-01",
 budget: "$9.7K",
 },
 ],
 },
 {
 title: "In Development",
 headerColor: "bg-orange-500",
 bgColor: "bg-orange-500/5",
 count: 4,
 projects: [
 {
 id: "p6",
 name: "E-commerce Platform",
 team: "Team Alpha",
 teamLetter: "A",
 type: "Web App",
 typeBadge: "bg-blue-400/10 text-blue-400",
 progress: 72,
 members: 6,
 dueDate: "Dec 20",
 status: "active",
 startDate: "2024-09-01",
 endDate: "2024-12-20",
 budget: "$12.5K",
 },
 {
 id: "p7",
 name: "Analytics Dashboard",
 team: "Team Beta",
 teamLetter: "B",
 type: "Analytics",
 typeBadge: "bg-orange-400/10 text-orange-400",
 progress: 60,
 members: 4,
 dueDate: "Jan 30",
 status: "active",
 startDate: "2024-10-01",
 endDate: "2025-01-30",
 budget: "$7.8K",
 },
 {
 id: "p8",
 name: "Mobile Banking",
 team: "Team Gamma",
 teamLetter: "G",
 type: "Mobile",
 typeBadge: "bg-purple-400/10 text-purple-400",
 progress: 85,
 members: 5,
 dueDate: "Dec 28",
 status: "active",
 startDate: "2024-08-15",
 endDate: "2024-12-28",
 budget: "$15.3K",
 },
 {
 id: "p9",
 name: "Internal Automation",
 team: "Team Delta",
 teamLetter: "D",
 type: "Internal",
 typeBadge: "bg-green-400/10 text-green-400",
 progress: 25,
 members: 3,
 dueDate: "Feb 15",
 status: "active",
 startDate: "2024-11-01",
 endDate: "2025-02-15",
 budget: "$5.4K",
 },
 ],
 },
 {
 title: "Testing",
 headerColor: "bg-yellow-500",
 bgColor: "bg-yellow-500/5",
 count: 2,
 projects: [
 {
 id: "p10",
 name: "Authentication Service",
 team: "Team Alpha",
 teamLetter: "A",
 type: "Backend",
 typeBadge: "bg-slate-400/10 text-slate-400",
 progress: 90,
 members: 4,
 dueDate: "Dec 18",
 status: "testing",
 startDate: "2024-07-01",
 endDate: "2024-12-18",
 budget: "$6.7K",
 },
 {
 id: "p11",
 name: "Payment Gateway",
 team: "Team Beta",
 teamLetter: "B",
 type: "Backend",
 typeBadge: "bg-slate-400/10 text-slate-400",
 progress: 95,
 members: 3,
 dueDate: "Dec 15",
 status: "testing",
 startDate: "2024-08-01",
 endDate: "2024-12-15",
 budget: "$8.9K",
 },
 ],
 },
 {
 title: "Deployment",
 headerColor: "bg-green-500",
 bgColor: "bg-green-500/5",
 count: 1,
 projects: [
 {
 id: "p12",
 name: "Notification System",
 team: "Team Gamma",
 teamLetter: "G",
 type: "Backend",
 typeBadge: "bg-slate-400/10 text-slate-400",
 progress: 100,
 members: 2,
 dueDate: "Dec 12",
 status: "deployment",
 startDate: "2024-06-01",
 endDate: "2024-12-12",
 budget: "$3.2K",
 },
 ],
 },
 {
 title: "Completed",
 headerColor: "bg-slate-500",
 bgColor: "bg-slate-500/5",
 count: 3,
 projects: [
 {
 id: "p13",
 name: "Legacy Migration",
 team: "Team Alpha",
 teamLetter: "A",
 type: "Internal",
 typeBadge: "bg-green-400/10 text-green-400",
 progress: 100,
 members: 3,
 dueDate: "Nov 01",
 status: "completed",
 startDate: "2024-04-01",
 endDate: "2024-11-01",
 budget: "$4.1K",
 },
 {
 id: "p14",
 name: "Reporting Tool",
 team: "Team Beta",
 teamLetter: "B",
 type: "Analytics",
 typeBadge: "bg-orange-400/10 text-orange-400",
 progress: 100,
 members: 2,
 dueDate: "Oct 15",
 status: "completed",
 startDate: "2024-05-01",
 endDate: "2024-10-15",
 budget: "$5.6K",
 },
 {
 id: "p15",
 name: "Documentation Portal",
 team: "Team Delta",
 teamLetter: "D",
 type: "Internal",
 typeBadge: "bg-green-400/10 text-green-400",
 progress: 100,
 members: 2,
 dueDate: "Sep 30",
 status: "completed",
 startDate: "2024-03-01",
 endDate: "2024-09-30",
 budget: "$2.8K",
 },
 ],
 },
];

const RECENT_ACTIVITY: ActivityItem[] = [
 { teamLetter: "B", teamColor: "bg-purple-500", description: "Team Beta started Sprint 2", timestamp: "2h ago" },
 { teamLetter: "A", teamColor: "bg-blue-500", description: "Team Alpha completed a feature", timestamp: "4h ago" },
 { teamLetter: "G", teamColor: "bg-orange-500", description: "Team Gamma added 3 new tasks", timestamp: "6h ago" },
 { teamLetter: "D", teamColor: "bg-green-500", description: "Team Delta moved to On Hold", timestamp: "1 day ago" },
];

const PROJECT_TYPE_DATA = [
 { label: "Web Application", value: 1, color: "bg-blue-500", width: "40%" },
 { label: "Mobile Application", value: 1, color: "bg-purple-500", width: "40%" },
 { label: "Internal Tools", value: 1, color: "bg-green-500", width: "40%" },
 { label: "Data & Analytics", value: 1, color: "bg-orange-500", width: "40%" },
];

const TABLE_PROJECTS: ProjectType[] = [
 {
 id: "p6",
 name: "E-commerce Platform",
 team: "Team Alpha",
 teamLetter: "A",
 type: "Web App",
 typeBadge: "bg-blue-400/10 text-blue-400",
 progress: 72,
 members: 6,
 dueDate: "Dec 20",
 status: "active",
 startDate: "Sep 01, 2024",
 endDate: "Dec 20, 2024",
 budget: "$12,500",
 },
 {
 id: "p7",
 name: "Analytics Dashboard",
 team: "Team Beta",
 teamLetter: "B",
 type: "Analytics",
 typeBadge: "bg-orange-400/10 text-orange-400",
 progress: 60,
 members: 4,
 dueDate: "Jan 30",
 status: "active",
 startDate: "Oct 01, 2024",
 endDate: "Jan 30, 2025",
 budget: "$7,800",
 },
 {
 id: "p8",
 name: "Mobile Banking",
 team: "Team Gamma",
 teamLetter: "G",
 type: "Mobile",
 typeBadge: "bg-purple-400/10 text-purple-400",
 progress: 85,
 members: 5,
 dueDate: "Dec 28",
 status: "active",
 startDate: "Aug 15, 2024",
 endDate: "Dec 28, 2024",
 budget: "$15,300",
 },
 {
 id: "p9",
 name: "Internal Automation",
 team: "Team Delta",
 teamLetter: "D",
 type: "Internal",
 typeBadge: "bg-green-400/10 text-green-400",
 progress: 25,
 members: 3,
 dueDate: "Feb 15",
 status: "active",
 startDate: "Nov 01, 2024",
 endDate: "Feb 15, 2025",
 budget: "$5,400",
 },
 {
 id: "p10",
 name: "Authentication Service",
 team: "Team Alpha",
 teamLetter: "A",
 type: "Backend",
 typeBadge: "bg-slate-400/10 text-slate-400",
 progress: 90,
 members: 4,
 dueDate: "Dec 18",
 status: "testing",
 startDate: "Jul 01, 2024",
 endDate: "Dec 18, 2024",
 budget: "$6,700",
 },
];

// ── Progress Bar Component ───────────────────────────────────────────────

function ProgressBar({ value, color = "bg-blue-500" }: { value: number; color?: string }) {
 return (
 <div className="w-full bg-slate-700 rounded-full h-1.5">
 <div className={`${color} h-1.5 rounded-full transition-all`} style={{ width: `${value}%` }} />
 </div>
 );
}

// ── Projects Page ────────────────────────────────────────────────────────

const ProjectsPage: React.FC = () => {
 const router = useRouter();
 const [search, setSearch] = useState("");
 const [teamFilter, setTeamFilter] = useState("All Teams");
 const [statusFilter, setStatusFilter] = useState("All Status");

 const handleNavigate = (_navId: string) => {
 router.push("/");
 };

 const statsCards = [
 { label: "Total Projects", value: "12", icon: <FaFolderOpen />, color: "text-blue-400", bg: "bg-blue-400/10" },
 { label: "Active", value: "8", icon: <FaCheckCircle />, color: "text-green-400", bg: "bg-green-400/10" },
 { label: "On Hold", value: "2", icon: <FaClock />, color: "text-orange-400", bg: "bg-orange-400/10" },
 { label: "At Risk", value: "1", icon: <FaTimesCircle />, color: "text-red-400", bg: "bg-red-400/10" },
 { label: "Completed", value: "3", icon: <FaCheckCircle />, color: "text-slate-400", bg: "bg-slate-400/10" },
 { label: "Total Estimated Cost", value: "$48.2K", icon: <FaDollarSign />, color: "text-emerald-400", bg: "bg-emerald-400/10" },
 ];

 const quickActions = [
 { label: "New Project", icon: <FaPlus /> },
 { label: "Import CSV", icon: <FaCodeBranch /> },
 { label: "Export Report", icon: <FaExternalLinkAlt /> },
 { label: "Project Templates", icon: <FaTasks /> },
 ];

 const progressColor = (pct: number) => {
 if (pct >= 80) return "bg-green-500";
 if (pct >= 40) return "bg-blue-500";
 if (pct >= 15) return "bg-orange-500";
 return "bg-slate-500";
 };

 return (
 <Layout activeNav="projects" onNavigate={handleNavigate}>
 <div className="px-6 space-y-6">
 {/* Page Header */}
 <div className="flex items-center justify-between">
 <div>
 <h1 className="text-2xl font-bold text-white">Projects</h1>
 <p className="text-sm text-slate-400 mt-1">Track project pipeline, status, and team progress.</p>
 </div>
 </div>

 {/* Action Bar */}
 <div className="flex flex-wrap items-center gap-3">
 <div className="relative flex-1 min-w-[200px] max-w-sm">
 <FaSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 text-xs" />
 <input
 type="text"
 placeholder="Search projects..."
 value={search}
 onChange={(e) => setSearch(e.target.value)}
 className="w-full bg-[#1a1d2e] border border-slate-700 rounded-md pl-9 pr-4 py-2 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-500"
 />
 </div>
 <select
 value={teamFilter}
 onChange={(e) => setTeamFilter(e.target.value)}
 className="bg-[#1a1d2e] border border-slate-700 rounded-md px-3 py-2 text-sm text-slate-300 focus:outline-none focus:border-blue-500"
 >
 <option>All Teams</option>
 <option>Team Alpha</option>
 <option>Team Beta</option>
 <option>Team Gamma</option>
 <option>Team Delta</option>
 </select>
 <select
 value={statusFilter}
 onChange={(e) => setStatusFilter(e.target.value)}
 className="bg-[#1a1d2e] border border-slate-700 rounded-md px-3 py-2 text-sm text-slate-300 focus:outline-none focus:border-blue-500"
 >
 <option>All Status</option>
 <option>Active</option>
 <option>On Hold</option>
 <option>At Risk</option>
 <option>Completed</option>
 </select>
 <button className="bg-blue-600 hover:bg-blue-500 text-white text-sm px-4 py-2 rounded-md flex items-center gap-2 transition-colors">
 <FaPlus className="w-3 h-3" />
 Add Project
 </button>
 </div>

 {/* Stats Row */}
 <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
 {statsCards.map((s) => (
 <div key={s.label} className="bg-[#1a1d2e] border border-slate-700 rounded-lg p-4">
 <div className="flex items-start justify-between">
 <div>
 <p className="text-xs text-slate-400 mb-1">{s.label}</p>
 <p className="text-xl font-bold text-white">{s.value}</p>
 </div>
 <div className={`p-2 rounded-lg ${s.bg} ${s.color}`}>
 {React.cloneElement(s.icon as React.ReactElement, { className: "w-4 h-4" })}
 </div>
 </div>
 </div>
 ))}
 </div>

 {/* Pipeline + Sidebar */}
 <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
 {/* Kanban Pipeline */}
 <div className="xl:col-span-3 overflow-x-auto">
 <div className="flex gap-4 min-w-max">
 {KANBAN_COLUMNS.map((col) => (
 <div key={col.title} className={`w-64 flex-shrink-0 rounded-lg border border-slate-700 ${col.bgColor}`}>
 {/* Column Header */}
 <div className={`${col.headerColor} text-white text-sm font-semibold px-3 py-2 rounded-t-lg flex items-center justify-between`}>
 <span>{col.title}</span>
 <span className="bg-white/20 text-xs px-2 py-0.5 rounded-full">{col.count}</span>
 </div>
 {/* Cards */}
 <div className="p-2 space-y-2">
 {col.projects.map((proj) => (
 <div
 key={proj.id}
 className="bg-[#1a1d2e] border border-slate-700 rounded-md p-3 hover:border-slate-600 cursor-pointer transition-colors"
 >
 <div className="flex items-start justify-between mb-1">
 <div>
 <span className="text-sm font-semibold text-white">{proj.name}</span>
 <p className="text-xs text-slate-500">{proj.team}</p>
 </div>
 <span className={`text-[10px] px-1.5 py-0.5 rounded-full ${proj.typeBadge}`}>{proj.type}</span>
 </div>
 <div className="mt-2">
 <div className="flex items-center justify-between mb-1">
 <span className="text-[10px] text-slate-500">Progress</span>
 <span className="text-[10px] text-slate-400">{proj.progress}%</span>
 </div>
 <ProgressBar value={proj.progress} color={progressColor(proj.progress)} />
 </div>
 <div className="flex items-center justify-between mt-2 text-[10px] text-slate-500">
 <span className="flex items-center gap-1">
 <FaUsers className="w-2.5 h-2.5" />
 {proj.members} members
 </span>
 <span className="flex items-center gap-1">
 <FaClock className="w-2.5 h-2.5" />
 {proj.dueDate}
 </span>
 </div>
 </div>
 ))}
 </div>
 </div>
 ))}
 </div>
 </div>

 {/* Right Sidebar */}
 <div className="space-y-6">
 {/* Project Overview Donut */}
 <div className="bg-[#1a1d2e] border border-slate-700 rounded-lg p-4">
 <h3 className="text-sm font-semibold text-white mb-3">Project Overview</h3>
 <InteractiveDonut
 segments={[
 { label: "Active", value: 8, color: "#22c55e" },
 { label: "On Hold", value: 2, color: "#f97316" },
 { label: "At Risk", value: 1, color: "#ef4444" },
 { label: "Completed", value: 3, color: "#94a3b8" },
 ]}
 size={140}
 strokeWidth={22}
 centerLabel="Projects"
 showLegend={true}
/>
 </div>

 {/* Projects by Type */}
 <div className="bg-[#1a1d2e] border border-slate-700 rounded-lg p-4">
 <h3 className="text-sm font-semibold text-white mb-3">Projects by Type</h3>
 <div className="space-y-3">
 {PROJECT_TYPE_DATA.map((item) => (
 <div key={item.label}>
 <div className="flex items-center justify-between text-xs mb-1">
 <span className="text-slate-400">{item.label}</span>
 <span className="text-slate-500">{item.value}</span>
 </div>
 <div className="w-full bg-slate-700 rounded-full h-2">
 <div className={`${item.color} h-2 rounded-full`} style={{ width: item.width }} />
 </div>
 </div>
 ))}
 </div>
 </div>

 {/* Recent Team Activity */}
 <div className="bg-[#1a1d2e] border border-slate-700 rounded-lg p-4">
 <h3 className="text-sm font-semibold text-white mb-3">Recent Team Activity</h3>
 <div className="space-y-3">
 {RECENT_ACTIVITY.map((item, i) => (
 <div key={i} className="flex items-start gap-3">
 <div className={`w-7 h-7 rounded-full ${item.teamColor} flex items-center justify-center text-white text-xs font-bold flex-shrink-0`}>
 {item.teamLetter}
 </div>
 <div className="flex-1 min-w-0">
 <p className="text-xs text-slate-300 truncate">{item.description}</p>
 <p className="text-[10px] text-slate-500">{item.timestamp}</p>
 </div>
 </div>
 ))}
 </div>
 </div>

 {/* Quick Actions */}
 <div className="bg-[#1a1d2e] border border-slate-700 rounded-lg p-4">
 <h3 className="text-sm font-semibold text-white mb-3">Quick Actions</h3>
 <div className="space-y-1">
 {quickActions.map((action) => (
 <button
 key={action.label}
 className="w-full flex items-center gap-2 px-3 py-2 text-sm text-slate-400 hover:text-white hover:bg-slate-800 rounded-md transition-colors text-left"
 >
 {action.icon}
 {action.label}
 </button>
 ))}
 </div>
 </div>
 </div>
 </div>

 {/* All Projects Table */}
 <div className="bg-[#1a1d2e] border border-slate-700 rounded-lg overflow-hidden">
 <div className="px-4 py-3 border-b border-slate-700">
 <h3 className="text-sm font-semibold text-white">All Projects</h3>
 </div>
 <div className="overflow-x-auto">
 <table className="w-full text-sm">
 <thead>
 <tr className="text-xs text-slate-500 border-b border-slate-700">
 <th className="text-left px-4 py-2 font-medium">#</th>
 <th className="text-left px-4 py-2 font-medium">Project Name</th>
 <th className="text-left px-4 py-2 font-medium">Team</th>
 <th className="text-left px-4 py-2 font-medium">Type</th>
 <th className="text-left px-4 py-2 font-medium">Status</th>
 <th className="text-left px-4 py-2 font-medium">Progress</th>
 <th className="text-left px-4 py-2 font-medium">Start Date</th>
 <th className="text-left px-4 py-2 font-medium">End Date</th>
 <th className="text-left px-4 py-2 font-medium">Budget</th>
 <th className="text-left px-4 py-2 font-medium">Actions</th>
 </tr>
 </thead>
 <tbody>
 {TABLE_PROJECTS.map((proj, idx) => (
 <tr key={proj.id} className="border-b border-slate-700/50 hover:bg-slate-800/30">
 <td className="px-4 py-3 text-slate-500">{idx + 1}</td>
 <td className="px-4 py-3 text-white font-medium">{proj.name}</td>
 <td className="px-4 py-3 text-slate-400">
 <span className="flex items-center gap-2">
 <span className="w-5 h-5 rounded-full bg-slate-600 flex items-center justify-center text-[10px] text-white font-bold">
 {proj.teamLetter}
 </span>
 {proj.team}
 </span>
 </td>
 <td className="px-4 py-3">
 <span className={`text-xs px-2 py-0.5 rounded-full ${proj.typeBadge}`}>{proj.type}</span>
 </td>
 <td className="px-4 py-3">
 <span className={`text-xs px-2 py-0.5 rounded-full ${
 proj.status === "active" ? "bg-green-400/10 text-green-400" :
 proj.status === "completed" ? "bg-slate-400/10 text-slate-400" :
 "bg-orange-400/10 text-orange-400"
 }`}>
 {proj.status.charAt(0).toUpperCase() + proj.status.slice(1)}
 </span>
 </td>
 <td className="px-4 py-3">
 <div className="flex items-center gap-2">
 <div className="w-16">
 <ProgressBar value={proj.progress} color={progressColor(proj.progress)} />
 </div>
 <span className="text-xs text-slate-400 w-8">{proj.progress}%</span>
 </div>
 </td>
 <td className="px-4 py-3 text-slate-400">{proj.startDate}</td>
 <td className="px-4 py-3 text-slate-400">{proj.endDate}</td>
 <td className="px-4 py-3 text-slate-400">{proj.budget}</td>
 <td className="px-4 py-3">
 <div className="flex items-center gap-2">
 <button className="text-slate-400 hover:text-blue-400 transition-colors" title="View">
 <FaEye className="w-3.5 h-3.5" />
 </button>
 <button className="text-slate-400 hover:text-yellow-400 transition-colors" title="Edit">
 <FaEdit className="w-3.5 h-3.5" />
 </button>
 <button className="text-slate-400 hover:text-red-400 transition-colors" title="Delete">
 <FaTrash className="w-3.5 h-3.5" />
 </button>
 <button className="text-slate-400 hover:text-white transition-colors" title="More">
 <FaEllipsisH className="w-3.5 h-3.5" />
 </button>
 </div>
 </td>
 </tr>
 ))}
 </tbody>
 </table>
 </div>
 </div>
 </div>
 </Layout>
 );
};

export default ProjectsPage;
