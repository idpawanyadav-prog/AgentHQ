import React from "react";
import { useRouter } from "next/router";
import type { Agent } from "@/types";
import Layout from "@/components/Layout";
import AgentCard from "@/components/AgentCard";
import { FaPlus, FaSearch, FaSlidersH } from "react-icons/fa";

const SAMPLE_AGENTS: Agent[] = [
 {
 id: "agent-1",
 name: "Claude Dev #1",
 type: "anthropic",
 model: "claude-sonnet-4-5",
 memberId: "m-3",
 config: { temperature: 0.7, maxTokens: 4096 },
 status: "working",
 createdAt: new Date(Date.now() - 86400000 * 30).toISOString(),
 updatedAt: new Date().toISOString(),
 },
 {
 id: "agent-2",
 name: "GPT Assistant #1",
 type: "openai",
 model: "gpt-4o",
 memberId: "m-4",
 config: { temperature: 0.7, maxTokens: 4096 },
 status: "idle",
 createdAt: new Date(Date.now() - 86400000 * 20).toISOString(),
 updatedAt: new Date().toISOString(),
 },
 {
 id: "agent-3",
 name: "Claude Dev #2",
 type: "anthropic",
 model: "claude-opus-4",
 memberId: "m-7",
 config: { temperature: 0.5, maxTokens: 8192 },
 status: "working",
 createdAt: new Date(Date.now() - 86400000 * 15).toISOString(),
 updatedAt: new Date().toISOString(),
 },
 {
 id: "agent-4",
 name: "GPT Coder",
 type: "openai",
 model: "gpt-4o-mini",
 memberId: "m-8",
 config: { temperature: 0.3, maxTokens: 2048 },
 status: "error",
 createdAt: new Date(Date.now() - 86400000 * 10).toISOString(),
 updatedAt: new Date().toISOString(),
 },
];

const AgentsPage: React.FC = () => {
 const router = useRouter();

	const handleNavigate = (item: string) => {
	const navHref: Record<string, string> = {
		overview: "/",
		teams: "/teams",
		tasks: "/tasks",
		agents: "/agents",
		projects: "/projects",
		activity: "/activity",
		settings: "/settings",
		sprints: "/sprints",
	};
	router.push(navHref[item] || "/");
	};

 const handleAgentClick = (agentId: string) => {
 router.push(`/agents/${agentId}`);
 };

 const workingCount = SAMPLE_AGENTS.filter((a) => a.status === "working").length;
 const idleCount = SAMPLE_AGENTS.filter((a) => a.status === "idle").length;
 const errorCount = SAMPLE_AGENTS.filter((a) => a.status === "error").length;

 return (
 <Layout activeNav="agents" onNavigate={handleNavigate}>
 <div className="space-y-6">
 <div className="flex items-center justify-between">
 <div>
 <h1 className="text-2xl font-bold text-white">Agents</h1>
 <p className="text-sm text-slate-400 mt-1">Manage AI agents, their models, and performance.</p>
 </div>
 <div className="flex items-center gap-2">
 <button className="text-xs px-3 py-2 rounded bg-blue-600 hover:bg-blue-500 text-white flex items-center gap-1">
 <FaPlus className="w-3 h-3" />
 Add Agent
 </button>
 </div>
 </div>

 <div className="flex items-center gap-6">
 <div className="flex items-center gap-4">
 <div className="flex items-center gap-1.5">
 <span className="w-2 h-2 rounded-full bg-green-400" />
 <span className="text-sm text-slate-400">{workingCount} working</span>
 </div>
 <div className="flex items-center gap-1.5">
 <span className="w-2 h-2 rounded-full bg-slate-400" />
 <span className="text-sm text-slate-400">{idleCount} idle</span>
 </div>
 <div className="flex items-center gap-1.5">
 <span className="w-2 h-2 rounded-full bg-red-400" />
 <span className="text-sm text-slate-400">{errorCount} error</span>
 </div>
 </div>
 </div>

 <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
 {SAMPLE_AGENTS.map((agent) => (
 <div key={agent.id} onClick={() => handleAgentClick(agent.id)} className="cursor-pointer">
 <AgentCard agent={agent} />
 </div>
 ))}
 </div>
 </div>
 </Layout>
 );
};

export default AgentsPage;
