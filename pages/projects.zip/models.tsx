'use client';

import React, { useState } from "react";
import { useRouter } from "next/router";
import Layout from "@/components/Layout";
import InteractiveDonut from "@/components/InteractiveDonut";
import {
 FaSearch,
 FaPlus,
 FaFilter,
 FaMicrochip,
 FaCog,
 FaCheckCircle,
 FaTimesCircle,
 FaEllipsisH,
 FaDollarSign,
 FaUsers,
 FaClock,
 FaBolt,
 FaCopy,
 FaDownload,
 FaChartLine,
 FaExternalLinkAlt,
 FaEye,
 FaEdit,
 FaTrash,
 FaPlay,
} from "react-icons/fa";

// ── Types ────────────────────────────────────────────────────────────────

interface ModelRow {
 id: string;
 name: string;
 provider: string;
 providerBadge: string;
 capability: string;
 capabilityBadge: string;
 contextWindow: string;
 inputCost: string;
 outputCost: string;
 avgSpeed: string;
 status: string;
 assignments: number;
 modelId: string;
 maxOutput: string;
 modalities: string[];
 features: string[];
}

interface ProviderRow {
 name: string;
 value: number;
 pct: number;
 color: string;
}

interface AssignmentRow {
 name: string;
 value: number;
 color: string;
 width: string;
}

// ── Sample Data ──────────────────────────────────────────────────────────

const MODELS: ModelRow[] = [
 {
 id: "m1",
 name: "Claude Opus 5",
 provider: "Anthropic",
 providerBadge: "bg-orange-400/10 text-orange-400",
 capability: "High",
 capabilityBadge: "bg-blue-400/10 text-blue-400",
 contextWindow: "200K",
 inputCost: "$15.00",
 outputCost: "$75.00",
 avgSpeed: "2.4s",
 status: "Active",
 assignments: 6,
 modelId: "claude-opus-5",
 maxOutput: "16,384",
 modalities: ["Text input", "Text output", "Vision input"],
 features: ["Reasoning", "Code generation", "Creative writing", "Vision"],
 },
 {
 id: "m2",
 name: "Claude Fable 5.1",
 provider: "Anthropic",
 providerBadge: "bg-orange-400/10 text-orange-400",
 capability: "Highest",
 capabilityBadge: "bg-purple-400/10 text-purple-400",
 contextWindow: "1M",
 inputCost: "$3.00",
 outputCost: "$15.00",
 avgSpeed: "3.1s",
 status: "Active",
 assignments: 2,
 modelId: "claude-fable-5-1",
 maxOutput: "8,192",
 modalities: ["Text input", "Text output", "Vision input"],
 features: ["Reasoning", "Code generation", "Creative writing", "Long context", "Vision"],
 },
 {
 id: "m3",
 name: "Claude Sonnet 4",
 provider: "Anthropic",
 providerBadge: "bg-orange-400/10 text-orange-400",
 capability: "Balanced",
 capabilityBadge: "bg-green-400/10 text-green-400",
 contextWindow: "200K",
 inputCost: "$3.00",
 outputCost: "$15.00",
 avgSpeed: "1.8s",
 status: "Active",
 assignments: 12,
 modelId: "claude-sonnet-4",
 maxOutput: "8,192",
 modalities: ["Text input", "Text output"],
 features: ["Reasoning", "Code generation", "Long context"],
 },
 {
 id: "m4",
 name: "Claude Haiku",
 provider: "Anthropic",
 providerBadge: "bg-orange-400/10 text-orange-400",
 capability: "Fast",
 capabilityBadge: "bg-yellow-400/10 text-yellow-400",
 contextWindow: "200K",
 inputCost: "$0.25",
 outputCost: "$1.25",
 avgSpeed: "0.6s",
 status: "Active",
 assignments: 4,
 modelId: "claude-haiku",
 maxOutput: "4,096",
 modalities: ["Text input", "Text output"],
 features: ["Fast inference", "Summarization"],
 },
 {
 id: "m5",
 name: "GPT-4o",
 provider: "OpenAI",
 providerBadge: "bg-teal-400/10 text-teal-400",
 capability: "High",
 capabilityBadge: "bg-blue-400/10 text-blue-400",
 contextWindow: "128K",
 inputCost: "$2.50",
 outputCost: "$10.00",
 avgSpeed: "1.5s",
 status: "Active",
 assignments: 2,
 modelId: "gpt-4o",
 maxOutput: "4,096",
 modalities: ["Text input", "Text output", "Vision input"],
 features: ["Reasoning", "Code generation", "Vision"],
 },
 {
 id: "m6",
 name: "GPT-4o mini",
 provider: "OpenAI",
 providerBadge: "bg-teal-400/10 text-teal-400",
 capability: "Balanced",
 capabilityBadge: "bg-green-400/10 text-green-400",
 contextWindow: "128K",
 inputCost: "$0.15",
 outputCost: "$0.60",
 avgSpeed: "0.9s",
 status: "Active",
 assignments: 1,
 modelId: "gpt-4o-mini",
 maxOutput: "4,096",
 modalities: ["Text input", "Text output"],
 features: ["Fast inference", "Lightweight"],
 },
 {
 id: "m7",
 name: "o3-mini",
 provider: "OpenAI",
 providerBadge: "bg-teal-400/10 text-teal-400",
 capability: "Reasoning",
 capabilityBadge: "bg-red-400/10 text-red-400",
 contextWindow: "200K",
 inputCost: "$1.10",
 outputCost: "$4.40",
 avgSpeed: "4.2s",
 status: "Active",
 assignments: 1,
 modelId: "o3-mini",
 maxOutput: "4,096",
 modalities: ["Text input", "Text output"],
 features: ["Reasoning", "Chain-of-thought"],
 },
];

const STATS = [
 { label: "Models Configured", value: "7", icon: <FaMicrochip />, color: "text-blue-400", bg: "bg-blue-400/10" },
 { label: "Active Assignments", value: "28", icon: <FaUsers />, color: "text-green-400", bg: "bg-green-400/10" },
 { label: "Est. Monthly Cost", value: "$128.50", icon: <FaDollarSign />, color: "text-emerald-400", bg: "bg-emerald-400/10" },
 { label: "Tokens Used (7d)", value: "2.4M", icon: <FaChartLine />, color: "text-yellow-400", bg: "bg-yellow-400/10" },
 { label: "Avg Response Time", value: "1.8s", icon: <FaClock />, color: "text-purple-400", bg: "bg-purple-400/10" },
];

const TABS = ["All Models", "By Provider", "Usage Analytics", "Cost Comparison", "Performance", "Assignments"];

// Selected model detail (Claude Fable 5.1)
const SELECTED_MODEL: ModelRow = MODELS[1];

const COST_DATA: ProviderRow[] = [
 { name: "Opus 5", value: 36.12, pct: 28, color: "#f97316" },
 { name: "Fable 5.1", value: 32.40, pct: 25, color: "#a855f7" },
 { name: "Sonnet 4", value: 21.80, pct: 17, color: "#3b82f6" },
 { name: "Haiku", value: 12.40, pct: 10, color: "#eab308" },
 { name: "GPT-4o", value: 10.22, pct: 8, color: "#14b8a6" },
 { name: "GPT-4o mini", value: 6.45, pct: 5, color: "#22c55e" },
 { name: "o3-mini", value: 4.10, pct: 3, color: "#ef4444" },
 { name: "Others", value: 4.91, pct: 4, color: "#64748b" },
];

const ASSIGNMENT_DATA: AssignmentRow[] = [
 { name: "Sonnet 4", value: 12, color: "bg-blue-500", width: "92%" },
 { name: "Opus 5", value: 6, color: "bg-orange-500", width: "46%" },
 { name: "Haiku", value: 4, color: "bg-yellow-500", width: "31%" },
 { name: "Fable 5.1", value: 2, color: "bg-purple-500", width: "15%" },
 { name: "GPT-4o", value: 2, color: "bg-teal-500", width: "15%" },
 { name: "o3-mini", value: 1, color: "bg-red-500", width: "8%" },
 { name: "GPT-4o mini", value: 1, color: "bg-green-500", width: "8%" },
];

const USAGE_7D = [120, 340, 280, 420, 380, 510, 470];

// ── SVG Area Chart ───────────────────────────────────────────────────────

function AreaChart() {
 const data = USAGE_7D;
 const labels = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
 const max = Math.max(...data);
 const min = Math.min(...data);
 const range = max - min || 1;
 const padding = 20;
 const w = 320;
 const h = 150;
 const chartW = w - padding * 2;
 const chartH = h - padding * 2;

 const [tooltip, setTooltip] = useState<{x:number;y:number;val:number;label:string}|null>(null);

 const points = data.map((v, i) => ({
 x: padding + (i / (data.length - 1)) * chartW,
 y: padding + chartH - ((v - min) / range) * chartH,
 }));

 const linePath = points.map((p, i) => (i === 0 ? `M ${p.x} ${p.y}` : `L ${p.x} ${p.y}`)).join(" ");
 const areaPath = linePath + ` L ${points[points.length - 1].x} ${padding + chartH} L ${points[0].x} ${padding + chartH} Z`;

 return (
 <svg viewBox={`0 0 ${w} ${h}`} className="w-full">
 <defs>
 <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
 <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.3" />
 <stop offset="100%" stopColor="#3b82f6" stopOpacity="0" />
 </linearGradient>
 </defs>
 {[0, 0.25, 0.5, 0.75, 1].map((frac) => {
 const y = padding + chartH - frac * chartH;
 return (
 <line key={frac} x1={padding} x2={w - padding} y1={y} y2={y} stroke="#334155" strokeWidth="0.5" />
 );
 })}
 <path d={areaPath} fill="url(#areaGrad)" />
 <path d={linePath} fill="none" stroke="#3b82f6" strokeWidth="2" />
 {points.map((p, i) => (
 <circle key={i} cx={p.x} cy={p.y} r="12" fill="transparent"
 onMouseEnter={() => setTooltip({ x: p.x, y: p.y, val: data[i], label: labels[i] })}
 onMouseLeave={() => setTooltip(null)}
 style={{ cursor: "pointer" }} />
 ))}
 {points.map((p, i) => (
 <circle key={i} cx={p.x} cy={p.y} r="3" fill="#3b82f6" stroke="#1a1d2e" strokeWidth="1.5"
 style={{ pointerEvents: "none" }} />
 ))}
 {tooltip && (
 <g>
 <rect x={tooltip.x - 28} y={tooltip.y - 38} width="56" height="26" rx="4" fill="#1e293b" stroke="#334155" strokeWidth="1" />
 <text x={tooltip.x} y={tooltip.y - 22} textAnchor="middle" fill="#94a3b8" fontSize="9">{tooltip.label}</text>
 <text x={tooltip.x} y={tooltip.y - 10} textAnchor="middle" fill="#3b82f6" fontSize="10" fontWeight="bold">{tooltip.val}</text>
 </g>
 )}
 {points.map((p, i) => (
 <text key={i} x={p.x} y={h - 4} textAnchor="middle" style={{ fontSize: 10, fill: "#64748b" }}>
 {labels[i]}
 </text>
 ))}
 {[0, 0.5, 1].map((frac) => {
 const y = padding + chartH - frac * chartH;
 const val = Math.round(min + frac * range);
 return (
 <text key={frac} x={padding - 4} y={y + 3} textAnchor="end" style={{ fontSize: 9, fill: "#64748b" }}>
 {val}
 </text>
 );
 })}
 </svg>
 );
}

// ── Main Models Page ─────────────────────────────────────────────────────

const ModelsPage: React.FC = () => {
 const router = useRouter();
 const [search, setSearch] = useState("");
 const [providerFilter, setProviderFilter] = useState("All Providers");
 const [selectedModel, setSelectedModel] = useState<ModelRow>(SELECTED_MODEL);
 const [sidebarTab, setSidebarTab] = useState("Overview");
 const [activeTab, setActiveTab] = useState("All Models");

 const handleNavigate = (navId: string) => {
 const navHref: Record<string, string> = {
 overview: "/",
 teams: "/teams",
 tasks: "/tasks",
 agents: "/agents",
 projects: "/projects",
 activity: "/activity",
 settings: "/settings",
 sprints: "/sprints",
 };
 router.push(navHref[navId] || "/");
 };

 const progressColor = (pct: number) => {
 if (pct >= 90) return "bg-green-500";
 if (pct >= 50) return "bg-blue-500";
 if (pct >= 20) return "bg-orange-500";
 return "bg-slate-500";
 };

 return (
 <Layout activeNav="models" onNavigate={handleNavigate}>
 <div className="px-6 space-y-6">
 {/* Page Header */}
 <div className="flex items-center justify-between">
 <div>
 <h1 className="text-2xl font-bold text-white">Models</h1>
 <p className="text-sm text-slate-400 mt-1">Manage AI models, configure providers, and monitor performance across your organization.</p>
 </div>
 </div>

 {/* Action Bar */}
 <div className="flex flex-wrap items-center gap-3">
 <div className="relative flex-1 min-w-[200px] max-w-sm">
 <FaSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 text-xs" />
 <input
 type="text"
 placeholder="Search models..."
 value={search}
 onChange={(e) => setSearch(e.target.value)}
 className="w-full bg-[#1a1d2e] border border-slate-700 rounded-md pl-9 pr-4 py-2 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-500"
 />
 </div>
 <select
 value={providerFilter}
 onChange={(e) => setProviderFilter(e.target.value)}
 className="bg-[#1a1d2e] border border-slate-700 rounded-md px-3 py-2 text-sm text-slate-300 focus:outline-none focus:border-blue-500"
 >
 <option>All Providers</option>
 <option>Anthropic</option>
 <option>OpenAI</option>
 </select>
 <button className="bg-blue-600 hover:bg-blue-500 text-white text-sm px-4 py-2 rounded-md flex items-center gap-2 transition-colors">
 <FaPlus className="w-3 h-3" />
 Add Model
 </button>
 </div>

 {/* Stats Row */}
 <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
 {STATS.map((s) => (
 <div key={s.label} className="bg-[#1a1d2e] border border-slate-700 rounded-lg p-4">
 <div className="flex items-start justify-between">
 <div>
 <p className="text-xs text-slate-400 mb-1">{s.label}</p>
 <p className="text-xl font-bold text-white">{s.value}</p>
 </div>
 <div className={`p-2 rounded-lg ${s.bg} ${s.color}`}>
 {React.cloneElement(s.icon as React.ReactElement, { className: "w-4 h-4" })}
 </div>
 </div>
 </div>
 ))}
 </div>

 {/* Filter Tabs */}
 <div className="flex flex-wrap items-center gap-1 border-b border-slate-700">
 {TABS.map((tab) => (
 <button
 key={tab}
 onClick={() => setActiveTab(tab)}
 className={`px-3 py-2 text-sm rounded-t-md transition-colors ${
 activeTab === tab
 ? "text-white border-b-2 border-blue-500 bg-[#1a1d2e]"
 : "text-slate-400 hover:text-white"
 }`}
 >
 {tab}
 </button>
 ))}
 </div>

 {/* Table + Sidebar */}
 <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
 {/* Models Table */}
 <div className="xl:col-span-3 bg-[#1a1d2e] border border-slate-700 rounded-lg overflow-hidden">
 <div className="overflow-x-auto">
 <table className="w-full text-sm">
 <thead>
 <tr className="text-xs text-slate-500 border-b border-slate-700">
 <th className="text-left px-4 py-2 font-medium">Model</th>
 <th className="text-left px-4 py-2 font-medium">Provider</th>
 <th className="text-left px-4 py-2 font-medium">Capability</th>
 <th className="text-left px-4 py-2 font-medium">Context Window</th>
 <th className="text-left px-4 py-2 font-medium">Input Cost/1M</th>
 <th className="text-left px-4 py-2 font-medium">Output Cost/1M</th>
 <th className="text-left px-4 py-2 font-medium">Avg Speed</th>
 <th className="text-left px-4 py-2 font-medium">Status</th>
 <th className="text-left px-4 py-2 font-medium">Assignments</th>
 <th className="text-left px-4 py-2 font-medium">Actions</th>
 </tr>
 </thead>
 <tbody>
 {MODELS.map((model) => (
 <tr key={model.id} className="border-b border-slate-700/50 hover:bg-slate-800/30">
 <td className="px-4 py-3 text-white font-medium">{model.name}</td>
 <td className="px-4 py-3">
 <span className={`text-xs px-2 py-0.5 rounded-full ${model.providerBadge}`}>{model.provider}</span>
 </td>
 <td className="px-4 py-3">
 <span className={`text-xs px-2 py-0.5 rounded-full ${model.capabilityBadge}`}>{model.capability}</span>
 </td>
 <td className="px-4 py-3 text-slate-400">{model.contextWindow}</td>
 <td className="px-4 py-3 text-slate-400">{model.inputCost}</td>
 <td className="px-4 py-3 text-slate-400">{model.outputCost}</td>
 <td className="px-4 py-3 text-slate-400">{model.avgSpeed}</td>
 <td className="px-4 py-3">
 <span className="flex items-center gap-1 text-xs text-green-400">
 <span className="w-1.5 h-1.5 rounded-full bg-green-400" />
 {model.status}
 </span>
 </td>
 <td className="px-4 py-3 text-slate-400">{model.assignments}</td>
 <td className="px-4 py-3">
 <div className="flex items-center gap-2">
 <button className="text-slate-400 hover:text-blue-400 transition-colors" title="View">
 <FaEye className="w-3.5 h-3.5" />
 </button>
 <button
 onClick={() => setSelectedModel(model)}
 className="text-slate-400 hover:text-yellow-400 transition-colors"
 title="Edit"
 >
 <FaEdit className="w-3.5 h-3.5" />
 </button>
 <button className="text-slate-400 hover:text-red-400 transition-colors" title="Delete">
 <FaTrash className="w-3.5 h-3.5" />
 </button>
 <button className="text-slate-400 hover:text-white transition-colors" title="More">
 <FaEllipsisH className="w-3.5 h-3.5" />
 </button>
 </div>
 </td>
 </tr>
 ))}
 </tbody>
 </table>
 </div>
 </div>

 {/* Right Sidebar: Selected Model Detail */}
 <div className="space-y-6">
 <div className="bg-[#1a1d2e] border border-slate-700 rounded-lg overflow-hidden">
 {/* Header */}
 <div className="p-4 border-b border-slate-700">
 <div className="flex items-center justify-between">
 <div>
 <h3 className="text-base font-semibold text-white">{selectedModel.name}</h3>
 <span className={`text-xs px-2 py-0.5 rounded-full ${selectedModel.providerBadge}`}>
 {selectedModel.provider}
 </span>
 </div>
 </div>
 {/* Tabs */}
 <div className="flex items-center gap-1 mt-3">
 {["Overview", "Usage", "Assignments", "Settings"].map((tab) => (
 <button
 key={tab}
 onClick={() => setSidebarTab(tab)}
 className={`px-2 py-1 text-xs rounded transition-colors ${
 sidebarTab === tab ? "bg-blue-600 text-white" : "text-slate-400 hover:text-white"
 }`}
 >
 {tab}
 </button>
 ))}
 </div>
 </div>

 {/* Overview Content */}
 {sidebarTab === "Overview" && (
 <div className="p-4 space-y-3">
 <div className="space-y-2">
 <InfoRow label="Model ID" value={selectedModel.modelId} />
 <InfoRow label="Provider" value={selectedModel.provider} />
 <InfoRow label="Context Window" value={`${selectedModel.contextWindow} tokens`} />
 <InfoRow label="Max Output" value={`${selectedModel.maxOutput} tokens`} />
 <InfoRow label="Modalities" value={selectedModel.modalities.join(", ")} />
 <InfoRow label="Capabilities" value={selectedModel.features.join(", ")} />
 </div>

 <div className="flex items-center gap-2 pt-2">
 <button className="bg-blue-600 hover:bg-blue-500 text-white text-xs px-3 py-1.5 rounded transition-colors">
 Edit Model
 </button>
 <button className="border border-slate-600 text-slate-300 hover:text-white text-xs px-3 py-1.5 rounded transition-colors">
 Deactivate
 </button>
 </div>

 <div className="border-t border-slate-700 pt-3">
 <p className="text-xs text-slate-500 mb-2">Quick Actions</p>
 <div className="grid grid-cols-2 gap-2">
 <button className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-white bg-slate-800 rounded px-2 py-1.5 transition-colors">
 <FaCopy className="w-3 h-3" /> Duplicate
 </button>
 <button className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-white bg-slate-800 rounded px-2 py-1.5 transition-colors">
 <FaDownload className="w-3 h-3" /> Export Config
 </button>
 <button className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-white bg-slate-800 rounded px-2 py-1.5 transition-colors">
 <FaChartLine className="w-3 h-3" /> View Pricing
 </button>
 <button className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-white bg-slate-800 rounded px-2 py-1.5 transition-colors">
 <FaPlay className="w-3 h-3" /> Run Test
 </button>
 </div>
 </div>
 </div>
 )}
 </div>

 {/* Other sidebar tabs placeholder */}
 {sidebarTab !== "Overview" && (
 <div className="bg-[#1a1d2e] border border-slate-700 rounded-lg p-6 text-center">
 <p className="text-sm text-slate-500">Select a model to view {sidebarTab.toLowerCase()} details.</p>
 </div>
 )}
 </div>
 </div>

 {/* Bottom Charts Row */}
 <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
 {/* Model Usage (7d) Area Chart */}
 <div className="bg-[#1a1d2e] border border-slate-700 rounded-lg p-4">
 <h3 className="text-sm font-semibold text-white mb-1">Model Usage (7d)</h3>
 <p className="text-xs text-slate-500 mb-3">Requests per day</p>
 <AreaChart />
 </div>

 {/* Cost by Model Donut */}
 <div className="bg-[#1a1d2e] border border-slate-700 rounded-lg p-4">
 <h3 className="text-sm font-semibold text-white mb-1">Cost by Model</h3>
 <p className="text-xs text-slate-500 mb-3">Monthly spend distribution</p>
 <InteractiveDonut
 segments={COST_DATA.map(d => ({ label: d.name, value: d.value, color: d.color }))}
 size={180}
 strokeWidth={18}
 centerLabel="Cost"
 showLegend={true}
 legendLayout="horizontal"
 />
 </div>

 {/* Model Assignments Horizontal Bar */}
 <div className="bg-[#1a1d2e] border border-slate-700 rounded-lg p-4">
 <h3 className="text-sm font-semibold text-white mb-1">Model Assignments</h3>
 <p className="text-xs text-slate-500 mb-3">Active assignments per model</p>
 <div className="space-y-2">
 {ASSIGNMENT_DATA.map((item) => (
 <div key={item.name}>
 <div className="flex items-center justify-between text-xs mb-1">
 <span className="text-slate-400">{item.name}</span>
 <span className="text-slate-500">{item.value}</span>
 </div>
 <div className="w-full bg-slate-700 rounded-full h-2">
 <div className={`${item.color} h-2 rounded-full`} style={{ width: item.width }} />
 </div>
 </div>
 ))}
 </div>
 </div>
 </div>
 </div>
 </Layout>
 );
};

function InfoRow({ label, value }: { label: string; value: string }) {
 return (
 <div className="flex items-center justify-between">
 <span className="text-xs text-slate-500">{label}</span>
 <span className="text-xs text-slate-300">{value}</span>
 </div>
 );
}

export default ModelsPage;
