import React, { useState } from "react";
import { useRouter } from "next/router";
import Layout from "@/components/Layout";
import {
 FaSearch,
 FaPlus,
 FaUserCircle,
 FaCircle,
 FaCheckSquare,
 FaEllipsisH,
 FaTimesCircle,
 FaCheckCircle,
 FaMicrochip,
 FaTasks,
 FaUsers,
} from "react-icons/fa";

import InteractiveDonut from "@/components/InteractiveDonut";

// --- Sample Data ---------------------------------------------------

interface Employee {
 id: string;
 name: string;
 role: string;
 team: string;
 model: string;
 status: "Active" | "On Leave" | "Inactive";
 currentWork: string;
 tokenUsage: number;
 email: string;
 joined: string;
 location: string;
 timezone: string;
 skills: string[];
 assignments: { title: string; project: string; due?: string; status: string }[];
}

const EMPLOYEES: Employee[] = [
 {
 id: "EMP-001",
 name: "Alex Kumar",
 role: "Scrum Master",
 team: "Team Alpha",
 model: "Claude Sonnet 4",
 status: "Active",
 currentWork: "Sprint planning",
 tokenUsage: 12500,
 email: "alex.kumar@aicompany.ai",
 joined: "Jan 5, 2025",
 location: "Remote",
 timezone: "IST (UTC+5:30)",
 skills: ["Agile", "Scrum", "Sprint Planning", "Stakeholder Management"],
 assignments: [
 { title: "Sprint 14 planning", project: "Alpha Sprint", status: "In Progress" },
 ],
 },
 {
 id: "EMP-002",
 name: "Taylor Singh",
 role: "Business Analyst",
 team: "Team Alpha",
 model: "Claude Sonnet 4",
 status: "Active",
 currentWork: "Requirements (US-23)",
 tokenUsage: 18200,
 email: "taylor.singh@aicompany.ai",
 joined: "Dec 10, 2024",
 location: "Remote",
 timezone: "IST (UTC+5:30)",
 skills: ["Requirements Analysis", "User Stories", "JIRA", "Data Analysis"],
 assignments: [
 { title: "US-23: Checkout flow", project: "E-commerce Platform", due: "Apr 20, 2025", status: "In Progress" },
 ],
 },
 {
 id: "EMP-003",
 name: "Casey Chen",
 role: "Designer",
 team: "Team Alpha",
 model: "Claude Fable 5.1",
 status: "Active",
 currentWork: "UI/UX for checkout",
 tokenUsage: 45100,
 email: "casey.chen@aicompany.ai",
 joined: "Jan 15, 2025",
 location: "Remote",
 timezone: "IST (UTC+5:30)",
 skills: ["UI/UX Design", "Design Systems", "Prototyping", "User Research", "Accessibility", "Figma"],
 assignments: [
 { title: "UI/UX for checkout flow", project: "E-commerce Platform", status: "In Progress" },
 { title: "TASK-147: E-commerce Platform", project: "E-commerce Platform", due: "Apr 28, 2025", status: "In Progress" },
 ],
 },
 {
 id: "EMP-004",
 name: "Morgan Lee",
 role: "Senior Developer",
 team: "Team Alpha",
 model: "Claude Opus 5",
 status: "Active",
 currentWork: "Payment API (TASK-142)",
 tokenUsage: 62300,
 email: "morgan.lee@aicompany.ai",
 joined: "Nov 1, 2024",
 location: "Remote",
 timezone: "PST (UTC-8)",
 skills: ["TypeScript", "Node.js", "PostgreSQL", "API Design", "AWS"],
 assignments: [
 { title: "Payment API (TASK-142)", project: "E-commerce Platform", due: "Apr 25, 2025", status: "In Progress" },
 ],
 },
 {
 id: "EMP-005",
 name: "Jordan Patel",
 role: "Senior Developer",
 team: "Team Alpha",
 model: "Claude Opus 5",
 status: "Active",
 currentWork: "Code review",
 tokenUsage: 38700,
 email: "jordan.patel@aicompany.ai",
 joined: "Nov 15, 2024",
 location: "Hybrid",
 timezone: "EST (UTC-5)",
 skills: ["React", "Python", "Docker", "CI/CD", "Code Review"],
 assignments: [
 { title: "Code review - checkout module", project: "E-commerce Platform", status: "In Progress" },
 ],
 },
 {
 id: "EMP-006",
 name: "Riley Adams",
 role: "Junior Developer",
 team: "Team Alpha",
 model: "Claude Haiku",
 status: "Active",
 currentWork: "UI components (TASK-147)",
 tokenUsage: 15900,
 email: "riley.adams@aicompany.ai",
 joined: "Feb 1, 2025",
 location: "Remote",
 timezone: "IST (UTC+5:30)",
 skills: ["React", "CSS", "Tailwind", "JavaScript"],
 assignments: [
 { title: "UI components (TASK-147)", project: "E-commerce Platform", status: "In Progress" },
 ],
 },
 {
 id: "EMP-007",
 name: "Quinn Park",
 role: "Tester / QA",
 team: "Team Alpha",
 model: "Claude Sonnet 4",
 status: "Active",
 currentWork: "Test cases (US-23)",
 tokenUsage: 21400,
 email: "quinn.park@aicompany.ai",
 joined: "Dec 20, 2024",
 location: "Remote",
 timezone: "CET (UTC+1)",
 skills: ["Test Automation", "Selenium", "Playwright", "Regression Testing"],
 assignments: [
 { title: "Test cases (US-23)", project: "E-commerce Platform", status: "In Progress" },
 ],
 },
 {
 id: "EMP-008",
 name: "Sam Wilson",
 role: "Scrum Master",
 team: "Team Beta",
 model: "Claude Sonnet 4",
 status: "Active",
 currentWork: "Daily sync & blockers",
 tokenUsage: 11800,
 email: "sam.wilson@aicompany.ai",
 joined: "Oct 5, 2024",
 location: "Remote",
 timezone: "PST (UTC-8)",
 skills: ["Agile", "Scrum", "Retrospectives", "Team Coordination"],
 assignments: [
 { title: "Sprint 14 coordination", project: "Beta Sprint", status: "In Progress" },
 ],
 },
 {
 id: "EMP-009",
 name: "Jamie Kim",
 role: "Business Analyst",
 team: "Team Beta",
 model: "Claude Sonnet 4",
 status: "Active",
 currentWork: "User stories (EP-12)",
 tokenUsage: 16700,
 email: "jamie.kim@aicompany.ai",
 joined: "Jan 2, 2025",
 location: "Remote",
 timezone: "KST (UTC+9)",
 skills: ["Requirements Analysis", "User Stories", "BPMN", "Confluence"],
 assignments: [
 { title: "EP-12: Analytics dashboard", project: "Analytics Platform", due: "May 10, 2025", status: "In Progress" },
 ],
 },
 {
 id: "EMP-010",
 name: "Avery Brown",
 role: "Designer",
 team: "Team Beta",
 model: "Claude Fable 5.1",
 status: "On Leave",
 currentWork: "-",
 tokenUsage: 0,
 email: "avery.brown@aicompany.ai",
 joined: "Sep 10, 2024",
 location: "Remote",
 timezone: "EST (UTC-5)",
 skills: ["UI/UX Design", "Branding", "Illustration", "Figma"],
 assignments: [],
 },
 {
 id: "EMP-011",
 name: "Chris Evans",
 role: "Senior Developer",
 team: "Team Beta",
 model: "Claude Opus 5",
 status: "Active",
 currentWork: "Backend services",
 tokenUsage: 51200,
 email: "chris.evans@aicompany.ai",
 joined: "Aug 20, 2024",
 location: "On-site",
 timezone: "PST (UTC-8)",
 skills: ["Go", "gRPC", "Kubernetes", "Microservices", "Redis"],
 assignments: [
 { title: "Backend services - analytics API", project: "Analytics Platform", due: "May 5, 2025", status: "In Progress" },
 ],
 },
 {
 id: "EMP-012",
 name: "Dana Scott",
 role: "Senior Developer",
 team: "Team Beta",
 model: "Claude Opus 5",
 status: "Active",
 currentWork: "Database optimization",
 tokenUsage: 49800,
 email: "dana.scott@aicompany.ai",
 joined: "Jul 15, 2024",
 location: "Hybrid",
 timezone: "EST (UTC-5)",
 skills: ["PostgreSQL", "Redis", "Query Optimization", "Data Modeling"],
 assignments: [
 { title: "Database optimization", project: "Analytics Platform", due: "Apr 30, 2025", status: "In Progress" },
 ],
 },
 {
 id: "EMP-013",
 name: "Lee Nguyen",
 role: "Junior Developer",
 team: "Team Beta",
 model: "Claude Haiku",
 status: "Active",
 currentWork: "Bug fixes (BUG-87)",
 tokenUsage: 14100,
 email: "lee.nguyen@aicompany.ai",
 joined: "Mar 1, 2025",
 location: "Remote",
 timezone: "IST (UTC+5:30)",
 skills: ["JavaScript", "React", "Bug Fixing", "Testing"],
 assignments: [
 { title: "BUG-87: Fix login redirect", project: "Analytics Platform", due: "Apr 22, 2025", status: "In Progress" },
 ],
 },
 {
 id: "EMP-014",
 name: "Pat Garcia",
 role: "Tester / QA",
 team: "Team Beta",
 model: "Claude Sonnet 4",
 status: "Active",
 currentWork: "Regression testing",
 tokenUsage: 22600,
 email: "pat.garcia@aicompany.ai",
 joined: "Feb 15, 2025",
 location: "Remote",
 timezone: "CET (UTC+1)",
 skills: ["Test Automation", "Cypress", "API Testing", "Performance Testing"],
 assignments: [
 { title: "Regression testing - v2.1", project: "Analytics Platform", status: "In Progress" },
 ],
 },
];

// --- Helpers -------------------------------------------------------

const ROLE_COLORS: Record<string, string> = {
 Designer: "bg-purple-500/15 text-purple-300 border-purple-500/30",
 "Business Analyst": "bg-blue-500/15 text-blue-300 border-blue-500/30",
 "Senior Developer": "bg-emerald-500/15 text-emerald-300 border-emerald-500/30",
 "Junior Developer": "bg-amber-500/15 text-amber-300 border-amber-500/30",
 "Tester / QA": "bg-slate-500/15 text-slate-300 border-slate-500/30",
 "Scrum Master": "bg-teal-500/15 text-teal-300 border-teal-500/30",
};

const STATUS_CONFIG: Record<string, { color: string; dot: string }> = {
 Active: { color: "text-emerald-400", dot: "bg-emerald-400" },
 "On Leave": { color: "text-amber-400", dot: "bg-amber-400" },
 Inactive: { color: "text-red-400", dot: "bg-red-400" },
};

const TEAMS = ["Team Alpha", "Team Beta", "Team Gamma", "Team Delta"];
const ROLES = [
 "Scrum Master",
 "Business Analyst",
 "Designer",
 "Senior Developer",
 "Junior Developer",
 "Tester / QA",
];

const formatTokens = (n: number) => {
 if (n >= 1000) return (n / 1000).toFixed(1) + "K";
 return n.toString();
};

// --- Main Page -----------------------------------------------------

const Employees: React.FC = () => {
 const router = useRouter();
 const handleNavigate = (item: string) => {
 const navHref: Record<string, string> = {
 overview: "/",
 teams: "/teams",
 tasks: "/tasks",
 agents: "/agents",
 projects: "/projects",
 activity: "/activity",
 settings: "/settings",
 sprints: "/sprints",
 };
 router.push(navHref[item] || "/");
 };
 const [searchQuery, setSearchQuery] = useState("");
 const [teamFilter, setTeamFilter] = useState("All Teams");
 const [roleFilter, setRoleFilter] = useState("All Roles");
 const [selectedId, setSelectedId] = useState("EMP-003");
 const [currentPage, setCurrentPage] = useState(1);
 const [rowsPerPage, setRowsPerPage] = useState(14);
 const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
 const [profileTab, setProfileTab] = useState("Overview");

 const selectedEmployee = EMPLOYEES.find((e) => e.id === selectedId)!;

 // Filtering
 const filtered = EMPLOYEES.filter((emp) => {
 const matchesSearch =
 !searchQuery ||
 emp.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
 emp.role.toLowerCase().includes(searchQuery.toLowerCase()) ||
 emp.team.toLowerCase().includes(searchQuery.toLowerCase());
 const matchesTeam = teamFilter === "All Teams" || emp.team === teamFilter;
 const matchesRole = roleFilter === "All Roles" || emp.role === roleFilter;
 return matchesSearch && matchesTeam && matchesRole;
 });

 const totalPages = Math.max(1, Math.ceil(filtered.length / rowsPerPage));
 const safePage = Math.min(currentPage, totalPages);
 const pageStart = (safePage - 1) * rowsPerPage;
 const pageEmployees = filtered.slice(pageStart, pageStart + rowsPerPage);

 const toggleSelect = (id: string) => {
 setSelectedIds((prev) => {
 const next = new Set(prev);
 if (next.has(id)) next.delete(id);
 else next.add(id);
 return next;
 });
 };

 const allOnPageSelected = pageEmployees.length > 0 && pageEmployees.every((e) => selectedIds.has(e.id));

 // Stats
 const totalEmployees = 28;
 const activeCount = 24;
 const onLeaveCount = 3;
 const inactiveCount = 1;
 const differentModels = 7;

 // Render

 return (
 <Layout activeNav="employees" onNavigate={handleNavigate}>
 {/* Page Header */}
 <div className="px-6">
 <div>
 <h1 className="text-2xl font-bold text-white mb-1">Employees</h1>
 <p className="text-sm text-slate-400">
 Manage your AI workforce, assign roles, configure models, and track performance across all teams.
 </p>
 </div>
 <div className="flex items-center gap-3 flex-wrap">
 <div className="relative">
 <FaSearch className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
 <input
 type="text"
 value={searchQuery}
 onChange={(e) => { setSearchQuery(e.target.value); setCurrentPage(1); }}
 placeholder="Search employees..."
 className="input-dark pl-10 w-64"
 />
 </div>
 <select
 value={teamFilter}
 onChange={(e) => { setTeamFilter(e.target.value); setCurrentPage(1); }}
 className="input-dark"
 >
 <option>All Teams</option>
 {TEAMS.map((t) => (
 <option key={t}>{t}</option>
 ))}
 </select>
 <select
 value={roleFilter}
 onChange={(e) => { setRoleFilter(e.target.value); setCurrentPage(1); }}
 className="input-dark"
 >
 <option>All Roles</option>
 {ROLES.map((r) => (
 <option key={r}>{r}</option>
 ))}
 </select>
 <button className="btn-primary flex items-center gap-2">
 <FaPlus className="w-4 h-4" />
 Add Employee
 </button>
 </div>
 </div>

 {/* Stats Row */}
 <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 mb-6">
 {[
 { label: "Total Employees", value: totalEmployees.toString(), sub: "^ 4 vs last month", accent: false },
 { label: "Active", value: activeCount.toString(), sub: `(${Math.round((activeCount / totalEmployees) * 100)}%)`, accent: false },
 { label: "On Leave", value: onLeaveCount.toString(), sub: `(${Math.round((onLeaveCount / totalEmployees) * 100)}%)`, accent: false },
 { label: "Inactive", value: inactiveCount.toString(), sub: `(${Math.round((inactiveCount / totalEmployees) * 100)}%)`, accent: false },
 { label: "Different Models", value: differentModels.toString(), sub: "Manage Models ->", accent: true },
 ].map((stat) => (
 <div key={stat.label} className="stat-card">
 <p className="text-xs text-slate-400 mb-1">{stat.label}</p>
 <p className="text-2xl font-bold text-white">{stat.value}</p>
 <p className={`text-xs mt-1 ${stat.accent ? "text-blue-400 hover:underline cursor-pointer" : "text-slate-500"}`}>
 {stat.sub}
 </p>
 </div>
 ))}
 </div>

 {/* Main Layout: Table + Profile Panel */}
 <div className="flex flex-col lg:flex-row gap-6 mb-6">
 {/* LEFT: Employee Table */}
 <div className="flex-1 min-w-0">
 <div className="bg-[#1a1d2e] border border-slate-700 rounded-lg overflow-hidden">
 <div className="overflow-x-auto">
 <table className="w-full text-sm">
 <thead>
 <tr className="border-b border-slate-700 text-left text-xs text-slate-400 uppercase tracking-wider">
 <th className="p-3 w-10">
 <button
 onClick={() => {
 if (allOnPageSelected) setSelectedIds(new Set());
 else setSelectedIds(new Set(pageEmployees.map((e) => e.id)));
 }}
 className="text-slate-400 hover:text-white"
 >
 <FaCheckSquare className={`w-4 h-4 ${allOnPageSelected ? "text-blue-400" : ""}`} />
 </button>
 </th>
 <th className="p-3">Name</th>
 <th className="p-3">Role</th>
 <th className="p-3">Team</th>
 <th className="p-3">AI Model</th>
 <th className="p-3">Status</th>
 <th className="p-3">Current Work</th>
 <th className="p-3 text-right">Token Usage (7d)</th>
 <th className="p-3 w-10"></th>
 </tr>
 </thead>
 <tbody>
 {pageEmployees.map((emp) => {
 const isSelected = selectedId === emp.id;
 const roleColor = ROLE_COLORS[emp.role] || "bg-slate-500/15 text-slate-300 border-slate-500/30";
 const statusCfg = STATUS_CONFIG[emp.status] || STATUS_CONFIG.Active;

 return (
 <tr
 key={emp.id}
 onClick={() => setSelectedId(emp.id)}
 className={`border-b border-slate-700/50 cursor-pointer transition-colors ${
 isSelected ? "bg-blue-500/10" : "hover:bg-slate-800/40"
 }`}
 >
 <td className="p-3">
 <button
 onClick={(e) => { e.stopPropagation(); toggleSelect(emp.id); }}
 className="text-slate-400 hover:text-white"
 >
 <FaCheckSquare className={`w-4 h-4 ${selectedIds.has(emp.id) ? "text-blue-400" : ""}`} />
 </button>
 </td>
 <td className="p-3">
 <div className="flex items-center gap-2">
 <FaUserCircle className="w-8 h-8 text-slate-500 flex-shrink-0" />
 <div>
 <span className={`font-medium ${isSelected ? "text-blue-300" : "text-white"}`}>{emp.name}</span>
 <span className="text-xs text-slate-500 block">{emp.id}</span>
 </div>
 </div>
 </td>
 <td className="p-3">
 <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium border ${roleColor}`}>
 {emp.role}
 </span>
 </td>
 <td className="p-3 text-slate-300">{emp.team}</td>
 <td className="p-3 text-slate-300">{emp.model}</td>
 <td className="p-3">
 <span className={`inline-flex items-center gap-1.5 text-xs ${statusCfg.color}`}>
 <FaCircle className="w-2 h-2" />
 {emp.status}
 </span>
 </td>
 <td className="p-3 text-slate-400 max-w-[160px] truncate">{emp.currentWork}</td>
 <td className="p-3 text-right text-slate-300 font-mono text-xs">{formatTokens(emp.tokenUsage)}</td>
 <td className="p-3">
 <button className="text-slate-400 hover:text-white p-1">
 <FaEllipsisH className="w-4 h-4" />
 </button>
 </td>
 </tr>
 );
 })}
 </tbody>
 </table>
 </div>
 </div>

 {/* Pagination */}
 <div className="flex items-center justify-between mt-4">
 <p className="text-xs text-slate-400">
 Showing {pageStart + 1}-{Math.min(pageStart + rowsPerPage, filtered.length)} of {filtered.length} employees
 </p>
 <div className="flex items-center gap-3">
 <div className="flex items-center gap-1">
 <span className="text-xs text-slate-400 mr-1">Page</span>
 {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
 <button
 key={page}
 onClick={() => setCurrentPage(page)}
 className={`w-8 h-8 rounded text-xs flex items-center justify-center transition-colors ${
 safePage === page ? "bg-blue-600 text-white" : "text-slate-400 hover:bg-slate-800"
 }`}
 >
 {page}
 </button>
 ))}
 </div>
 <div className="flex items-center gap-2">
 <span className="text-xs text-slate-400">Rows per page:</span>
 <select
 value={rowsPerPage}
 onChange={(e) => { setRowsPerPage(Number(e.target.value)); setCurrentPage(1); }}
 className="input-dark text-xs py-1"
 >
 <option value={7}>7</option>
 <option value={14}>14</option>
 <option value={28}>28</option>
 </select>
 </div>
 </div>
 </div>
 </div>

 {/* RIGHT: Profile Panel */}
 <div className="w-full lg:w-80 xl:w-96 flex-shrink-0">
 <div className="bg-[#1a1d2e] border border-slate-700 rounded-lg overflow-hidden">
 {/* Header */}
 <div className="p-5 text-center border-b border-slate-700">
 <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center mx-auto mb-3">
 <span className="text-2xl font-bold text-white">
 {selectedEmployee.name.split(" ").map((n) => n[0]).join("")}
 </span>
 </div>
 <div className="flex items-center justify-center gap-2">
 <h3 className="text-lg font-semibold text-white">{selectedEmployee.name}</h3>
 <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
 <FaCircle className="w-1.5 h-1.5" />
 {selectedEmployee.status}
 </span>
 </div>
 <p className="text-sm text-slate-400 mt-1">
 {selectedEmployee.role} - {selectedEmployee.team}
 </p>
 <p className="text-xs text-slate-500 mt-2 italic">"{selectedEmployee.skills[0]} that inspire."</p>
 </div>

 {/* Tabs */}
 <div className="flex border-b border-slate-700">
 {["Overview", "Work", "Performance", "Settings"].map((tab) => (
 <button
 key={tab}
 onClick={() => setProfileTab(tab)}
 className={`flex-1 py-2.5 text-xs font-medium transition-colors ${
 profileTab === tab
 ? "text-blue-400 border-b-2 border-blue-400"
 : "text-slate-400 hover:text-slate-300"
 }`}
 >
 {tab}
 </button>
 ))}
 </div>

 {/* Overview Content */}
 {profileTab === "Overview" && (
 <div className="p-5 space-y-4">
 {[
 { label: "Employee ID", value: selectedEmployee.id },
 { label: "Email", value: selectedEmployee.email },
 { label: "Team", value: selectedEmployee.team },
 { label: "Role", value: selectedEmployee.role },
 { label: "AI Model", value: selectedEmployee.model },
 { label: "Status", value: selectedEmployee.status },
 { label: "Joined", value: selectedEmployee.joined },
 { label: "Location", value: selectedEmployee.location },
 { label: "Timezone", value: selectedEmployee.timezone },
 ].map((field) => (
 <div key={field.label} className="flex justify-between items-start">
 <span className="text-xs text-slate-400">{field.label}</span>
 <span className="text-xs text-white text-right">{field.value}</span>
 </div>
 ))}

 {/* Skills */}
 <div>
 <p className="text-xs text-slate-400 mb-2">Skills & Expertise</p>
 <div className="flex flex-wrap gap-1.5">
 {selectedEmployee.skills.map((skill) => (
 <span key={skill} className="px-2 py-0.5 rounded text-xs bg-slate-700/50 text-slate-300 border border-slate-600/50">
 {skill}
 </span>
 ))}
 <button className="px-2 py-0.5 rounded text-xs border border-dashed border-slate-600 text-slate-500 hover:text-slate-300 hover:border-slate-500 transition-colors">
 + Add Skill
 </button>
 </div>
 </div>

 {/* Current Assignments */}
 <div>
 <p className="text-xs text-slate-400 mb-2">Current Assignments</p>
 <div className="space-y-2">
 {selectedEmployee.assignments.map((a, i) => (
 <div key={i} className="bg-slate-800/50 rounded p-2.5 border border-slate-700/50">
 <p className="text-xs text-white">{a.title}</p>
 <span className="text-[10px] text-slate-500">{a.project}</span>
 {a.due && <span className="text-[10px] text-slate-500 ml-2">Due {a.due}</span>}
 <span className={`text-[10px] ml-2 ${a.status === "In Progress" ? "text-blue-400" : "text-slate-400"}`}>
 {a.status}
 </span>
 </div>
 ))}
 {selectedEmployee.assignments.length === 0 && (
 <p className="text-xs text-slate-500 italic">No active assignments</p>
 )}
 </div>
 </div>

 {/* Model Configuration */}
 <div>
 <p className="text-xs text-slate-400 mb-2">Model Configuration</p>
 <div className="bg-slate-800/50 rounded p-3 border border-slate-700/50">
 <div className="flex items-center justify-between mb-1">
 <span className="text-xs text-white font-medium">{selectedEmployee.model}</span>
 <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-300 border border-amber-500/30 font-medium">
 High Capability
 </span>
 </div>
 <p className="text-[10px] text-slate-500">1M context  Best for complex design and creative</p>
 <button className="mt-2 text-xs text-blue-400 hover:text-blue-300 border border-slate-600 rounded px-2 py-1 hover:border-slate-500 transition-colors">
 Change Model
 </button>
 </div>
 </div>

 {/* Workload */}
 <div>
 <div className="flex justify-between items-center mb-1">
 <p className="text-xs text-slate-400">Workload</p>
 <span className="text-xs text-white font-medium">70%</span>
 </div>
 <div className="h-2 rounded-full bg-slate-700 overflow-hidden">
 <div className="h-full rounded-full bg-blue-500" style={{ width: "70%" }} />
 </div>
 </div>
 </div>
 )}

 {/* Work Tab */}
 {profileTab === "Work" && (
 <div className="p-5">
 <p className="text-xs text-slate-500">Recent work activity for {selectedEmployee.name}.</p>
 <div className="mt-3 space-y-2">
 {selectedEmployee.assignments.map((a, i) => (
 <div key={i} className="bg-slate-800/50 rounded p-3 border border-slate-700/50">
 <p className="text-xs text-white">{a.title}</p>
 <p className="text-[10px] text-slate-500 mt-0.5">{a.project}</p>
 <span className={`inline-block mt-1 text-[10px] ${a.status === "In Progress" ? "text-blue-400" : "text-slate-400"}`}>
 {a.status}
 </span>
 </div>
 ))}
 {selectedEmployee.assignments.length === 0 && (
 <p className="text-xs text-slate-500 italic">No active assignments</p>
 )}
 </div>
 </div>
 )}

 {/* Performance Tab */}
 {profileTab === "Performance" && (
 <div className="p-5 space-y-3">
 <div className="flex justify-between">
 <span className="text-xs text-slate-400">Tasks Completed</span>
 <span className="text-xs text-white">42</span>
 </div>
 <div className="flex justify-between">
 <span className="text-xs text-slate-400">Avg. Completion Time</span>
 <span className="text-xs text-white">2.3 days</span>
 </div>
 <div className="flex justify-between">
 <span className="text-xs text-slate-400">Quality Score</span>
 <span className="text-xs text-emerald-400">94%</span>
 </div>
 <div className="flex justify-between">
 <span className="text-xs text-slate-400">Token Efficiency</span>
 <span className="text-xs text-white">Good</span>
 </div>
 <div className="flex justify-between">
 <span className="text-xs text-slate-400">Uptime</span>
 <span className="text-xs text-emerald-400">99.2%</span>
 </div>
 </div>
 )}

 {/* Settings Tab */}
 {profileTab === "Settings" && (
 <div className="p-5 space-y-3">
 <div className="flex justify-between items-center">
 <span className="text-xs text-slate-400">Auto-assign tasks</span>
 <FaCheckCircle className="w-4 h-4 text-emerald-400" />
 </div>
 <div className="flex justify-between items-center">
 <span className="text-xs text-slate-400">Notify on assignment</span>
 <FaCheckCircle className="w-4 h-4 text-emerald-400" />
 </div>
 <div className="flex justify-between items-center">
 <span className="text-xs text-slate-400">Allow model override</span>
 <FaTimesCircle className="w-4 h-4 text-red-400" />
 </div>
 <div className="flex justify-between items-center">
 <span className="text-xs text-slate-400">Pause when inactive</span>
 <FaCheckCircle className="w-4 h-4 text-emerald-400" />
 </div>
 </div>
 )}
 </div>
 </div>
 </div>

 {/* Bottom Charts Row */}
 <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
 {/* 1. Employees by Role */}
 <div className="stat-card">
 <div className="flex items-center gap-2 mb-3">
 <FaUsers className="w-4 h-4 text-blue-400" />
 <h3 className="text-sm font-medium text-white">Employees by Role</h3>
 </div>
 <div className="flex items-center gap-4">
 <InteractiveDonut
 segments={[
 { label: "Senior Developer", value: 8, color: "#10b981" },
 { label: "Scrum Master", value: 4, color: "#6366f1" },
 { label: "Designer", value: 4, color: "#a855f7" },
 { label: "Junior Developer", value: 4, color: "#f59e0b" },
 { label: "Tester/QA", value: 4, color: "#94a3b8" },
 { label: "Business Analyst", value: 4, color: "#14b8a6" },
 ]}
 centerLabel="By Role"
 showLegend={true}
 />
 <div className="space-y-1.5 flex-1">
 {[
 { label: "Senior Developer", count: 8, color: "bg-emerald-400" },
 { label: "Scrum Master", count: 4, color: "bg-teal-400" },
 { label: "Designer", count: 4, color: "bg-purple-400" },
 { label: "Junior Developer", count: 4, color: "bg-amber-400" },
 { label: "Tester/QA", count: 4, color: "bg-slate-400" },
 { label: "Business Analyst", count: 4, color: "bg-blue-400" },
 ].map((item) => (
 <div key={item.label} className="flex items-center justify-between">
 <div className="flex items-center gap-1.5">
 <div className={`w-2 h-2 rounded-sm ${item.color}`} />
 <span className="text-[11px] text-slate-400">{item.label}</span>
 </div>
 <span className="text-[11px] text-slate-300">{item.count}</span>
 </div>
 ))}
 </div>
 </div>
 <p className="text-[10px] text-slate-500 mt-2">28 total</p>
 </div>

 {/* 2. Employees by Team */}
 <div className="stat-card">
 <div className="flex items-center gap-2 mb-3">
 <FaUsers className="w-4 h-4 text-teal-400" />
 <h3 className="text-sm font-medium text-white">Employees by Team</h3>
 </div>
 <div className="flex items-center gap-4">
 <InteractiveDonut
 segments={[
 { label: "Team Alpha", value: 7, color: "#3b82f6" },
 { label: "Team Beta", value: 7, color: "#6366f1" },
 { label: "Team Gamma", value: 7, color: "#a855f7" },
 { label: "Team Delta", value: 7, color: "#10b981" },
 ]}
 centerLabel="By Team"
 showLegend={true}
 />
 <div className="space-y-1.5 flex-1">
 {[
 { label: "Team Alpha", count: 7, color: "bg-blue-400" },
 { label: "Team Beta", count: 7, color: "bg-indigo-400" },
 { label: "Team Gamma", count: 7, color: "bg-purple-400" },
 { label: "Team Delta", count: 7, color: "bg-emerald-400" },
 ].map((item) => (
 <div key={item.label} className="flex items-center justify-between">
 <div className="flex items-center gap-1.5">
 <div className={`w-2 h-2 rounded-sm ${item.color}`} />
 <span className="text-[11px] text-slate-400">{item.label}</span>
 </div>
 <span className="text-[11px] text-slate-300">{item.count}</span>
 </div>
 ))}
 </div>
 </div>
 <p className="text-[10px] text-slate-500 mt-2">28 total</p>
 </div>

 {/* 3. Model Usage */}
 <div className="stat-card">
 <div className="flex items-center gap-2 mb-3">
 <FaMicrochip className="w-4 h-4 text-purple-400" />
 <h3 className="text-sm font-medium text-white">Model Usage</h3>
 </div>
 <div className="flex items-center gap-4">
 <InteractiveDonut
 segments={[
 { label: "Sonnet 4", value: 12, color: "#6366f1" },
 { label: "Opus 5", value: 6, color: "#8b5cf6" },
 { label: "Haiku", value: 4, color: "#f59e0b" },
 { label: "Fable 5.1", value: 2, color: "#a855f7" },
 { label: "Other", value: 4, color: "#64748b" },
 ]}
 centerLabel="Models"
 showLegend={true}
 />
 <div className="space-y-1.5 flex-1">
 {[
 { label: "Sonnet 4", count: 12, color: "bg-indigo-400" },
 { label: "Opus 5", count: 6, color: "bg-violet-400" },
 { label: "Haiku", count: 4, color: "bg-amber-400" },
 { label: "Fable 5.1", count: 2, color: "bg-fuchsia-400" },
 { label: "Other", count: 4, color: "bg-slate-400" },
 ].map((item) => (
 <div key={item.label} className="flex items-center justify-between">
 <div className="flex items-center gap-1.5">
 <div className={`w-2 h-2 rounded-sm ${item.color}`} />
 <span className="text-[11px] text-slate-400">{item.label}</span>
 </div>
 <span className="text-[11px] text-slate-300">{item.count}</span>
 </div>
 ))}
 </div>
 </div>
 <p className="text-[10px] text-slate-500 mt-2">28 total</p>
 </div>

 {/* 4. Availability */}
 <div className="stat-card">
 <div className="flex items-center gap-2 mb-3">
 <FaTasks className="w-4 h-4 text-emerald-400" />
 <h3 className="text-sm font-medium text-white">Availability</h3>
 </div>
 <div className="flex items-center gap-4">
 <InteractiveDonut
 segments={[
 { label: "Active", value: 24, color: "#10b981" },
 { label: "On Leave", value: 3, color: "#f59e0b" },
 { label: "Inactive", value: 1, color: "#ef4444" },
 ]}
 centerLabel="Staff"
 showLegend={true}
 />
 <div className="space-y-1.5 flex-1">
 {[
 { label: "Active", count: 24, pct: "86%", color: "text-emerald-400", bar: "bg-emerald-400" },
 { label: "On Leave", count: 3, pct: "11%", color: "text-amber-400", bar: "bg-amber-400" },
 { label: "Inactive", count: 1, pct: "3%", color: "text-red-400", bar: "bg-red-400" },
 ].map((item) => (
 <div key={item.label}>
 <div className="flex items-center justify-between">
 <div className="flex items-center gap-1.5">
 <div className={`w-2 h-2 rounded-sm ${item.bar}`} />
 <span className="text-[11px] text-slate-400">{item.label}</span>
 </div>
 <span className={`text-[11px] ${item.color} font-medium`}>{item.pct}</span>
 </div>
 </div>
 ))}
 </div>
 <p className="text-[10px] text-slate-500 mt-2">28 total</p>
 </div>
 </div>
</Layout>
 </div>
 </div>
 </div>
 );
};

export default Employees;
