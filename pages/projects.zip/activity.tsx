import React from "react";
import { useRouter } from "next/router";
import Layout from "@/components/Layout";
import ActivityFeed from "@/components/ActivityFeed";
import { FaStream } from "react-icons/fa";

const ACTIVITIES = [
 { id: "a-1", type: "task_assigned", description: "John Doe assigned 'Build sidebar navigation component' to Jane Smith", meta: null, teamId: "team-1", memberId: "m-1", createdAt: new Date(Date.now() - 1000 * 60 * 5).toISOString() },
 { id: "a-2", type: "agent_completed", description: "Claude Dev #1 completed task: 'Write unit tests for StatCard'", meta: { tokensUsed: 1450 }, teamId: "team-1", memberId: "m-3", createdAt: new Date(Date.now() - 1000 * 60 * 15).toISOString() },
 { id: "a-3", type: "pr_merged", description: "Sarah Lee merged feat/oauth-setup into main", meta: { prNumber: 42 }, teamId: "team-2", memberId: "m-6", createdAt: new Date(Date.now() - 1000 * 60 * 30).toISOString() },
 { id: "a-4", type: "ci_passed", description: "CI build passed for Frontend Squad PR #38", meta: { ciState: "success" }, teamId: "team-1", memberId: "m-3", createdAt: new Date(Date.now() - 1000 * 60 * 45).toISOString() },
 { id: "a-5", type: "task_moved", description: "Jane Smith moved 'Implement auth flow' from Todo to In Progress", meta: null, teamId: "team-1", memberId: "m-2", createdAt: new Date(Date.now() - 1000 * 60 * 60).toISOString() },
 { id: "a-6", type: "commit", description: "Claude Dev #1 pushed 3 commits to feature/sidebar-nav", meta: { branch: "feature/sidebar-nav" }, teamId: "team-1", memberId: "m-3", createdAt: new Date(Date.now() - 1000 * 60 * 90).toISOString() },
 { id: "a-7", type: "agent_started", description: "GPT Assistant #1 started working on task: 'Write unit tests'", meta: null, teamId: "team-1", memberId: "m-4", createdAt: new Date(Date.now() - 1000 * 60 * 120).toISOString() },
 { id: "a-8", type: "milestone_completed", description: "Milestone 'Authentication & Authorization' completed", meta: null, teamId: "team-2", memberId: "m-6", createdAt: new Date(Date.now() - 1000 * 60 * 180).toISOString() },
];

export default function ActivityPage() {
	const router = useRouter();
	const handleNavigate = (item: string) => {
		const navHref: Record<string, string> = {
			overview: "/",
			teams: "/teams",
			tasks: "/tasks",
			agents: "/agents",
			projects: "/projects",
			activity: "/activity",
			settings: "/settings",
			sprints: "/sprints",
		};
		router.push(navHref[item] || "/");
	};

	return (
		<Layout activeNav="activity" onNavigate={handleNavigate}>
 <div className="space-y-6">
 <div className="flex items-center gap-2 mb-2">
 <FaStream className="text-blue-400" />
 <h1 className="text-3xl font-bold text-white">Activity</h1>
 </div>
 <p className="text-slate-400">Real-time feed of team and agent activity across all projects.</p>
 <div className="bg-[#1a1d2e] border border-slate-700 rounded-lg overflow-hidden">
 <div className="px-4 py-3 border-b border-slate-700">
 <h2 className="text-lg font-semibold text-white">Live Activity Feed</h2>
 </div>
 <div className="p-4">
 <ActivityFeed activities={ACTIVITIES} maxHeight="600px" title="All Activity" />
 </div>
 </div>
 </div>
 </Layout>
 );
}
